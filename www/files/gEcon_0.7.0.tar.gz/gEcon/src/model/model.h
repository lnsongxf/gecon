/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file model.h
 * \brief Class representing DSGE model.
 */

#ifndef MODEL_MODEL_H

#define MODEL_MODEL_H

#include <gecon_info.h>
#include <ex.h>
#include <model_block.h>


/// Class representing DSGE model.
class Model {
  public:
    /// Default constructor
    Model();

    /// Set model name (extracts path from name).
    void set_name(const std::string&);

    /// Add variables to be symbolically reduced.
    void add_red_vars(const vec_exint vl) {
        m_redvars_v = vl;
    }

    /// Add block.
    void add_block(const std::string &s);

    /// Add definition.
    void add_definition(const ex &lhs, const ex &rhs, int l) {
        m_blocks.back().add_definition(lhs, rhs, l);
    }

    /// Add control variable.
    void add_controls(const vec_exint &cl) {
        m_blocks.back().add_controls(cl);
    }

    /// Add objective.
    void add_objective(const ex &obj, const ex &obj_eq, const ex &lambda, int l) {
        m_blocks.back().add_objective(obj, obj_eq, lambda, l);
    }

    /// Add constraint.
    void add_constraint(const ex &lhs, const ex &rhs, const ex &lambda, int l) {
        m_blocks.back().add_constraint(lhs, rhs, lambda, l);
    }

    /// Add identity.
    void add_identity(const ex &lhs, const ex &rhs, int l) {
        m_blocks.back().add_identity(lhs, rhs, l);
    }

    /// Add shock.
    void add_shock(const ex &s, int l) {
        m_blocks.back().add_shock(s, l);
    }
    /// Add shocks.
    void add_shocks(const vec_exint &pl) {
        m_blocks.back().add_shocks(pl);
    }

    /// Add calibrating equation.
    void add_calibr(const ex &lhs, const ex &rhs, int l, const vec_exint &pl = vec_exint()) {
        m_blocks.back().add_calibr(lhs, rhs, l, pl);
    }

    /// Be backward compatible?
    void set_backwardcomp(bool fl = true) { m_backwardcomp = fl; }
    /// Be backward compatible?
    bool backwardcomp() const { return m_backwardcomp; }

    /// Be verbose?
    void set_verbose(bool fl = true) { m_verb = fl; }

    /// Write logfile?
    void set_output_logf(bool fl = true) { m_output_logf = fl; }

    /// Write LaTeX?
    void set_output_LaTeX(bool fl = true) { m_output_LaTeX = fl; }

    /// Write R file?
    void set_output_R(bool fl = true) { m_output_R = fl; }

    /// Write R with explicit variable names?
    void set_output_long(bool fl = true) { m_output_long = fl; }

    /// Do it.
    void do_it();

    /// Clear.
    void clear();

    /// Warning
    void warning(const std::string &mes);
    /// Error
    void error(const std::string &mes);
    /// Where there any warnings?
    bool warnings() const { return m_warn.size(); }
    /// Where there any errors?
    bool errors() const { return m_err.size(); }
    /// Retrieve error messages.
    std::string get_errs() const;
    /// Retrieve warning messages.
    std::string get_warns() const;

    /// Produce output
    void write() const;

    /// Write model report to cerr.
    void report() const;

  private:

    // model path and name
    std::string m_path, m_name;
    // block names
    std::set<std::string> m_names;
    // vars for reduction
    vec_exint m_redvars_v;
    set_ex m_redvars;
    // blocks
    std::vector<Model_block> m_blocks;
    // variables
    set_ex m_vars;
    // defined variables
    map_ex_str m_def_vars;
    // parameters
    set_ex m_params, m_params_calibr, m_params_free;
    map_ex_ex m_params_free_set;
    // controls
    map_ex_str m_contr;
    // objective functions
    map_ex_str m_obj;
    // is deterministic?
    bool m_deter;
    // is static?
    bool m_static;
    // max and min lag
    int m_max_lag, m_min_lag;
    // shocks
    set_ex m_shocks;
    // Lagrange multipliers
    set_ex m_lagr_mult, m_lagr_mult_in;
    // Lagged variables
    set_ex m_lags;
    // equations
    set_ex m_eqs;
    // steady stateequations
    vec_ex m_ss;
    // calibration eq's
    set_ex m_calibr;
    // calibration eq's
    set_ex m_calibr_init;
    // Variables, parameters / equations, calibrating equations map
    std::map<std::pair<int, int>, unsigned> m_var_eq_map;
    std::set<std::pair<int, int> > m_var_ceq_map;
    std::set<std::pair<int, int> > m_cpar_eq_map;
    std::set<std::pair<int, int> > m_cpar_ceq_map;
    std::set<std::pair<int, int> > m_fpar_eq_map;
    std::set<std::pair<int, int> > m_fpar_ceq_map;
    // Shocks / equations map
    std::set<std::pair<int, int> > m_shock_eq_map;
    // Jacobian for ss equations
    std::map<std::pair<int, int>, ex> m_jacob_ss;
    // Jacobian for ss and calibration equations
    std::map<std::pair<int, int>, ex> m_jacob_ss_calibr;
    // 1st order pertubation
    std::map<std::pair<int, int>, ex> m_Atm1, m_At, m_Atp1, m_Aeps;
    // warnings & errors
    std::vector<std::string> m_warn, m_err;
    // be verbose?
    bool m_verb;
    // be backward compatible?
    bool m_backwardcomp;
    // output
    bool m_output_R, m_output_long, m_output_logf, m_output_LaTeX;


    // Check definitions
    void check_defs();
    // Check names in blocks
    void check_names();
    // Substitute definitions
    void subst_defs();
    // Check if model is deterministic
    void check_deter();
    // Check controls
    void check_obj_contr();
    // Check / handle leads > 1
    void leads();
    // Check / handle lags > 1
    void lags();
    // Check if model is static
    void check_static();
    // FOCs
    void focs();
    // Collect shocks
    void collect_shocks();
    // Merge vars and parameters in blocks
    void collect_vp();
    // Collect Lagrange multipliers
    void collect_lagr();
    // Collect calibration
    void collect_calibr();
    // Merge equations
    void collect_eq();
    // Check list of variables for reduction
    void check_red_vars();
    // Reduce equations
    void reduce();
    // Construct variables / equations map
    void var_eq_map();
    // Construct variables / calibrating equations map
    void var_ceq_map();
    // Construct calibrated parameters / equations map
    void par_eq_map();
    // Construct calibrated parameters / calibrating equations map
    void par_ceq_map();
    // Construct shocks / equations map
    void shock_eq_map();
    // Steady state
    void stst();
    // Steady state and calibration eq's Jacobian
    void ss_jacob();
    // 1st order derivatives
    void diff_eqs();
    // Write gEcon model info message.
    static void write_model_info(const std::string &mes);
    // Write gEcon info message.
    static void write_info(const std::string &mes);
    // Error
    void terminate_on_errors();
    // Write log
    void write_log(std::ostream&) const;
    // Generate logfile with results.
    void write_logf() const;
    // Generate R code and write it to file.
    void write_R(bool output_long) const;
    // Generate LaTeX documentation and write it to file.
    void write_LaTeX() const;

};


#endif /* MODEL_MODEL_H */
