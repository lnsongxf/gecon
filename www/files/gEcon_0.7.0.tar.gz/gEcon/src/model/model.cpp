/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file model.cpp
 * \brief Class representing DSGE model.
 */

#include <model.h>
#include <model_parse.h>
#include <utils.h>
#include <stdexcept>
#include <fstream>
#include <cstdlib>
#include <ctime>

using symbolic::internal::num2str;
using symbolic::internal::print_flag;
using symbolic::internal::DEFAULT;
using symbolic::internal::CONVERT_T;
using symbolic::internal::DROP_T;
using symbolic::internal::EXACT_T;
using symbolic::internal::ANY_T;
using symbolic::internal::DIFF_T;
using symbolic::internal::LEAD_T;
using symbolic::triplet;


Model::Model() : m_deter(false), m_static(false), m_verb(false), m_backwardcomp(false), m_output_long(false)
{
#ifdef R_DLL
    m_output_R = true; m_output_logf = false; m_output_LaTeX = false;
#else /* R_DLL */
    m_output_R = false; m_output_logf = true, m_output_LaTeX = false;
#endif /* R_DLL */
}


void
Model::write_model_info(const std::string &mes)
{
    ::write_info("(gEcon model info): " + mes);
}


void
Model::write_info(const std::string &mes)
{
    ::write_info("(gEcon info): " + mes);
}


void
Model::warning(const std::string &mes)
{
    m_warn.push_back(mes);
}


void
Model::error(const std::string &mes)
{
    m_err.push_back(mes);
}


void
Model::terminate_on_errors()
{
    if (errors()) {
        write_logf();
        if (warnings()) report_warns(get_warns());
        std::string errs = get_errs();
        clear();
        report_errors(errs);
    }
}



std::string
Model::get_errs() const
{
    std::string errs;
    std::vector<std::string>::const_iterator it;
    int i = 1;
    for (it = m_err.begin(); it != m_err.end(); ++it, ++i)
        errs += "(gEcon model error " + num2str(i) + "): " + *it + '\n';
    time_t tt = time(0);
    struct tm *now = localtime(&tt);
    if ((now->tm_mday == 13) && (now->tm_wday == 5)) {
        errs += "Well, \"I Ain't Superstitious\", but it's Friday the 13th and you've got an error...";
    }
    return errs;
}


std::string
Model::get_warns() const
{
    std::string warns;
    std::vector<std::string>::const_iterator it;
    int i = 1;
    for (it = m_warn.begin(); it != m_warn.end(); ++it, ++i)
        warns += "(gEcon model warning " + num2str(i) + "): " + *it + '\n';
    return warns;
}


void
Model::set_name(const std::string &name)
{
    size_t slash = name.find_last_of('/');
    if (slash == std::string::npos) {
        m_name = name;
        return;
    }
    m_path = name.substr(0, slash + 1);
    m_name = name.substr(slash + 1);
}


void
Model::add_block(const std::string &s)
{
#ifdef DEBUG
    std::cerr << "Adding block: " << s << '\n';
#endif /* DEBUG */
    if (!m_names.insert(s).second)
        error("block called \'" + s + "\' already exists");
    m_blocks.push_back(Model_block(s));
}



void
Model::check_defs()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        for (unsigned d = 0, D = m_blocks[i].m_defs_lhs.size(); d < D; ++d) {
            ex lhs = m_blocks[i].m_defs_lhs[d].first;
            ex rhs = m_blocks[i].m_defs_rhs[d].first;
            if (lhs.hast()) {
                int l;
                if ((l = lhs.get_lag_max())) {
                    lhs = lag(lhs, -l);
                    error("\'" + lhs.str() + "\' defined in lead/lag; error near line "
                          + num2str(m_blocks[i].m_defs_lhs[d].second));
                }
                if (!rhs.hast()) {
                    error("variable \'" + lhs.str() + "\' defined as constant expression \'"
                          + rhs.str() + "\'; error near line "
                          + num2str(m_blocks[i].m_defs_lhs[d].second));
                }
                m_def_vars.insert(exstr(lhs, m_blocks[i].m_name));
            } else {
                if (rhs.hast()) {
                    error("constant \'" + lhs.str() + "\' defined as variable expression \'"
                          + rhs.str() + "\'; error near line "
                          + num2str(m_blocks[i].m_defs_lhs[d].second));
                }
            }
            if (!m_blocks[i].m_defs.insert(lhs).second) {
                error("\'" + lhs.str() + "\' already defined; error near line "
                        + num2str(m_blocks[i].m_defs_lhs[d].second));
            }
            if (rhs.has(lhs, ANY_T)) {
                error("\'" + lhs.str() + "\' used in its own definition; error near line "
                        + num2str(m_blocks[i].m_defs_lhs[d].second));
            }
            for (unsigned dd = d + 1; dd < D; ++dd) {
                ex rhsf = m_blocks[i].m_defs_rhs[dd].first;
                if (rhsf.has(lhs, ANY_T)) {
                    error("\'" + lhs.str() + "\' appears in definition following "
                          "the definition of \'" + lhs.str() + "\' itself; error near line "
                            + num2str(m_blocks[i].m_defs_lhs[dd].second));
                }
            }
        }
    }
}



void
Model::check_names()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        set_ex vars, params;
        m_blocks[i].collect_vp(vars, params, true);
        set_ex::const_iterator it;
        std::set<std::string> names;
        for (it = vars.begin(); it != vars.end(); ++it) {
            std::string name = it->str(DROP_T);
            names.insert(name);
        }
        for (it = params.begin(); it != params.end(); ++it) {
            std::string name = it->str();
            if (!names.insert(name).second) {
                error("\'" + name + "\' treated both as a variable and a parameter in block "
                      + m_blocks[i].m_name + "; you might have forgotten \'[]\'");
            }
        }
    }
}





void
Model::subst_defs()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        m_blocks[i].subst_defs();
    }
}



void
Model::check_obj_contr()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        ex obj = m_blocks[i].m_obj_var;
        if (obj) {
            int l;
            if ((l = obj.get_lag_max())) {
                error("objective variable \'" + lag(obj, -l).str() + "\' on LHS of " + m_blocks[i].m_name
                      + "\'s problem is in lag different than 0; error near line "
                      + num2str(m_blocks[i].m_obj_line));
            }
            if (!m_obj.insert(exstr(obj, m_blocks[i].m_name)).second) {
                error("objective variable \'" + obj.str() + "\' in " + m_blocks[i].m_name
                      + "\'s problem is objective variable in " + m_obj.find(obj)->second
                      + "\'s problem; error near line " + num2str(m_blocks[i].m_obj_line));
            }
            if (m_blocks[i].m_obj_eq.has(lag(obj, 1), DIFF_T)) {
                error("objective variable \'" + obj.str() + "\' on RHS of " + m_blocks[i].m_name
                      + "\'s problem is in lead/lag different than 1; "
                      + "error near line " + num2str(m_blocks[i].m_obj_line));
            }
            if (!m_blocks[i].m_obj_eq.has(lag(obj, 1), EXACT_T)) {
                m_blocks[i].m_static = true;
            }
            for (unsigned j = 0, J = m_blocks[i].m_constraints.size(); j < J; ++j) {
                if (m_blocks[i].m_constraints[j].first.has(lag(obj, 1), DIFF_T)) {
                    error("objective variable \'" + obj.str() + "\' in " + m_blocks[i].m_name
                        + "\'s problem's constraint is in lead/lag different than 1; "
                        + "error near line " + num2str(m_blocks[i].m_constraints[j].second));
                }
            }
        }
    }

    for (std::map<ex, std::string>::const_iterator it = m_obj.begin();
         it != m_obj.end(); ++it) {
        for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
            for (unsigned j = 0, J = m_blocks[i].m_identities.size(); j < J; ++j) {
                if (m_blocks[i].m_identities[j].first.has(it->first, ANY_T)) {
                    warning(it->second + "\'s objective variable \'" + it->first.str()
                            + "\' appears in identity; warning near line "
                            + num2str(m_blocks[i].m_identities[j].second));
                }
            }
        }
    }

    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        for (unsigned c = 0, C = m_blocks[i].m_controls.size(); c < C; ++c) {
            ex contr = m_blocks[i].m_controls[c].first;
            int l;
            bool any = false;
            if ((l = contr.get_lag_max())) {
                error("control variable \'" + lag(contr, -l).str() + "\' in " + m_blocks[i].m_name
                      + "\'s problem lag is " + num2str(l) + "; error near line "
                      + num2str(m_blocks[i].m_controls[c].second));
            }
            if (!m_blocks[i].m_contr.insert(contr).second) {
                error("control variable \'" + contr.str() + "\' in "
                      + m_blocks[i].m_name + "\'s problem is duplicated; error near line "
                      + num2str(m_blocks[i].m_controls[c].second));
            }
            if (m_blocks[i].m_defs.find(contr) != m_blocks[i].m_defs.end()) {
                error("control variable \'" + contr.str() + "\' in "
                      + m_blocks[i].m_name + "\'s problem was used in definitions "
                      + "(substituted); error near line "
                      + num2str(m_blocks[i].m_controls[c].second));
            }
            if (m_obj.find(contr) != m_obj.end()) {
                error("control variable \'" + contr.str() + "\' in " + m_blocks[i].m_name
                      + "\'s problem is objective variable in " + m_obj.find(contr)->second
                      + "\'s problem; error near line "
                      + num2str(m_blocks[i].m_controls[c].second));
            }
            if (!m_contr.insert(exstr(contr, m_blocks[i].m_name)).second) {
                warning("control variable \'" + contr.str() + "\' in "
                        + m_blocks[i].m_name + "\'s problem is control variable in "
                        + m_contr.find(contr)->second + "\'s problem; "
                        + "if this was intentional you might consider rewriting your model in terms "
                        + "of two different controls and adding equilibrium condition equating them; "
                        + "one of them could then be selected for reduction; "
                        + "warning near line "+ num2str(m_blocks[i].m_controls[c].second));
            }
            if (m_blocks[i].m_obj_eq.has(contr, ANY_T)) any = true;
            if (m_blocks[i].m_obj_eq.has(contr, LEAD_T)) {
                error("control variable \'" + contr.str() + "\' in " + m_blocks[i].m_name
                      + "\'s problem is in lead; error near line "
                      + num2str(m_blocks[i].m_obj_line));
            }
            for (unsigned j = 0, J = m_blocks[i].m_constraints.size(); j < J; ++j) {
                if (m_blocks[i].m_constraints[j].first.has(contr, ANY_T)) any = true;
                if (m_blocks[i].m_constraints[j].first.has(contr, LEAD_T)) {
                    error("control variable \'" + contr.str() + "\' in " + m_blocks[i].m_name
                        + "\'s problem is in lead; error near line "
                        + num2str(m_blocks[i].m_constraints[j].second));
                }
            }
            if (!any) {
                error("control variable \'" + contr.str() + "\' in " + m_blocks[i].m_name
                    + "\'s problem does not appear in objective nor in any constraint; error near line "
                    + num2str(m_blocks[i].m_controls[c].second));
            }
        }
    }
}



void
Model::check_deter()
{
    m_deter = true;
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        if (m_blocks[i].m_shocks.size()) {
            m_deter = false;
            return;
        }
    }
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        ex eq = m_blocks[i].m_obj_eq;
        int l = m_blocks[i].m_obj_line;
        if (eq.has_Es() > 0) {
            warning("dropping expectation in objective \'"
                    + m_blocks[i].m_obj_var.str() + " = " + eq.str()
                    + "\'; model is deterministic (has no shocks); "
                    + "warning near line " + num2str(l));
            m_blocks[i].m_obj_eq = drop_Es(m_blocks[i].m_obj_eq);
            m_blocks[i].m_obj_eq_in = drop_Es(m_blocks[i].m_obj_eq_in);
        }
        for (unsigned e = 0; e < m_blocks[i].m_constraints.size(); ++e) {
            eq = m_blocks[i].m_constraints[e].first;
            l = m_blocks[i].m_constraints[e].second;
            if (eq.has_Es() > 0) {
                warning("dropping expectation in constraint \'"
                        + eq.str() + " = 0\'; model is deterministic (has no shocks); "
                        + "warning near line " + num2str(l));
                m_blocks[i].m_constraints[e].first =
                    drop_Es(m_blocks[i].m_constraints[e].first);
            }
        }
        for (unsigned e = 0; e < m_blocks[i].m_identities.size(); ++e) {
            eq = m_blocks[i].m_identities[e].first;
            l = m_blocks[i].m_identities[e].second;
            if (eq.has_Es() > 0) {
                warning("dropping expectation in identity \'"
                        + eq.str() + " = 0\'; model is deterministic (has no shocks); "
                        + "warning near line " + num2str(l));
                m_blocks[i].m_identities[e].first =
                    drop_Es(m_blocks[i].m_identities[e].first);
            }
        }
    }
}



void
Model::leads()
{
    m_max_lag = 0;
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        if (!m_deter) {
            ex eq = m_blocks[i].m_obj_eq;
            int l = m_blocks[i].m_obj_line;
            if (eq.get_lag_max(true) > 0) {
                error("forward looking variable(s) in objective \'"
                      + m_blocks[i].m_obj_var.str() + " = " + eq.str()
                      + "\' outside expected value operator in stochastic model; "
                      + "error near line " + num2str(l));
            }
            for (unsigned e = 0; e < m_blocks[i].m_constraints.size(); ++e) {
                eq = m_blocks[i].m_constraints[e].first;
                l = m_blocks[i].m_constraints[e].second;
                if (eq.get_lag_max(true) > 0) {
                    error("forward looking variable(s) in constraint \'"
                        + eq.str() + " = 0\' outside expected value operator "
                        + "in stochastic model; error near line " + num2str(l));
                }
            }
            for (unsigned e = 0; e < m_blocks[i].m_identities.size(); ++e) {
                eq = m_blocks[i].m_identities[e].first;
                l = m_blocks[i].m_identities[e].second;
                if (eq.get_lag_max(true) > 0) {
                    error("forward looking variable(s) in identity \'"
                        + eq.str() + " = 0\' outside expected value operator "
                        + "in stochastic model; error near line " + num2str(l));
                }
            }
        }

        ex eq = m_blocks[i].m_obj_eq;
        int l = m_blocks[i].m_obj_line;
        int mlag;
        if ((mlag = eq.get_lag_max()) > 1) {
            error("variable(s) in objective \'"
                    + m_blocks[i].m_obj_var.str() + " = " + eq.str()
                    + "\' in lead > 1; error near line " + num2str(l));
        }
        if (mlag > m_max_lag) m_max_lag = mlag;
        for (unsigned e = 0; e < m_blocks[i].m_constraints.size(); ++e) {
            eq = m_blocks[i].m_constraints[e].first;
            l = m_blocks[i].m_constraints[e].second;
            if ((mlag = eq.get_lag_max()) > 1) {
                error("variable(s) in constraint \'"
                    + eq.str() + " = 0\' in lead > 1; error near line " + num2str(l));
            }
            if (mlag > m_max_lag) m_max_lag = mlag;
        }
        for (unsigned e = 0; e < m_blocks[i].m_identities.size(); ++e) {
            eq = m_blocks[i].m_identities[e].first;
            l = m_blocks[i].m_identities[e].second;
            if ((mlag = eq.get_lag_max()) > 1) {
                error("variable(s) in identity \'"
                    + eq.str() + " = 0\' in lead > 1; error near line " + num2str(l));
            }
            if (mlag > m_max_lag) m_max_lag = mlag;
        }
    }
}



void
Model::lags()
{
    m_min_lag = 0;
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        int bmlag = 0, mlag;
        ex eq = m_blocks[i].m_obj_eq;
        mlag = eq.get_lag_min();
        if (mlag < bmlag) bmlag = mlag;
        for (unsigned e = 0; e < m_blocks[i].m_constraints.size(); ++e) {
            eq = m_blocks[i].m_constraints[e].first;
            mlag = eq.get_lag_min();
            if (mlag < bmlag) bmlag = mlag;
        }
        for (unsigned e = 0; e < m_blocks[i].m_identities.size(); ++e) {
            eq = m_blocks[i].m_identities[e].first;
            mlag = eq.get_lag_min();
            if (mlag < bmlag) bmlag = mlag;
        }
        if (bmlag < m_min_lag) m_min_lag = bmlag;
        if (bmlag < -1) {
            m_blocks[i].lags();
            m_lags.insert(m_blocks[i].m_lags.begin(), m_blocks[i].m_lags.end());
        }
    }
}



void
Model::check_static()
{
    if ((m_min_lag == 0) && (m_max_lag == 0)) m_static = true;
    if (m_static && !m_deter) {
        error("model is static (has no lags and leads) but has shocks; static models must also be deterministic");
    }
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        if (m_blocks[i].m_static) {
            if (m_blocks[i].m_obj_lm_in) {
                if (m_backwardcomp) {
                    warning("in backward compatibility mode, ignoring declaration of Lagrange multiplier on objective (time aggregator) in static problem; warning near line " + num2str(m_blocks[i].m_obj_line));
                    m_blocks[i].m_redlm.erase(m_blocks[i].m_obj_lm);
                    m_blocks[i].m_obj_lm = ex();
                } else {
                    error("Lagrange multiplier on objective (time aggregator) declared in static problem; please remove it or force acceptance of your code using \"backwardcomp\" option; error near line " + num2str(m_blocks[i].m_obj_line));
                }
            }
        }
    }
}


void
Model::focs()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        if (m_blocks[i].m_static) {
            m_blocks[i].focs_static();
        } else if (m_deter) {
            m_blocks[i].focs_deter();
        } else {
            m_blocks[i].focs();
        }
        for (int f = 0, F = m_blocks[i].m_focs.size(); f < F; ++f) {
            if (!m_blocks[i].m_focs[f].first)
                warning("one of your first order conditions (w.r.t. \""
                        + m_blocks[i].m_focs[f].second.str() + "\") in " + m_blocks[i].m_name +
                        "\'s problem is of the form 0 = 0;");
        }
    }
}


void
Model::collect_shocks()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        std::vector<exint>::const_iterator it, ite;
        it = m_blocks[i].m_shocks.begin();
        ite = m_blocks[i].m_shocks.end();
        for (; it != ite; ++it) {
            if (m_blocks[i].m_defs.find(it->first) != m_blocks[i].m_defs.end()) {
                error("shock \'" + it->first.str() + "\' declared in "
                      + m_blocks[i].m_name + "\'s block was used in definitions "
                      + "(substituted); error near line " + num2str(it->second));
            }
            if (it->first.get_lag_max())
                error("shock \'" + it->first.str() + "\' declared in lead / lag;"
                      + " error near line " + num2str(it->second));
            if (!m_shocks.insert(it->first).second) {
                error("shock " + it->first.str() + " already declared;"
                      + " error near line " + num2str(it->second));
            }
            if (m_obj.find(it->first) != m_obj.end()) {
                error(m_obj.find(it->first)->second + "\'s objective variable \'"
                      + it->first.str() + "\' declared as shock;"
                      + " error near line " + num2str(it->second));
            }
            if (m_contr.find(it->first) != m_contr.end()) {
                error(m_contr.find(it->first)->second + "\'s control variable \'"
                      + it->first.str() + "\' declared as shock;"
                      + " error near line " + num2str(it->second));
            }
        }
    }
}


namespace {

// Easter eggs ;-)
const char* namescomments[] = {
    "dupa", "Oj, brzydko, brzydko ;-)",
    "Dupa", "Oj, brzydko, brzydko ;-)",
    "DUPA", "Oj, brzydko, brzydko ;-)",
    "foo", "Hey, try and be more creative ;-)",
    "bar", "Hey, try and be more creative ;-)",
    "foobar", "Hey, try and be more creative ;-)",
    "foo_bar", "Hey, try and be more creative ;-)",
""};


void
easter_eggs(Model &model, const std::set<std::string> &names)
{
    for (unsigned i = 0; namescomments[i][0]; i += 2) {
        std::string nm = namescomments[i];
        if (names.find(nm) != names.end())
            model.warning("\"" + nm + "\"? " + namescomments[i + 1]);
    }
}

} /* namespace */



void
Model::collect_vp()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        m_blocks[i].collect_vp(m_vars, m_params);
    }

    // Test names of vars and params
    set_ex::const_iterator it;
    std::set<std::string> names;
    for (it = m_vars.begin(); it != m_vars.end(); ++it) {
        std::string name = it->str(DROP_T);
        names.insert(name);
    }
    for (it = m_shocks.begin(); it != m_shocks.end(); ++it) {
        std::string name = it->str(DROP_T);
        names.insert(name);
    }
    for (it = m_params.begin(); it != m_params.end(); ++it) {
        std::string name = it->str();
        if (!names.insert(name).second) {
            error("\'" + name + "\' treated both as a variable and a parameter; you "
                  "might have forgotten \'[]\'");
        }
    }
    names.insert(m_names.begin(), m_names.end());
    easter_eggs(*this, names);
    for (it = m_shocks.begin(); it != m_shocks.end(); ++it) {
        if (m_vars.find(*it) == m_vars.end()) {
            warning("shock \'" + it->str() + "\' does not appear in any model equation");
        } else m_vars.erase(*it);
    }
}



void
Model::collect_lagr()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        std::pair<set_ex::iterator, bool> res;
        ex lmin = m_blocks[i].m_obj_lm_in;
        int l;
        if (lmin) {
            if ((l = lmin.get_lag_max())) {
                error("Lagrange multiplier  \'" + lag(lmin, -l).str() + "\' declared in lead / lag;"
                      + " error near line " + num2str(m_blocks[i].m_obj_line));
            }
            res = m_lagr_mult_in.insert(lmin);
            if (!res.second) {
                error("Lagrange multiplier \'" + lmin.str() + "\' already used;"
                      + " error near line " + num2str(m_blocks[i].m_obj_line));
            }
            if (m_backwardcomp) {
                warning("in backward compatibility mode; adding Lagrange multiplier \'"
                        + lmin.str() + "\' to list of variables for reduction");
                m_redvars.insert(lmin);
            }
        }
        std::vector<exint>::const_iterator it, ite;
        unsigned ll = 0, LL = m_blocks[i].m_lagr_mult_in.size();
        for (; ll < LL; ++ll) {
            lmin = m_blocks[i].m_lagr_mult_in[ll].first;
            if (lmin) {
                if ((l = lmin.get_lag_max())) {
                    error("Lagrange multiplier  \'" + lag(lmin, -l).str() + "\' declared in lead / lag;"
                        + " error near line " + num2str(m_blocks[i].m_lagr_mult_in[l].second));
                }
                res = m_lagr_mult_in.insert(lmin);
                if (!res.second) {
                    error("Lagrange multiplier \'" + lmin.str() + "\' already used;"
                        + " error near line " + num2str(m_blocks[i].m_lagr_mult_in[l].second));
                }
                if (m_backwardcomp) {
                    warning("in backward compatibility mode; adding Lagrange multiplier \'"
                            + lmin.str() + "\' to list of variables for reduction");
                    m_redvars.insert(lmin);
                }
            }
        }
        m_lagr_mult.insert(m_blocks[i].m_redlm.begin(), m_blocks[i].m_redlm.end());
    }
}



namespace {

std::string
mk_diff_no_error(unsigned n1, const std::string &name1, unsigned n2, const std::string &name2)
{
    std::string mes = "There ";
    if (n1 > 1) {
        mes += "are ";
        if (n1 < n2) { mes += "only "; }
        mes += num2str(n1);
        mes += " ";
    } else if (n1 == 1) {
        mes += "is ";
        if (n1 < n2) { mes += "only "; }
        mes += "1 ";
    } else {
        mes += "are no ";
    }
    mes += name1;
    if (n1 == 1) { mes += " "; } else { mes += "s "; }
    mes += "but there ";
    if (n2 > 1) {
        mes += "are ";
        if (n1 > n2) { mes += "only "; }
        mes += num2str(n2);
        mes += " ";
    } else if (n2 == 1) {
        mes += "is ";
        if (n1 > n2) { mes += "only "; }
        mes += "1 ";
    } else {
        mes += "are no ";
    }
    mes += name2;
    if (n2 != 1) { mes += "s"; }

    return mes;
}

} /* namespace */



void
Model::collect_eq()
{
    int i, n;
    for (i = 0, n = m_blocks.size(); i < n; ++i) {
        std::vector<expair>::const_iterator itp, itep;
        itp = m_blocks[i].m_focs_red.begin();
        itep = m_blocks[i].m_focs_red.end();
        for (; itp != itep; ++itp) {
            if (!m_eqs.insert(itp->first).second) {
                warning("repeating equation: " + itp->first.str() + " = 0");
            }
        }
        if (m_blocks[i].m_obj_eq) {
            ex lhs = m_blocks[i].m_obj_var, rhs = m_blocks[i].m_obj_eq;
            if (!m_eqs.insert(lhs - rhs).second) {
                warning("equation for " + m_blocks[i].m_name + "\'s objective \'"
                        + m_blocks[i].m_obj_eq.str() + "\' is duplicated");
            }
        }
        std::vector<exint>::const_iterator it, ite;
        it = m_blocks[i].m_constraints.begin();
        ite = m_blocks[i].m_constraints.end();
        for (; it != ite; ++it) {
            if ((!m_eqs.insert(it->first).second) && (it->second)) {
                warning("repeating constraint: \'" + it->first.str() + " = 0\' "
                        + "near line " + num2str(it->second));
            }
        }
        it = m_blocks[i].m_identities.begin();
        ite = m_blocks[i].m_identities.end();
        for (; it != ite; ++it) {
            if ((!m_eqs.insert(it->first).second) && (it->second)) {
                warning("repeating identity: \'" + it->first.str() + " = 0\' "
                        + "near line " + num2str(it->second));
            }
        }
    }

    unsigned nv = m_vars.size(), ne = m_eqs.size();
    if (nv != ne) {
        error(mk_diff_no_error(nv, "variable", ne, "model equation"));
    }
}




void
Model::collect_calibr()
{
    int i, n;
    set_ex params_set, params_fr_add;
    for (i = 0, n = m_blocks.size(); i < n; ++i) {
        std::vector<exint>::const_iterator it, ite;
        unsigned j, m = m_blocks[i].m_calibr.size();
        for (j = 0; j < m; ++j) {
            ex ceq = m_blocks[i].m_calibr[j].first;
            int lineno = m_blocks[i].m_calibr[j].second;
            if (!ceq) {
                error("calibrating equation \'0 = 0\'; error near line " + num2str(lineno));
                continue;
            }

            if (!m_static && ceq.hast()) {
                error("calibrating equation with non-steady state values: \'" + ceq.str()
                      + " = 0\'; error near line " + num2str(lineno));
            }

            set_ex vars, pars;
            collect(ceq, vars, pars);
            set_ex::const_iterator it, ite;
            for (it = vars.begin(), ite = vars.end(); it != ite; ++it) {
                if (m_vars.find(*it) == m_vars.end()) {
                    error("variable \'" + it->str() + "\' appears in calibrating equation but does not "
                          + "appear in any model equation; error near line " + num2str(lineno));
                }
            }
            vars.clear();
            for (it = pars.begin(), ite = pars.end(); it != ite; ++it) {
                if (m_params.find(*it) == m_params.end()) {
                    warning("parameter \'" + it->str()
                            + "\' appears in calibrating equation but does not "
                            + "appear in any model equation; adding \'"
                            + it->str() + "\' to free parameter list; "
                            + "warning near line " + num2str(lineno));
                    m_params_free.insert(*it);
                    params_fr_add.insert(*it);
                }
            }
            pars.clear();

            triplet<bool, ex, ex> ps = find_par_eq_num(ceq);
            if (ps.first) {
                if (!params_set.insert(ps.second).second) {
                    error("free parameter \'" + ps.second.str()
                          + "\' already set to " + m_params_free_set.find(ps.second)->second.str()
                          + "; error near line " + num2str(lineno));
                }
                if (m_blocks[i].m_calibr_pl[j].size()) {
                    error("equation \'" + ps.second.str() + " = " + ps.third.str()
                          + "\' sets value of a parameter and is not a proper "
                          + "calibrating equation so it cannot be followed by a parameter list; "
                          + "error near line " + num2str(lineno));
                }
                if (!ps.third.validnum()) {
                    error("value of parameter \'" + ps.second.str() + "\' set to " + ps.third.str()
                          + "; error near line " + num2str(lineno));
                }
                m_params_free_set.insert(expair(ps.second, ps.third));
                if (m_params_calibr.find(ps.second) != m_params_calibr.end()) {
                    error("parameter \'" + ps.second.str() + "\' was earlier declared as calibrated "
                          + "parameter; error near line " + num2str(lineno));
                }
                continue;
            }

            for (unsigned k = 0; k < m_blocks[i].m_calibr_pl[j].size(); ++k) {
                ex pp = m_blocks[i].m_calibr_pl[j][k].first;
                if (m_params.find(pp) == m_params.end()) {
                    error("parameter \'" + pp.str() + "\' declared as calibrated, but does not "
                          + "appear in any model equation; error near line "
                          + num2str(m_blocks[i].m_calibr_pl[j][k].second));
                }
//                 if (!ceq.has(pp)) {
//                     warning("parameter \'" + pp.str() + "\' is listed as calibrated through "
//                             + "equation \'" + " = 0\', but does not appear in it; "
//                             + "warning near line " + num2str(m_blocks[i].m_calibr_pl[j][k].second));
//                 }
                if (!pars.insert(pp).second) {
                    error("repeating parameter \'" + pp.str() + "\' in a parameter list; "
                          + "error near line " + num2str(m_blocks[i].m_calibr_pl[j][k].second));
                } else {
                    m_params_calibr.insert(pp);
                }
                map_ex_ex::const_iterator mit;
                if ((mit = m_params_free_set.find(pp)) != m_params_free_set.end()) {
                    error("parameter \'" + pp.str() + "\' declared as calibrated parameter "
                          + "yet at the same time its value was set to " + mit->second.str()
                          + "; error near line "
                          + num2str(m_blocks[i].m_calibr_pl[j][k].second));
                }
            }

            if (!m_calibr.insert(ceq).second) {
                warning("repeating calibration equation \'" + ceq.str()
                        + " = 0\'; warning near line " + num2str(lineno));
            }
        }
    }

    unsigned nfp = m_params_calibr.size(), ce = m_calibr.size();
    if (ce != nfp) {
        error(mk_diff_no_error(nfp, "non-free (calibrated) parameter", ce, "calibrating equation"));
    }

    for (set_ex::const_iterator it = m_params.begin(), ite = m_params.end();
         it != ite; ++it) {
        if (m_params_calibr.find(*it) == m_params_calibr.end())
            m_params_free.insert(*it);
    }
    for (set_ex::const_iterator it = params_fr_add.begin(),
         ite = params_fr_add.end(); it != ite; ++it) {
        m_params.insert(*it);
    }
}



void
Model::check_red_vars()
{
    std::vector<exint>::const_iterator it = m_redvars_v.begin();
    for (; it != m_redvars_v.end(); ++it) {
        if (it->first.get_lag_max()) {
            error("Variable \'" + it->first.str()
                  + "\' selected for reduction listed in lead/lag; error near line "
                  + num2str(it->second));
            continue;
        }
        map_ex_str::const_iterator df = m_def_vars.find(it->first);
        if (df != m_def_vars.end()) {
            warning("Variable \'" + it->first.str()
                    + "\' selected for reduction appears on the LHS of definition in "
                    + df->second + " block; warning near line " + num2str(it->second));
        }
        if (m_vars.find(it->first) == m_vars.end()) {
            error("Variable \'" + it->first.str()
                  + "\' selected for reduction but does not appear in any model equation; "
                  + "error near line " + num2str(it->second));
            continue;
        }
        set_ex::const_iterator it1;
        for (it1 = m_calibr.begin(); it1 != m_calibr.end(); ++it1) {
            if (it1->has(it->first, ANY_T)) {
                warning("Variable \'" + it->first.str()
                        + "\' selected for reduction appears in calibrating equation \'"
                        + it1->str() + " = 0\'; warning near line " + num2str(it->second));
            }
        }
        if (m_redvars.find(it->first) != m_redvars.end()) {
            error("Variable \'" + it->first.str()
                  + "\' already selected for reduction; error near line "
                  + num2str(it->second));
        } else {
            m_redvars.insert(it->first);
        }
    }
    m_redvars.insert(m_lagr_mult.begin(), m_lagr_mult.end());
    m_redvars.insert(m_lags.begin(), m_lags.end());
}



void
Model::reduce()
{
    vec_ex eqs, eqsc;
    eqs.reserve(m_eqs.size());
    for (set_ex::iterator it = m_eqs.begin(); it != m_eqs.end(); ++it) eqs.push_back(*it);
    eqsc.reserve(m_calibr.size());
    for (set_ex::iterator it = m_calibr.begin(); it != m_calibr.end(); ++it) eqsc.push_back(*it);

    unsigned i, n = eqs.size(), nc = eqsc.size();
    bool try_red;
    do {
        try_red = false;
        for (i = 0; i < n; ++i) {
            triplet<bool, ex, ex> ts = find_subst(eqs[i], m_redvars);
            if (!ts.first) continue;
            if (ts.third.hast()) {
                ex e = ts.second, lde = lag(e, 1), lge = lag(e, -1);
                int ld = 0, lg = 0;
                for (unsigned i = 0; i < n; ++i) {
                    if (eqs[i].has(lde)) {
                        ld = 1;
                    }
                    if (eqs[i].has(lge)) {
                        lg = -1;
                    }
                    if (ld && lg) break;
                }
                if (ts.third.get_lag_max() + ld > 1) continue;
                if (ts.third.get_lag_min() + lg < -1) continue;
                // check if we have shocks on RHS in substitution
                bool hasshock = false;
                for (set_ex::const_iterator lit = m_shocks.begin();
                     lit != m_shocks.end(); ++lit) {
                    if (ts.third.has(*lit)) {
                        hasshock = true;
                        break;
                    }
                }
                if (hasshock && (ld || lg)) continue;
            }
            ex what = ts.second, with = ts.third;
            m_lagr_mult.erase(what);
            m_lags.erase(what);
            m_vars.erase(what);
            m_redvars.erase(what);
            eqs[i] = ex();
            for (unsigned j = 0; j < n; ++j) {
                eqs[j] = eqs[j].subst(what, with);
            }
            for (unsigned j = 0; j < nc; ++j) {
                eqsc[j] = eqsc[j].subst(what, with);
            }
            try_red = true;
            break;
        }
    } while (try_red && m_redvars.size());

    m_eqs.clear();
    for (i = 0; i < n; ++i) {
        ex eq = eqs[i];
        if (eq) m_eqs.insert(eq);
    }
    m_calibr.clear();
    for (i = 0; i < nc; ++i) {
        ex eq = eqsc[i];
        if (eq) m_calibr.insert(eq);
    }

    unsigned nv = m_vars.size(), ne = m_eqs.size();
    if (nv != ne) {
        error(mk_diff_no_error(nv, "variable", ne, "model equation"));
    }
    unsigned nfp = m_params_calibr.size(), ce = m_calibr.size();
    if (ce != nfp) {
        error(mk_diff_no_error(nfp, "non-free (calibrated) parameter", ce, "calibrating equation"));
    }

    for (set_ex::const_iterator it = m_lagr_mult.begin();
             it != m_lagr_mult.end(); ++it) {
        m_redvars.erase(*it);
    }
    for (set_ex::const_iterator it = m_lags.begin();
             it != m_lags.end(); ++it) {
        m_redvars.erase(*it);
    }
    if (m_redvars.size()) {
        std::string vlst;
        print_flag pflag = (m_static) ? DROP_T : DEFAULT;
        for (set_ex::const_iterator it = m_redvars.begin();
             it != m_redvars.end();) {
            vlst += "\'" + it->str(pflag) + "\'";
            if (++it != m_redvars.end()) {
                vlst += ", ";
            }
        }
        warning("the following variable(s) selected for reduction could not be \
symbolically reduced in the model: " + vlst);
    }
    if (m_lagr_mult.size()) {
        std::string vlst;
        print_flag pflag = (m_static) ? DROP_T : DEFAULT;
        for (set_ex::const_iterator it = m_lagr_mult.begin();
             it != m_lagr_mult.end();) {
            vlst += "\'" + it->str(pflag) + "\'";
            if (++it != m_lagr_mult.end()) {
                vlst += ", ";
            }
        }
        write_model_info("the following internally generated variable(s) could not be \
symbolically reduced in the model: " + vlst);
    }
    if (m_lags.size()) {
        std::string vlst;
        print_flag pflag = (m_static) ? DROP_T : DEFAULT;
        for (set_ex::const_iterator it = m_lags.begin();
             it != m_lags.end();) {
            vlst += "\'" + it->str(pflag) + "\'";
            if (++it != m_lags.end()) {
                vlst += ", ";
            }
        }
        write_model_info("the following internally generated variable(s) could not be \
symbolically reduced in the model: " + vlst);
    }
}




namespace {

enum lag_flags {
    NUL    =     0,
    LAG_M1 =   0x1,
    LAG_0  =   0x2,
    LAG_P1 =   0x4,
    LAG_SS =   0x8
};

} /* namespace */


void
Model::var_eq_map()
{
    int i, j;
    unsigned flag;
    set_ex::const_iterator it1, it2;
    ex x, e;

    for (it1 = m_eqs.begin(), i = 1; it1 != m_eqs.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_vars.begin(), j = 1; it2 != m_vars.end(); ++it2, ++j) {
            flag = 0;
            x = lag(*it2, -1);
            if (e.has(x)) flag |= LAG_M1;
            x = *it2;
            if (e.has(x)) flag |= LAG_0;
            x = lag(*it2, 1);
            if (e.has(x)) flag |= LAG_P1;
            x = ss(*it2);
            if (e.has(x)) flag |= LAG_SS;
            if (flag) m_var_eq_map.insert(std::pair<std::pair<int, int>, unsigned>(
                                          std::pair<int, int>(i, j), flag));
        }
    }
}


void
Model::shock_eq_map()
{
    int i, j;
    set_ex::const_iterator it1, it2;
    ex x, e;

    for (it1 = m_eqs.begin(), i = 1; it1 != m_eqs.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_shocks.begin(), j = 1; it2 != m_shocks.end(); ++it2, ++j) {
            if (e.has(*it2, DIFF_T)) {
                error("shock \'" + it2->str() + "\' in equation \'" + it1->str()
                      + "\' has invalid time index; shocks should have time index 0");
            }
            if (e.has(*it2)) m_shock_eq_map.insert(std::pair<int, int>(i, j));
        }
    }
}






void
Model::stst()
{
    set_ex::const_iterator it, it2;
    set_ex sseq;
    unsigned vs = m_vars.size();
    m_ss.reserve(vs);

    if (m_static) {
        for (it = m_eqs.begin(); it != m_eqs.end(); ++it) {
            m_ss.push_back(ss(*it));
        }
        return;
    }

    for (it = m_eqs.begin(); it != m_eqs.end(); ++it) {
        ex ssex = ss(*it);
        for (it2 = m_shocks.begin(); it2 != m_shocks.end(); ++it2) {
            ssex = ssex.subst(ss(*it2), ex());
        }
        m_ss.push_back(ssex);
        if (!ssex) {
            error("steady state equation \'0 = 0\' derived from \'"
                  + it->str() + "\'");
            continue;
        }
        if (!sseq.insert(ssex).second) {
            warning("repeating steady state equation: " + ssex.str() + " = 0");
        }
    }

    unsigned sse = sseq.size();
    if (vs != sse) {
        error(mk_diff_no_error(vs, "variable", sse, "steady state equation"));
    }
}



void
Model::var_ceq_map()
{
    int i, j;
    set_ex::const_iterator it1, it2;

    if (m_static) {
        for (it1 = m_calibr.begin(), i = 1; it1 != m_calibr.end(); ++it1, ++i) {
            for (it2 = m_vars.begin(), j = 1; it2 != m_vars.end(); ++it2, ++j) {
                if (it1->has(*it2)) m_var_ceq_map.insert(std::pair<int, int>(i, j));
            }
        }
    }
    for (it1 = m_calibr.begin(), i = 1; it1 != m_calibr.end(); ++it1, ++i) {
        for (it2 = m_vars.begin(), j = 1; it2 != m_vars.end(); ++it2, ++j) {
            if (it1->has(ss(*it2))) m_var_ceq_map.insert(std::pair<int, int>(i, j));
        }
    }
}



void
Model::par_eq_map()
{
    int i, j;
    set_ex::const_iterator it1, it2;
    ex x, r, e;

    for (it1 = m_eqs.begin(), i = 1; it1 != m_eqs.end(); ++it1, ++i) {
        for (it2 = m_params_calibr.begin(), j = 1; it2 != m_params_calibr.end(); ++it2, ++j) {
            if (it1->has(*it2)) m_cpar_eq_map.insert(std::pair<int, int>(i, j));
        }
        for (it2 = m_params_free.begin(), j = 1; it2 != m_params_free.end(); ++it2, ++j) {
            if (it1->has(*it2)) m_fpar_eq_map.insert(std::pair<int, int>(i, j));
        }
    }
}



void
Model::par_ceq_map()
{
    int i, j;
    set_ex::const_iterator it1, it2;

    for (it1 = m_calibr.begin(), i = 1; it1 != m_calibr.end(); ++it1, ++i) {
        for (it2 = m_params_calibr.begin(), j = 1; it2 != m_params_calibr.end(); ++it2, ++j) {
            if (it1->has(*it2)) m_cpar_ceq_map.insert(std::pair<int, int>(i, j));
        }
        for (it2 = m_params_free.begin(), j = 1; it2 != m_params_free.end(); ++it2, ++j) {
            if (it1->has(*it2)) m_fpar_ceq_map.insert(std::pair<int, int>(i, j));
        }
    }
}






void
Model::ss_jacob()
{
    int i, j;
    vec_ex::const_iterator it0;
    set_ex::const_iterator it1, it2;
    ex x, e, r;

    for (it0 = m_ss.begin(), i = 1; it0 != m_ss.end(); ++it0, ++i) {
        e = *it0;
        for (it2 = m_vars.begin(), j = 1; it2 != m_vars.end(); ++it2, ++j) {
            x = ss(*it2);
            r = diff(e, x);
            if (r) {
                m_jacob_ss.insert(std::pair<std::pair<int, int>, ex>(
                                  std::pair<int, int>(i, j), r));
                m_jacob_ss_calibr.insert(std::pair<std::pair<int, int>, ex>(
                                  std::pair<int, int>(i, j), r));
            }
        }
    }
    for (it0 = m_ss.begin(), i = 1; it0 != m_ss.end(); ++it0, ++i) {
        e = *it0;
        for (it2 = m_params_calibr.begin(), j = m_vars.size() + 1;
             it2 != m_params_calibr.end(); ++it2, ++j) {
            x = *it2;
            r = diff(e, x);
            if (r) {
                m_jacob_ss_calibr.insert(std::pair<std::pair<int, int>, ex>(
                                  std::pair<int, int>(i, j), r));
            }
        }
    }
    for (it1 = m_calibr.begin(), i = m_eqs.size() + 1; it1 != m_calibr.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_vars.begin(), j = 1; it2 != m_vars.end(); ++it2, ++j) {
            x = ss(*it2);
            r = diff(e, x);
            if (r) {
                m_jacob_ss_calibr.insert(std::pair<std::pair<int, int>, ex>(
                                  std::pair<int, int>(i, j), r));
            }
        }
    }
    for (it1 = m_calibr.begin(), i = m_eqs.size() + 1; it1 != m_calibr.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_params_calibr.begin(), j = m_vars.size() + 1;
             it2 != m_params_calibr.end(); ++it2, ++j) {
            x = *it2;
            r = diff(e, x);
            if (r) {
                m_jacob_ss_calibr.insert(std::pair<std::pair<int, int>, ex>(
                                  std::pair<int, int>(i, j), r));
            }
        }
    }
}




void
Model::diff_eqs()
{
    int i, j;
    set_ex::const_iterator it1, it2, it3;
    ex x, r, e;

    if (m_static) return;

    for (it1 = m_eqs.begin(), i = 1; it1 != m_eqs.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_vars.begin(), j = 1; it2 != m_vars.end(); ++it2, ++j) {
            x = lag(*it2, -1);
            r = diff(e, x);
            r = ss(r);
            for (it3 = m_shocks.begin(); (it3 != m_shocks.end()) && (r); ++it3) {
                r = r.subst(ss(*it3), ex());
            }
            if (r) m_Atm1.insert(std::pair<std::pair<int, int>, ex>(
                        std::pair<int, int>(i, j), r));
            x = *it2;
            r = diff(e, x);
            r = ss(r);
            for (it3 = m_shocks.begin(); (it3 != m_shocks.end()) && (r); ++it3) {
                r = r.subst(ss(*it3), ex());
            }
            if (r) m_At.insert(std::pair<std::pair<int, int>, ex>(
                        std::pair<int, int>(i, j), r));
            x = lag(*it2, 1);
            r = diff(e, x);
            r = ss(r);
            for (it3 = m_shocks.begin(); (it3 != m_shocks.end()) && (r); ++it3) {
                r = r.subst(ss(*it3), ex());
            }
            if (r) m_Atp1.insert(std::pair<std::pair<int, int>, ex>(
                        std::pair<int, int>(i, j), r));
        }
        for (it2 = m_shocks.begin(), j = 1; it2 != m_shocks.end(); ++it2, ++j) {
            x = *it2;
            r = diff(e, x);
            r = ss(r);
            for (it3 = m_shocks.begin(); (it3 != m_shocks.end()) && (r); ++it3) {
                r = r.subst(ss(*it3), ex());
            }
            if (r) m_Aeps.insert(std::pair<std::pair<int, int>, ex>(
                        std::pair<int, int>(i, j), r));
        }
    }
}



void
Model::do_it()
{
#ifdef DEBUG
    std::cerr << "Sanity check\n";
#endif /* DEBUG */
    terminate_on_errors();
    if (m_verb) {
        std::string mes = "model has " + num2str((unsigned) m_blocks.size()) + " block";
        if (m_blocks.size() > 1) mes += 's';
        mes += ": " + m_blocks[0].m_name;
        for (unsigned i = 1; i < m_blocks.size(); ++i)
            mes += ", " + m_blocks[i].m_name;
        write_model_info(mes);
    }
#ifdef DEBUG
    std::cerr << "Checking definitions\n";
#endif /* DEBUG */
    check_defs();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Checking names in blocks before definition substitution\n";
#endif /* DEBUG */
    check_names();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Substituting definitions\n";
#endif /* DEBUG */
    subst_defs();
#ifdef DEBUG
    std::cerr << "Checking if model is deterministic\n";
#endif /* DEBUG */
    check_deter();
#ifdef DEBUG
    std::cerr << "Checking controls\n";
#endif /* DEBUG */
    check_obj_contr();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Checking / handling leads\n";
#endif /* DEBUG */
    leads();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Checking / handling lags\n";
#endif /* DEBUG */
    lags();
#ifdef DEBUG
    std::cerr << "Checking if model is static\n";
#endif /* DEBUG */
    check_static();
    terminate_on_errors();
    if (m_verb) {
        if (m_static) {
            write_model_info("model is static");
        } else {
            if (m_deter) {
                write_model_info("model is dynamic, deterministic");
            } else {
                write_model_info("model is dynamic, stochastic");
            }
        }
    }
#ifdef DEBUG
    std::cerr << "Deriving FOCs\n";
#endif /* DEBUG */
    focs();
#ifdef DEBUG
    std::cerr << "Collecting shocks\n";
#endif /* DEBUG */
    collect_shocks();
#ifdef DEBUG
    std::cerr << "Collecting variables and parameters\n";
#endif /* DEBUG */
    collect_vp();
#ifdef DEBUG
    std::cerr << "Collecting Lagrange multipliers\n";
#endif /* DEBUG */
    collect_lagr();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Collecting model equations\n";
#endif /* DEBUG */
    collect_eq();
#ifdef DEBUG
    std::cerr << "Collecting calibration equations\n";
#endif /* DEBUG */
    collect_calibr();
    terminate_on_errors();
    if (m_verb) {
        write_model_info("model has " + num2str((unsigned) m_eqs.size())
                         + " equations with " + num2str((unsigned) m_vars.size())
                         + " variables");
        write_model_info("model has " + num2str((unsigned) m_calibr.size())
                         + " calibrating equations and " + num2str((unsigned) m_params_calibr.size())
                         + " non-free (calibrated) parameters");
    }
#ifdef DEBUG
    std::cerr << "Reducing model equations\n";
#endif /* DEBUG */
    check_red_vars();
    terminate_on_errors();
    reduce();
    terminate_on_errors();
    if (m_verb) {
        write_model_info("after reduction the model has " + num2str((unsigned) m_eqs.size())
                         + " equations with " + num2str((unsigned) m_vars.size())
                         + " variables");
    }
#ifdef DEBUG
    std::cerr << "Constructing variables / equations equations map\n";
#endif /* DEBUG */
    var_eq_map();
#ifdef DEBUG
    std::cerr << "Constructing shocks / equations map\n";
#endif /* DEBUG */
    shock_eq_map();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Determining steady state equations\n";
#endif /* DEBUG */
    stst();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Constructing variables / calibrating equations map\n";
#endif /* DEBUG */
    var_ceq_map();
#ifdef DEBUG
    std::cerr << "Constructing parameter / equations, calibrating equations maps\n";
#endif /* DEBUG */
    par_eq_map();
    par_ceq_map();
#ifdef DEBUG
    std::cerr << "Determining steady state equations Jacobian\n";
#endif /* DEBUG */
    ss_jacob();
#ifdef DEBUG
    std::cerr << "Differentiating equations for 1st order perturbation\n";
#endif /* DEBUG */
    diff_eqs();
}


void
Model::write_logf() const
{
    std::string full_name = m_path + m_name + ".model.log";
#ifdef DEBUG
    std::cerr << "Writing logfile to: \'" << full_name << "\'\n";
#endif /* DEBUG */
    std::ofstream logfile(full_name.c_str());
    if (!logfile.good()) {
        report_errors("(gEcon error): failed opening logfile \'" + full_name
                      + "\' for writing");
    }
    write_log(logfile);
    if (!logfile.good()) {
        report_errors("(gEcon error): failed writing logfile \'" + full_name
                      + "\'");
    } else if (m_verb) {
        write_info("logfile written to \'" + full_name + "\'");
    }

}


namespace {

std::string
time_str()
{
    std::string ts, mo, da, ho, mi, se;
    time_t tt = time(0);
    struct tm *now = localtime(&tt);
    mo = (now->tm_mon < 9) ? '0' + num2str(now->tm_mon + 1) : num2str(now->tm_mon + 1);
    da = (now->tm_mday < 10) ? '0' + num2str(now->tm_mday) : num2str(now->tm_mday);
    ho = (now->tm_hour < 10) ? '0' + num2str(now->tm_hour) : num2str(now->tm_hour);
    mi = (now->tm_min < 10) ? '0' + num2str(now->tm_min) : num2str(now->tm_min);
    se = (now->tm_sec < 10) ? '0' + num2str(now->tm_sec) : num2str(now->tm_sec);
    ts = num2str(now->tm_year + 1900) + '-' + mo + '-' + da
        + ' ' + ho + ':' + mi + ':' + se;
    return ts;
}


std::string
info_str()
{
    return "Generated on " + time_str() + " by gEcon ver. " + gecon_ver_str();
}

} /* namespace */



void
Model::write_log(std::ostream &logfile) const
{
    logfile << info_str() << "\n\n";
    logfile << "Model name: " << m_name << "\n\n";

    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        m_blocks[i].write_logfile(logfile, m_static);
    }

    set_ex::const_iterator it;
    std::string tab("    ");
    print_flag pflag = (m_static) ? DROP_T : DEFAULT;

    if (m_vars.size()) {
        logfile << "Variables (" << m_vars.size() << "):\n";
        it = m_vars.begin();
        logfile << tab << it->str(pflag);
        for (++it; it != m_vars.end(); ++it) {
            logfile << ", "<< it->str(pflag);
        }
        logfile << "\n\n";
    }

    if (m_shocks.size()) {
        logfile << "Shocks (" << m_shocks.size() << "):\n";
        it = m_shocks.begin();
        logfile << tab << it->str(pflag);
        for (++it; it != m_shocks.end(); ++it) {
            logfile << ", "<< it->str(pflag);
        }
        logfile << "\n\n";
    }

    if (m_params.size()) {
        logfile << "Parameters (" << m_params.size() << "):\n";
        it = m_params.begin();
        logfile << tab << it->str(pflag);
        for (++it; it != m_params.end(); ++it) {
            logfile << ", "<< it->str(pflag);
        }
        logfile << "\n\n";
    }

    if (m_params_free.size()) {
        logfile << "Free parameters (" << m_params_free.size() << "):\n";
        it = m_params_free.begin();
        logfile << tab << it->str(pflag);
        for (++it; it != m_params_free.end(); ++it) {
            logfile << ", "<< it->str(pflag);
        }
        logfile << "\n\n";
    }

    if (m_params_calibr.size()) {
        logfile << "Calibrated parameters (" << m_params_calibr.size() << "):\n";
        it = m_params_calibr.begin();
        logfile << tab << it->str(pflag);
        for (++it; it != m_params_calibr.end(); ++it) {
            logfile << ", "<< it->str(pflag);
        }
        logfile << "\n\n";
    }

    unsigned i;
    if (m_eqs.size()) {
        logfile << "Equations (" << m_eqs.size() << "):\n";
        for (it = m_eqs.begin(), i = 1; it != m_eqs.end(); ++it, ++i) {
            logfile << " (" << i << ")  " << it->str(pflag) << " = 0\n";
        }
        logfile << "\n";
    }

    if (!m_static && m_ss.size()) {
        logfile << "Steady state equations (" << m_eqs.size() << "):\n";
        for (unsigned i = 0; i < m_ss.size(); ++i) {
            logfile << " (" << (i + 1) << ")  " << m_ss[i].str(pflag) << " = 0\n";
        }
        logfile << "\n";
    }

    if (m_calibr.size()) {
        logfile << "Calibration equations (" << m_calibr.size() << "):\n";
        for (it = m_calibr.begin(), i = 1; it != m_calibr.end(); ++it, ++i) {
            logfile << " (" << i << ")  " << it->str(pflag) << " = 0\n";
        }
        logfile << "\n";
    }

    if (m_params_free_set.size()) {
        logfile << "Parameter settings (" << m_params_free_set.size() << "):\n";
        map_ex_ex::const_iterator itm;
        for (itm = m_params_free_set.begin(), i = 1; itm != m_params_free_set.end(); ++itm, ++i) {
            logfile << " (" << i << ")  " << itm->first.str(pflag) << " = "
                    << itm->second.str(pflag) << "\n";
        }
        logfile << "\n";
    }
}



void
Model::write_R(bool output_long) const
{
    std::string full_name = m_path + m_name + ".model.R";
#ifdef DEBUG
    std::cerr << "Writing R code to file: \'" << full_name << "\'\n";
#endif /* DEBUG */
    std::ofstream R(full_name.c_str());
    if (!R.good()) {
        report_errors("(gEcon error): failed opening R file \'" + full_name
                      + "\' for writing");
    }
    set_ex::const_iterator it;
    std::string tab("    ");
    unsigned index;
    unsigned n_v = m_vars.size(), n_s = m_shocks.size(),
             n_c = m_params_calibr.size(), n_f = m_params_free.size();

    R << "# " << info_str() << "\n# Model name: " << m_name << "\n\n";

    R << "# info\ninfo__ <- c(\"" << m_name << "\", \""
      << m_path << m_name << "\", \""
      << time_str() << "\")\n\n";

    R << "# variables\n";
    R << "variables__ <- c(";
    it = m_vars.begin();
    R << '\"' << it->str(DROP_T) << '\"';
    for (++it; it != m_vars.end(); ++it) {
        R << ",\n                 \"" << it->str(DROP_T) << '\"';
    }
    R << ")\n\n";

    R << "# shocks\n";
    if (n_s) {
        R << "shocks__ <- c(";
        it = m_shocks.begin();
        R << '\"' << it->str(DROP_T) << '\"';
        for (++it; it != m_shocks.end(); ++it) {
            R << ",\n              \"" << it->str(DROP_T) << '\"';
        }
        R << ")\n\n";
    } else {
        R << "shocks__ <- character(0)\n\n";
    }

    R << "# parameters\n";
    if (m_params.size()) {
    R << "parameters__ <- c(";
        it = m_params.begin();
        R << '\"' << it->str() << '\"';
        for (++it; it != m_params.end(); ++it) {
            R << ",\n                  \"" << it->str() << '\"';
        }
        R << ")\n\n";
    } else {
        R << "parameters__ <- character(0)\n\n";
    }

    R << "# free parameters\n";
    if (m_params_free.size()) {
    R << "parameters_free__ <- c(";
        it = m_params_free.begin();
        R << '\"' << it->str() << '\"';
        for (++it; it != m_params_free.end(); ++it) {
            R << ",\n                       \"" << it->str() << '\"';
        }
        R << ")\n\n";
    } else {
        R << "parameters_free__ <- character(0)\n\n";
    }


    R << "# free parameters' values\n";
    if (m_params_free.size()) {
    R << "parameters_free_val__ <- c(";
        it = m_params_free.begin();
        map_ex_ex::const_iterator mit;
        if ((mit = m_params_free_set.find(*it)) != m_params_free_set.end()) {
            R << mit->second.str();
        } else {
            R << "NA";
        }
        for (++it; it != m_params_free.end(); ++it) {
            if ((mit = m_params_free_set.find(*it)) != m_params_free_set.end()) {
                R << ",\n                           " << mit->second.str();
            } else {
                R << ",\n                           NA";
            }
        }
        R << ")\n\n";
    } else {
        R << "parameters_free_val__ <- numeric(0)\n\n";
    }

    print_flag pflag = (m_static) ? DROP_T : DEFAULT;
    R << "# equations\n";
    if (true) {
        R << "equations__ <- c(";
        it = m_eqs.begin();
        R << '\"' << it->str(pflag) << " = 0\"";
        for (++it; it != m_eqs.end(); ++it) {
            R << ",\n                 \"" << it->str(pflag) << " = 0\"";
        }
        R << ")\n\n";
    } else {
        R << "equations__ <- character(0)\n\n";
    }

    R << "# calibrating equations\n";
    if (m_calibr.size()) {
        R << "calibr_equations__ <- c(";
        it = m_calibr.begin();
        R << '\"' << it->str(pflag) << " = 0\"";
        for (++it; it != m_calibr.end(); ++it) {
            R << ",\n                        \"" << it->str(pflag) << " = 0\"";
        }
        R << ")\n\n";
    } else {
        R << "calibr_equations__ <- character(0)\n\n";
    }

    std::map<std::pair<int, int>, unsigned>::const_iterator itim;
    R << "# variables / equations map\n";
	R << "vareqmap__ <- sparseMatrix(i = c(";
    itim = m_var_eq_map.begin();
    R << itim->first.first;
    for (++itim; itim != m_var_eq_map.end(); ++itim) R << ", " << itim->first.first;
    R << "),\n                           j = c(";
    itim = m_var_eq_map.begin();
    R << itim->first.second;
    for (++itim; itim != m_var_eq_map.end(); ++itim) R << ", " << itim->first.second;
    R << "),\n                           x = c(";
    itim = m_var_eq_map.begin();
    R << itim->second;
    for (++itim; itim != m_var_eq_map.end(); ++itim) R << ", " << itim->second;
    R << "),\n                           dims = c(" << n_v << ", " << n_v << "))\n\n";

    std::set<std::pair<int, int> >::const_iterator itis;

    R << "# variables / calibrating equations map\n";
    if (m_var_ceq_map.size()) {
        R << "varcalibreqmap__ <- sparseMatrix(i = c(";
        itis = m_var_ceq_map.begin();
        R << itis->first;
        for (++itis; itis != m_var_ceq_map.end(); ++itis) R << ", " << itis->first;
        R << "),\n                                 j = c(";
        itis = m_var_ceq_map.begin();
        R << itis->second;
        for (++itis; itis != m_var_ceq_map.end(); ++itis) R << ", " << itis->second;
        R << "),\n                                 x = rep(1, " << m_var_ceq_map.size();
        R << "), dims = c(" << n_c << ", " << n_v << "))\n\n";
    } else {
        R << "varcalibreqmap__ <- sparseMatrix(i = NULL, j = NULL, dims = c(";
        R << n_c << ", " << n_v << "))\n\n";
    }

    R << "# calibrated parameters / equations map\n";
    if (m_cpar_eq_map.size()) {
        R << "calibrpareqmap__ <- sparseMatrix(i = c(";
        itis = m_cpar_eq_map.begin();
        R << itis->first;
        for (++itis; itis != m_cpar_eq_map.end(); ++itis) R << ", " << itis->first;
        R << "),\n                                 j = c(";
        itis = m_cpar_eq_map.begin();
        R << itis->second;
        for (++itis; itis != m_cpar_eq_map.end(); ++itis) R << ", " << itis->second;
        R << "),\n                                 x = rep(1, " << m_cpar_eq_map.size();
        R << "), dims = c(" << n_v << ", " << n_c << "))\n\n";
    } else {
        R << "calibrpareqmap__ <- sparseMatrix(i = NULL, j = NULL, dims = c(";
        R << n_v << ", " << n_c << "))\n\n";
    }

    R << "# calibrated parameters / calibrating equations map\n";
    if (m_cpar_ceq_map.size()) {
        R << "calibrparcalibreqmap__ <- sparseMatrix(i = c(";
        itis = m_cpar_ceq_map.begin();
        R << itis->first;
        for (++itis; itis != m_cpar_ceq_map.end(); ++itis) R << ", " << itis->first;
        R << "),\n                                       j = c(";
        itis = m_cpar_ceq_map.begin();
        R << itis->second;
        for (++itis; itis != m_cpar_ceq_map.end(); ++itis) R << ", " << itis->second;
        R << "),\n                                       x = rep(1, " << m_cpar_ceq_map.size();
        R << "), dims = c(" << n_c << ", " << n_c << "))\n\n";
    } else {
        R << "calibrparcalibreqmap__ <- sparseMatrix(i = NULL, j = NULL, dims = c(";
        R << n_c << ", " << n_c << "))\n\n";
    }

    R << "# free parameters / equations map\n";
    if (m_fpar_eq_map.size()) {
        R << "freepareqmap__ <- sparseMatrix(i = c(";
        itis = m_fpar_eq_map.begin();
        R << itis->first;
        for (++itis; itis != m_fpar_eq_map.end(); ++itis) R << ", " << itis->first;
        R << "),\n                               j = c(";
        itis = m_fpar_eq_map.begin();
        R << itis->second;
        for (++itis; itis != m_fpar_eq_map.end(); ++itis) R << ", " << itis->second;
        R << "),\n                               x = rep(1, " << m_fpar_eq_map.size();
        R << "), dims = c(" << n_v << ", " << n_f << "))\n\n";
    } else {
        R << "freepareqmap__ <- sparseMatrix(i = NULL, j = NULL, dims = c(";
        R << n_v << ", " << n_f << "))\n\n";
    }

    R << "# free parameters / calibrating equations map\n";
    if (m_fpar_ceq_map.size()) {
        R << "freeparcalibreqmap__ <- sparseMatrix(i = c(";
        itis = m_fpar_ceq_map.begin();
        R << itis->first;
        for (++itis; itis != m_fpar_ceq_map.end(); ++itis) R << ", " << itis->first;
        R << "),\n                                     j = c(";
        itis = m_fpar_ceq_map.begin();
        R << itis->second;
        for (++itis; itis != m_fpar_ceq_map.end(); ++itis) R << ", " << itis->second;
        R << "),\n                                     x = rep(1, " << m_fpar_ceq_map.size();
        R << "), dims = c(" << n_c << ", " << n_f << "))\n\n";
    } else {
        R << "freeparcalibreqmap__ <- sparseMatrix(i = NULL, j = NULL, dims = c(";
        R << n_c << ", " << n_f << "))\n\n";
    }

    R << "# shocks / equations map\n";
    if (m_shock_eq_map.size()) {
        R << "shockeqmap__ <- sparseMatrix(i = c(";
        itis = m_shock_eq_map.begin();
        R << itis->first;
        for (++itis; itis != m_shock_eq_map.end(); ++itis) R << ", " << itis->first;
        R << "),\n                             j = c(";
        itis = m_shock_eq_map.begin();
        R << itis->second;
        for (++itis; itis != m_shock_eq_map.end(); ++itis) R << ", " << itis->second;
        R << "),\n                             x = rep(1, " << m_shock_eq_map.size();
        R << "), dims = c(" << n_v << ", " << n_s << "))\n\n";
    } else {
        R << "shockeqmap__ <- sparseMatrix(i = NULL, j = NULL, dims = c(";
        R << n_v << ", " << n_s << "))\n\n";
    }

    // str map
    map_str_str mss;
    if (!m_output_long) {
        for (it = m_vars.begin(), index = 1; it != m_vars.end(); ++it, ++index) {
            mss[it->str(DROP_T)] = "v[" + num2str(index) + "]";
        }
        for (it = m_params_calibr.begin(), index = 1; it != m_params_calibr.end(); ++it, ++index) {
            mss[it->str()] = "pc[" + num2str(index) + "]";
        }
        for (it = m_params_free.begin(), index = 1; it != m_params_free.end(); ++it, ++index) {
            mss[it->str()] = "pf[" + num2str(index) + "]";
        }
    }
    // settings for printing R functions
    pflag = (m_static) ? DROP_T : CONVERT_T;

    R << "# steady state equations\n";
    R << "ss_eq__ <- function(v, pc, pf)\n";
    R << "{\n";
    if (m_output_long) {
        for (it = m_vars.begin(), index = 1; it != m_vars.end(); ++it, ++index) {
            R << tab << ss(*it).str(pflag) << " = v[" << index << "]\n" ;
        }
        if (m_vars.size()) R << '\n';
        for (it = m_params_calibr.begin(), index = 1; it != m_params_calibr.end(); ++it, ++index) {
            R << tab << it->str() << " = pc[" << index << "]\n" ;
        }
        if (m_params_calibr.size()) R << '\n';
        for (it = m_params_free.begin(), index = 1; it != m_params_free.end(); ++it, ++index) {
            R << tab << it->str() << " = pf[" << index << "]\n" ;
        }
        if (m_params_free.size()) R << '\n';
        R << tab << "r <- numeric(" << m_eqs.size() << ")\n";
        for (index = 0; index != m_ss.size(); ++index) {
            R << tab << "r[" << (index + 1) << "] = " << m_ss[index].str(pflag) << "\n" ;
        }
    } else {
        R << tab << "r <- numeric(" << m_eqs.size() << ")\n";
        for (index = 0; index != m_ss.size(); ++index) {
            R << tab << "r[" << (index + 1) << "] = " << m_ss[index].strmap(mss) << "\n" ;
        }
    }
    R << "\n" << tab << "return(r)" << "\n}\n\n";

    R << "# calibration equations\n";
    R << "calibr_eq__ <- function(v, pc, pf)\n";
    R << "{\n";
    if (m_output_long) {
        for (it = m_vars.begin(), index = 1; it != m_vars.end(); ++it, ++index) {
            R << tab << ss(*it).str(pflag) << " = v[" << index << "]\n" ;
        }
        if (m_vars.size()) R << '\n';
        for (it = m_params_calibr.begin(), index = 1; it != m_params_calibr.end(); ++it, ++index) {
            R << tab << it->str() << " = pc[" << index << "]\n" ;
        }
        if (m_params_calibr.size()) R << '\n';
        for (it = m_params_free.begin(), index = 1; it != m_params_free.end(); ++it, ++index) {
            R << tab << it->str() << " = pf[" << index << "]\n" ;
        }
        if (m_params_free.size()) R << '\n';
        R << tab << "r <- numeric(" << m_calibr.size() << ")\n";
        for (it = m_calibr.begin(), index = 1; it != m_calibr.end(); ++it, ++index) {
            R << tab << "r[" << index << "] = " << it->str(pflag) << "\n" ;
        }
    } else {
        R << tab << "r <- numeric(" << m_calibr.size() << ")\n";
        for (it = m_calibr.begin(), index = 1; it != m_calibr.end(); ++it, ++index) {
            R << tab << "r[" << index << "] = " << it->strmap(mss) << "\n" ;
        }
    }
    R << '\n' << tab << "return(r)" << "\n}\n\n";

    std::map<std::pair<int, int>, ex>::const_iterator itm;
    R << "# steady state and calibration equations Jacobian\n";
    R << "ss_calibr_eq_jacob__ <- function(v, pc, pf)\n";
    R << "{\n";
    if (m_output_long) {
        for (it = m_vars.begin(), index = 1; it != m_vars.end(); ++it, ++index) {
            R << tab << ss(*it).str(pflag) << " = v[" << index << "]\n" ;
        }
        if (m_vars.size()) R << '\n';
        for (it = m_params_calibr.begin(), index = 1; it != m_params_calibr.end(); ++it, ++index) {
            R << tab << it->str() << " = pc[" << index << "]\n" ;
        }
        if (m_params_calibr.size()) R << '\n';
        for (it = m_params_free.begin(), index = 1; it != m_params_free.end(); ++it, ++index) {
            R << tab << it->str() << " = pf[" << index << "]\n" ;
        }
        if (m_params_free.size()) R << '\n';
        R << tab << "jacob <- Matrix(0, nrow = "
          << (m_eqs.size() + m_calibr.size()) << ", ncol = "
          << (m_vars.size() + m_params_calibr.size()) << ", sparse = TRUE)\n";
        for (itm = m_jacob_ss_calibr.begin(); itm != m_jacob_ss_calibr.end(); ++itm) {
            R << tab << "jacob[" << itm->first.first << ", " << itm ->first.second
            << "] = " << itm->second.str(pflag) << '\n';
        }
    } else {
        R << tab << "jacob <- Matrix(0, nrow = "
          << (m_eqs.size() + m_calibr.size()) << ", ncol = "
          << (m_vars.size() + m_params_calibr.size()) << ", sparse = TRUE)\n";
        for (itm = m_jacob_ss_calibr.begin(); itm != m_jacob_ss_calibr.end(); ++itm) {
            R << tab << "jacob[" << itm->first.first << ", " << itm ->first.second
            << "] = " << itm->second.strmap(mss) << '\n';
        }
    }
    R << "\n" << tab << "return(jacob)" << "\n}\n\n";

    R << "# 1st order perturbation\n";
    R << "pert1__ <- function(v, pc, pf)\n";
    R << "{\n";
    if (m_output_long) {
        for (it = m_vars.begin(), index = 1; it != m_vars.end(); ++it, ++index) {
            R << tab << ss(*it).str(pflag) << " = v[" << index << "]\n" ;
        }
        if (m_vars.size()) R << '\n';
        for (it = m_params_calibr.begin(), index = 1; it != m_params_calibr.end(); ++it, ++index) {
            R << tab << it->str() << " = pc[" << index << "]\n" ;
        }
        if (m_params_calibr.size()) R << '\n';
        for (it = m_params_free.begin(), index = 1; it != m_params_free.end(); ++it, ++index) {
            R << tab << it->str() << " = pf[" << index << "]\n" ;
        }
        if (m_params_free.size()) R << '\n';
    }

    R << tab << "Atm1 <- Matrix(0, nrow = " << n_v << ", ncol = " << n_v
      << ", sparse = TRUE)\n";
    if (m_output_long) {
        for (itm = m_Atm1.begin(); itm != m_Atm1.end(); ++itm) {
            R << tab << "Atm1[" << itm->first.first << ", " << itm ->first.second
            << "] = " << itm->second.str(pflag) << '\n';
        }
    } else {
        for (itm = m_Atm1.begin(); itm != m_Atm1.end(); ++itm) {
            R << tab << "Atm1[" << itm->first.first << ", " << itm ->first.second
            << "] = " << itm->second.strmap(mss) << '\n';
        }
    }
    R << '\n';

    R << tab << "At <- Matrix(0, nrow = " << n_v << ", ncol = " << n_v
      << ", sparse = TRUE)\n";
    if (m_output_long) {
        for (itm = m_At.begin(); itm != m_At.end(); ++itm) {
            R << tab << "At[" << itm->first.first << ", " << itm ->first.second
            << "] = " << itm->second.str(pflag) << '\n';
        }
    } else {
        for (itm = m_At.begin(); itm != m_At.end(); ++itm) {
            R << tab << "At[" << itm->first.first << ", " << itm ->first.second
            << "] = " << itm->second.strmap(mss) << '\n';
        }
    }
    R << '\n';

    R << tab << "Atp1 <- Matrix(0, nrow = " << n_v << ", ncol = " << n_v
      << ", sparse = TRUE)\n";
    if (m_output_long) {
        for (itm = m_Atp1.begin(); itm != m_Atp1.end(); ++itm) {
            R << tab << "Atp1[" << itm->first.first << ", " << itm ->first.second
            << "] = " << itm->second.str(pflag) << '\n';
        }
    } else {
        for (itm = m_Atp1.begin(); itm != m_Atp1.end(); ++itm) {
            R << tab << "Atp1[" << itm->first.first << ", " << itm ->first.second
            << "] = " << itm->second.strmap(mss) << '\n';
        }
    }
    R << '\n';

	R << tab << "Aeps <- Matrix(0, nrow = " << n_v << ", ncol = " << n_s
      << ", sparse = TRUE)\n";
    if (m_output_long) {
        for (itm = m_Aeps.begin(); itm != m_Aeps.end(); ++itm) {
            R << tab << "Aeps[" << itm->first.first << ", " << itm ->first.second
            << "] = " << itm->second.str(pflag) << '\n';
        }
    } else {
        for (itm = m_Aeps.begin(); itm != m_Aeps.end(); ++itm) {
            R << tab << "Aeps[" << itm->first.first << ", " << itm ->first.second
            << "] = " << itm->second.strmap(mss) << '\n';
        }
    }

    R << '\n' << tab << "return(list(Atm1, At, Atp1, Aeps))" << "\n}\n\n";

    R << "# create model object\n"
      << "gecon_model(model_info = info__,\n"
      << "            map_var = variables__,\n"
      << "            map_shocks = shocks__,\n"
      << "            map_params = parameters__,\n"
      << "            map_params_free = parameters_free__,\n"
      << "            map_params_free_val = parameters_free_val__,\n"
      << "            map_equations = equations__,\n"
      << "            map_calibr_equations = calibr_equations__,\n"
      << "            var_eq_map = vareqmap__,\n"
      << "            shock_eq_map = shockeqmap__,\n"
      << "            var_ceq_map = varcalibreqmap__,\n"
      << "            cpar_eq_map = calibrpareqmap__,\n"
      << "            cpar_ceq_map = calibrparcalibreqmap__,\n"
      << "            fpar_eq_map = freepareqmap__,\n"
      << "            fpar_ceq_map = freeparcalibreqmap__,\n"
      << "            ss_function = ss_eq__,\n"
      << "            calibr_function = calibr_eq__,\n"
      << "            ss_calibr_function_jac = ss_calibr_eq_jacob__,\n"
      << "            pert = pert1__)\n\n";


    if (!R.good()) {
        report_errors("(gEcon error): failed writing R file \'" + full_name
                      + "\'");
    } else if (m_verb) {
        write_info("R code written to \'" + full_name + "\'");
    }
}


void
Model::write_LaTeX() const
{
    std::string full_name = m_path + m_name + ".tex";
#ifdef DEBUG
    std::cerr << "Writing LaTeX documentation to file: \'" << full_name << "\'\n";
#endif /* DEBUG */

    std::ofstream latex(full_name.c_str());
    if (!latex.good()) {
        report_errors("(gEcon error): failed opening LaTeX file \'" + full_name
                      + "\' for writing");
    }
    latex << "% " << info_str() << "\n% Model name: " << m_name << "\n\n";
    latex << "\
\\documentclass[a4]{article}\n\
\\usepackage[utf8]{inputenc}\n\
\\usepackage{color}\n\
\\usepackage{graphicx}\n\
\\usepackage{epstopdf}\n\
\\usepackage{amsmath}\n\
\\usepackage{amssymb}\n\
\\numberwithin{equation}{section}\n\
\\usepackage[top = 2.5cm, bottom=2.5cm, left = 2.0cm, right=2.0cm]{geometry}\n\
\\begin{document}\n\n";
    latex << "\\begin{flushleft}{\\large\n";
    latex << "Generated  on " + time_str() + " by \\texttt{gEcon} version " + gecon_ver_str() + "\\\\\n";
    latex << "Model name: \\verb+" << m_name << "+\n";
    latex << "}\\end{flushleft}\n\n";
    latex << "\\input{" << m_name << ".model.tex}\n\n";
    latex << "\\input{" << m_name << ".results.tex}\n\n";
    latex << "\\end{document}\n\n";
    if (!latex.good()) {
        report_errors("(gEcon error): failed writing LaTeX file \'" + full_name
                      + "\'");
    }
    latex.close();

    full_name = m_path + m_name + ".results.tex";
    latex.open(full_name.c_str());
    if (!latex.good()) {
        report_errors("(gEcon error): failed opening LaTeX file \'" + full_name
                      + "\' for writing");
    }
    latex << "% " << info_str() << "\n% Model name: " << m_name << "\n\n";
    if (!latex.good()) {
        report_errors("(gEcon error): failed writing LaTeX file \'" + full_name
                      + "\'");
    }
    latex.close();

    full_name = m_path + m_name + ".model.tex";
    latex.open(full_name.c_str());
    if (!latex.good()) {
        report_errors("(gEcon error): failed opening LaTeX file \'" + full_name
                      + "\' for writing");
    }
    latex << "% " << info_str() << "\n% Model name: " << m_name << "\n\n";

    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        m_blocks[i].write_LaTeX(latex, m_static);
    }

    set_ex::const_iterator it, ite;
    print_flag pflag = (m_static) ? DROP_T : DEFAULT;

    latex << "\\section{Equilibrium relationships}\n\n";
    it = m_eqs.begin();
    ite = m_eqs.end();
    for (; it != ite; ++it) {
        latex << "\\begin{equation}\n";
        latex << it->tex(pflag) << " = 0\n";
        latex << "\\end{equation}\n";
    }
    latex << "\n\n\n";

    if (!m_static) {
        latex << "\\section{Steady state relationships}\n\n";
        for (unsigned i = 0; i < m_ss.size(); ++i) {
            latex << "\\begin{equation}\n";
            latex << m_ss[i].tex(pflag) << " = 0\n";
            latex << "\\end{equation}\n";
        }
        latex << "\n\n\n";
    }

    if (m_calibr.size()) {
        latex << "\\section{Calibrating equations}\n\n";
        it = m_calibr.begin();
        ite = m_calibr.end();
        for (; it != ite; ++it) {
            latex << "\\begin{equation}\n";
            latex << it->tex(pflag) << " = 0\n";
            latex << "\\end{equation}\n";
        }
    }
    latex << "\n\n\n";

    if (m_params_free_set.size()) {
        latex << "\\section{Parameter settings}\n\n";
        map_ex_ex::const_iterator itm, itme;
        itm = m_params_free_set.begin();
        itme = m_params_free_set.end();
        for (; itm != itme; ++itm) {
            latex << "\\begin{equation}\n";
            latex << itm->first.tex(pflag) << " = " << itm->second.tex(pflag) << "\n";
            latex << "\\end{equation}\n";
        }
    }
    latex << "\n\n";

    if (!latex.good()) {
        report_errors("(gEcon error): failed writing LaTeX file \'" + full_name
                      + "\'");
    } else if (m_verb) {
        write_info("LaTeX documentation written to \'" + m_path + m_name
                   + ".tex\' and \'" + full_name + "\'; created file \'"
                   + m_path + m_name + ".results.tex\'");
    }
}




void
Model::write() const
{
#ifdef R_DLL
//     if (!output_R) {
//         report_warns("(gEcon warning): ignoring option 'output R = FALSE;'");
//     }
    write_R(m_output_long);
#else /* R_DLL */
    if (m_output_R) write_R(m_output_long);
#endif /* R_DLL */
    if (m_output_logf) write_logf();
    if (m_output_LaTeX) write_LaTeX();

}


void
Model::clear()
{
    *this = Model();
}



