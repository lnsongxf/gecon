/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ops.h
 * \brief Operations.
 */

#ifndef SYMBOLIC_OPS_H

#define SYMBOLIC_OPS_H

#include <decl.h>
#include <ptr_base.h>
#include <string>


namespace symbolic {
namespace internal {

/// Expression reduction.
ptr_base reduce(const ptr_base&);
/// Unary minus.
ptr_base mk_neg(const ptr_base &lhs);
/// Addition
ptr_base mk_add(const ptr_base &lhs, const ptr_base &rhs);
/// Addition
ptr_base mk_add(const num_ex_pair_vec &ops);
/// Subtraction.
ptr_base mk_sub(const ptr_base &lhs, const ptr_base &rhs);
/// Multiplication.
ptr_base mk_mul(const ptr_base &lhs, const ptr_base &rhs);
/// Multiplication.
ptr_base mk_mul(const num_ex_pair_vec &ops);
/// Division.
ptr_base mk_div(const ptr_base &lhs, const ptr_base &rhs);
/// Power.
ptr_base mk_pow(const ptr_base &lhs, const ptr_base &rhs);
/// Conditional expected value.
ptr_base mk_E(const ptr_base &p, int l);
/// Function.
ptr_base mk_func(func_code c, const ptr_base &arg);

/// Lag expression.
ptr_base lag(const ptr_base &p, int l);
/// Steady state.
ptr_base ss(const ptr_base &p);
/// Drop expectations
ptr_base drop_Es(const ptr_base &p);
/// Substitution.
ptr_base subst(const ptr_base &e, const ptr_base &what, const ptr_base &with,
               bool all_leads_lags = true);
/// Given variable or paramter create new one by appending string to its name
ptr_base append_name(const ptr_base &p, const std::string &s);

/// Does expression contain conditional expectations?
bool has_Es(const ptr_base &e);
/// Find expressions under expected value
void find_Es(const ptr_base&, set_ex&);

/// Collect variables and parameters.
void collect(const ptr_base&, set_ex &vars, set_ex &parms);
/// Collect variables in lag > 1
void collect_lags(const ptr_base &p, map_ex_int &map);

/// Differentiate
ptr_base mk_diff(const ptr_base &e, const ptr_base &v);


} /* namespace internal */
} /* namespace symbolic */

#endif /* SYMBOLIC_OPS_H */
