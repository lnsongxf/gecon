/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

 /** \file ops.cpp
 * \brief Operations.
 */


#include <ex_num.h>
#include <ex_symb.h>
#include <ex_vart.h>
#include <ex_add.h>
#include <ex_mul.h>
#include <ex_pow.h>
#include <ex_func.h>
#include <ex_e.h>
#include <cmp.h>
#include <error.h>
#include <ops.h>
#include <iostream>
#include <cmath>
#include <climits>


using namespace symbolic;
using namespace symbolic::internal;




bool
symbolic::internal::has_Es(const ptr_base &p)
{
    unsigned t = p->type();
    if ((t == NUM) || (t == SYMB) || (t == VART)) {
        return false;
    } else if (t == EX) {
        return true;
    } else if (t == ADD) {
        unsigned i, n = p.get<ex_add>()->no_ops();
        for (i = 0; i < n; ++i) {
            if (has_Es(p.get<ex_add>()->get_ops()[i].second))
                return true;
        }
        return false;
    } else if (t == MUL) {
        unsigned i, n = p.get<ex_mul>()->no_ops();
        for (i = 0; i < n; ++i) {
            if (has_Es(p.get<ex_mul>()->get_ops()[i].second))
                return true;
        }
        return false;
    } else if (t == POW) {
        const ex_pow *pt = p.get<ex_pow>();
        if (has_Es(pt->get_base())) return true;
        if (has_Es(pt->get_exp())) return true;
        return false;
    } else if (t == FUN) {
        return has_Es(p.get<ex_func>()->get_arg());
    } else INTERNAL_ERROR
}



void
symbolic::internal::find_Es(const ptr_base &p, set_ex &sex)
{
    unsigned t = p->type();
    if ((t == NUM) || (t == SYMB) || (t == VART)) {
        return;
    } else if (t == EX) {
        ptr_base pe = p.get<ex_e>()->get_arg();
        int l = p.get<ex_e>()->get_lag();
        sex.insert(ex(lag(pe, -l)));
        find_Es(pe, sex);
        return;
    } else if (t == ADD) {
        const num_ex_pair_vec &args = p.get<ex_add>()->get_ops();
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            find_Es(args[i].second, sex);
        }
        return;
    } else if (t == MUL) {
        const num_ex_pair_vec &args = p.get<ex_mul>()->get_ops();
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            find_Es(args[i].second, sex);
        }
        return;
    } else if (t == POW) {
        const ex_pow *pp = p.get<ex_pow>();
        find_Es(pp->get_base(), sex);
        find_Es(pp->get_exp(), sex);
        return;
    } else if (t == FUN) {
        find_Es(p.get<ex_func>()->get_arg(), sex);
        return;
    } else INTERNAL_ERROR
}




void
symbolic::internal::collect(const ptr_base &p, set_ex &vars, set_ex &parms)
{
    unsigned t = p->type();
    if (t == NUM) {
        return;
    } else if (t == SYMB) {
        parms.insert(ex(p));
        return;
    } else if (t == VART) {
        vars.insert(ex(p.get<ex_vart>()->copy0()));
        return;
    } else if (t == EX) {
        ptr_base pe = p.get<ex_e>()->get_arg();
        collect(pe, vars, parms);
        return;
    } else if (t == ADD) {
        const num_ex_pair_vec &args = p.get<ex_add>()->get_ops();
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            collect(args[i].second, vars, parms);
        }
        return;
    } else if (t == MUL) {
        const num_ex_pair_vec &args = p.get<ex_mul>()->get_ops();
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            collect(args[i].second, vars, parms);
        }
        return;
    } else if (t == POW) {
        const ex_pow *pp = p.get<ex_pow>();
        collect(pp->get_base(), vars, parms);
        collect(pp->get_exp(), vars, parms);
        return;
    } else if (t == FUN) {
        collect(p.get<ex_func>()->get_arg(), vars, parms);
        return;
    } else INTERNAL_ERROR
}





void
symbolic::internal::collect_lags(const ptr_base &p, map_ex_int &map)
{
    unsigned t = p->type();
    if ((t == NUM) || (t == SYMB)) {
        return;
    } else if (t == VART) {
        int l;
        l = p.get<ex_vart>()->get_lag();
        if (l >= -1) return;
        ex v = ex(p.get<ex_vart>()->copy0());
        map_ex_int::iterator it = map.find(v);
        if (it != map.end()) {
            if (it->second > l) it->second = l;
        } else {
            map.insert(std::pair<ex, int>(v, l));
        }
        return;
    } else if (t == EX) {
        ptr_base pe = p.get<ex_e>()->get_arg();
        collect_lags(pe, map);
        return;
    } else if (t == ADD) {
        const num_ex_pair_vec &args = p.get<ex_add>()->get_ops();
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            collect_lags(args[i].second, map);
        }
        return;
    } else if (t == MUL) {
        const num_ex_pair_vec &args = p.get<ex_mul>()->get_ops();
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            collect_lags(args[i].second, map);
        }
        return;
    } else if (t == POW) {
        const ex_pow *pp = p.get<ex_pow>();
        collect_lags(pp->get_base(), map);
        collect_lags(pp->get_exp(), map);
        return;
    } else if (t == FUN) {
        collect_lags(p.get<ex_func>()->get_arg(), map);
        return;
    } else INTERNAL_ERROR
}












