/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2013         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2013         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex_e.cpp
 * \brief Expected value (conditional - time indexed).
 */


#include <error.h>
#include <ex_e.h>
#include <ops.h>
#include <cmp.h>
#include <utils.h>
#include <climits>


using namespace symbolic::internal;


ex_e::ex_e(const ptr_base &e, int l)
    : ex_base(EX|HAST), m_arg(e), m_lag(l)
{
}

ptr_base
ex_e::create(const ptr_base &e, int l)
{
    return ptr_base(new ex_e(e, l));
}


void
ex_e::destroy(ex_base *ptr)
{
    delete ptr;
}

ptr_base
ex_e::copy() const
{
    return ptr_base(new ex_e(m_arg, m_lag));
}


int
ex_e::compare(const ex_e &b) const
{
    if (m_lag < b.m_lag) return -1;
    if (m_lag > b.m_lag) return 1;
    return symbolic::internal::compare(m_arg, b.m_arg);
}


std::string
ex_e::str(print_flag pflag) const
{
    switch (pflag) {
        case DEFAULT:
            return "E[" + num2str(m_lag) + "][" + m_arg->str(pflag) + ']';
        case CONVERT_T_IDX:
            if (m_lag < 0) return "E_tm" + num2str(-m_lag) + '[' + m_arg->str(pflag) + ']';
            if (m_lag == 0) return "E_t[" + m_arg->str(pflag) + ']';
            return "E_tp" + num2str(m_lag) + '[' + m_arg->str(pflag) + ']';
        default:
            USER_ERROR("invalid print flag in ex_e::str()")
    }
}


std::string
ex_e::tex(print_flag pflag) const
{
    if (pflag != DEFAULT) USER_ERROR("invalid print flag in ex_e::tex()")
    std::string res;
    if (m_lag == 0) res = "\\mathrm{E}_{t}";
    else if (m_lag < 0) res = "\\mathrm{E}_{t" + num2str(m_lag) + '}';
    else res = "\\mathrm{E}_{t+" + num2str(m_lag) + '}';
    res += "\\left[";
    res += m_arg->tex(pflag);
    res += "\\right]";
    return res;
}


int
ex_e::get_lag_max(bool stop_on_E) const
{
    if (stop_on_E) return m_lag;
    return std::max(m_lag, m_arg->get_lag_max());
}


int
ex_e::get_lag_min(bool stop_on_E) const
{
    if (stop_on_E) return m_lag;
    return std::min(m_lag, m_arg->get_lag_min());
}


ptr_base
ex_e::subst(const ptr_base &what, const ptr_base &with, bool all_leads_lags) const
{
    if (what->type() == EX) {
        int l1 = m_lag, l2 = static_cast<const ex_e*>(what.get())->get_lag(), ld = l2 - l1;
        if (ld && (!all_leads_lags)) return mk_E(m_arg->subst(what, with, false), m_lag);
        if (!symbolic::internal::compare(symbolic::internal::lag(m_arg, ld),
            static_cast<const ex_e*>(what.get())->m_arg)) {
            return symbolic::internal::lag(with, -ld);
        }
    }

    return mk_E(m_arg->subst(what, with), m_lag);
}


ptr_base
ex_e::diff(const ptr_base &p) const
{
    return mk_E(m_arg->diff(p), m_lag);
}


ptr_base
ex_e::lag(int l) const
{
    if (l == INT_MIN) return symbolic::internal::lag(m_arg, l);
    return create(symbolic::internal::lag(m_arg, l), m_lag + l);
}








