/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2013         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2013         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file cmp.cpp
 * \brief Comparing expressions (used for sorting and reduction).
 */


#include <cmp.h>
#include <ex_num.h>
#include <ex_symb.h>
#include <ex_vart.h>
#include <ex_pow.h>
#include <ex_func.h>
#include <ex_e.h>
#include <ex_add.h>
#include <ex_mul.h>
#include <error.h>


using namespace symbolic::internal;



#define EXPAND_CASE(TYPE, CLASS) \
        case TYPE: \
            return static_cast<const CLASS*>(a.get())-> \
                   compare(*static_cast<const CLASS*>(b.get()));


int
symbolic::internal::compare(const ptr_base &a, const ptr_base &b)
{
    int c;
    unsigned t;

    if ((c = compareT(t = a->type(), b->type()))) return c;

    switch (t) {
        EXPAND_CASE(NUM, ex_num)
        EXPAND_CASE(SYMB, ex_symb)
        EXPAND_CASE(VART, ex_vart)
        EXPAND_CASE(EX, ex_e)
        EXPAND_CASE(POW, ex_pow)
        EXPAND_CASE(FUN, ex_func)
        EXPAND_CASE(ADD, ex_add)
        EXPAND_CASE(MUL, ex_mul)
        default:
            INTERNAL_ERROR
    }

    return 0;
}


































