/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2013         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2013         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex_base.cpp
 * \brief Abstract base class for expressions.
 */


#include <ex_base.h>
#include <ex_num.h>

using namespace symbolic;
using namespace symbolic::internal;


bool
ex_base::is0() const
{
    if (type() != NUM) return false;
    const ex_num *p = static_cast<const ex_num*>(this);
    return (p->val() == 0.);
}


bool
ex_base::is1() const
{
    if (type() != NUM) return false;
    const ex_num *p = static_cast<const ex_num*>(this);
    return (p->val() == 1.);
}


bool
ex_base::ism1() const
{
    if (type() != NUM) return false;
    const ex_num *p = static_cast<const ex_num*>(this);
    return (p->val() == -1.);
}


Number
ex_base::val() const
{
    if (type() != NUM) return 0./0.;
    return static_cast<const ex_num*>(this)->val();
}

