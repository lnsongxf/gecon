/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2013         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2013         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex_add.h
 * \brief Addition.
 */

#ifndef SYMBOLIC_EX_ADD_H

#define SYMBOLIC_EX_ADD_H


#include <ex_base.h>
#include <num_ex_pair_vec.h>
#include <helper.h>


namespace symbolic {
namespace internal {


/// Class representing addition operation
class ex_add : public ex_base {
  public:
    /// Constructor from an expression.
    explicit ex_add(const ptr_base &p);
    /// Constructor from a scalar / expression pair.
    ex_add(const Number &s, const ptr_base &p);
    /// Constructor from two arguments.
    ex_add(const ptr_base &a, const ptr_base &b);
    /// Constructor from num_ex_pair_vec
    explicit ex_add(const num_ex_pair_vec &ops, bool try_reduce = false);
    /// Destructor
    virtual ~ex_add() { ; }

    /// Comparison
    int compare(const ex_add&) const;

    /// Constructor from an expression.
    static ptr_base create(const ptr_base &p);
    /// Constructor from a scalar expression pair.
    static ptr_base create(const Number &s, const ptr_base &p);
    /// Constructor from two arguments.
    static ptr_base create(const ptr_base &a, const ptr_base &b);
    /// Constructor from num_ex_pair_vec.
    static ptr_base create(const num_ex_pair_vec &ops, bool try_reduce = false);

    /// Free memory (assumes that ptr is acutally pointer to ex_add)
    static void destroy(ex_base *ptr);

    /// String representation
    virtual std::string str(print_flag pflag) const;
    /// LaTeX string representation
    virtual std::string tex(print_flag pflag) const;
	/// Max lag in expression
	virtual int get_lag_max(bool stop_on_E = false) const;
	/// Min lag in expression
	virtual int get_lag_min(bool stop_on_E = false) const;
    /// Derivative wrt a variable
    virtual ptr_base diff(const ptr_base&) const;
    /// Substitution
    virtual ptr_base subst(const ptr_base &what, const ptr_base &with,
                           bool all_leads_lags = true) const;

    /// No. of arguments
    int no_args() const { return m_ops.size(); }

  private:
    // No default constructor
    ex_add() : ex_base(NUL) { ; }
    // Ops
    num_ex_pair_vec m_ops;

	void update_flags();

    friend ptr_base reduce(const ptr_base&);
    friend int compare(const ptr_base &a, const ptr_base &b);
	friend ptr_base mk_add(const ptr_base &lhs, const ptr_base &rhs);
	friend ptr_base mk_mul(const ptr_base &lhs, const ptr_base &rhs);
	friend ptr_base mk_pow(const ptr_base &lhs, const ptr_base &rhs);
    friend ptr_base lag(const ptr_base &p, int l);
	friend ptr_base ss(const ptr_base &p);
	friend ptr_base mk_E(const ptr_base &p, int l);
    friend bool has(const ptr_base &e, const ptr_base &what);
    friend bool hast(const ptr_base &p, const ptr_base &what);
    friend bool hasdifft(const ptr_base &p, const ptr_base &what);
    friend bool haslead(const ptr_base &p, const ptr_base &what);
    friend bool has_Es(const ptr_base &p);
    friend void find_Es(const ptr_base&, set_ex&);
    friend ptr_base drop_Es(const ptr_base&);
    friend void collect(const ptr_base &p, set_ex &vars, set_ex &parms);
    friend void collect_lags(const ptr_base &p, map_ex_int &map);
    friend void num_ex_pair_vec::reduce(ex_type t);
    friend triplet<bool, ex, ex> symbolic::find_subst(const ex &expression, const set_ex&);
    friend triplet<bool, ex, ex> symbolic::find_par_eq_num(const ex &expression);

    friend class symbolic::ex;

}; /* class ex_add */

} /* namespace internal */
} /* namespace symbolic */

#endif /* SYMBOLIC_EX_ADD_H */
