/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2013         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2013         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file cmp.h
 * \brief Comparing expressions (used for sorting and reduction).
 */

#ifndef SYMBOLIC_CMP_H

#define SYMBOLIC_CMP_H

#include <ptr_base.h>


namespace symbolic {
namespace internal {

int compare(const ptr_base &a, const ptr_base &b);

template <typename T>
inline
int
compareT(T a, T b)
{
    if (a < b) return -1;
    if (a > b) return 1;
    return 0;
}

} /* namespace internal */
} /* namespace symbolic */

#endif /* SYMBOLIC_CMP_H */
