/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2013         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2013         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex_base.h
 * \brief Abstract base class for expressions.
 */

#ifndef SYMBOLIC_EX_BASE_H

#define SYMBOLIC_EX_BASE_H

#include <string>
#include <decl.h>
#include <number.h>


namespace symbolic {
namespace internal {



/// Abstract base class for expressions
class ex_base {

  public:
    /// Constructor
    explicit ex_base(unsigned type) : m_type(type) { ; }
    /// Destructor
    virtual ~ex_base() { ; }

    /// String representation
    virtual std::string str(print_flag pflag = DEFAULT) const = 0;
    /// LaTeX string representation
    virtual std::string tex(print_flag pflag = DEFAULT) const = 0;
    /// Max lag in expression
    virtual int get_lag_max(bool stop_on_E = false) const = 0;
    /// Min lag in expression
    virtual int get_lag_min(bool stop_on_E = false) const = 0;
    /// Derivative wrt a variable
    virtual ptr_base diff(const ptr_base&) const = 0;
    /// Substitution
    virtual ptr_base subst(const ptr_base &what, const ptr_base &with,
                           bool all_leads_lags = true) const = 0;

    /// Is 0?
    bool is0() const;
    /// Is 1?
    bool is1() const;
    /// Is -1?
    bool ism1() const;
    /// Return value if number, NaN otherwise.
    Number val() const;

    /// Type
    unsigned type() const { return (m_type & 0xffffff00); }
    /// Flag
    unsigned flag() const { return (m_type & 0xff); }

  protected:
    /// No default constructor
    ex_base() { ; }
    /// Type
    unsigned m_type;

}; /* class ex_base */

} /* namespace internal */
} /* namespace symbolic */

#endif /* SYMBOLIC_EX_BASE_H */
