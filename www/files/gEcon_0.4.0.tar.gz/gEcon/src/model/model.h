/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2013         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2013         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file model.h
 * \brief Class representing DSGE model.
 */

#ifndef MODEL_MODEL_H

#define MODEL_MODEL_H

#include <gecon_info.h>
#include <ex.h>
#include <model_block.h>


/// Class representing DSGE model.
class Model {
  public:
    /// Default constructor
    Model() : m_deter(false), m_static(false) { ; }

    /// Set model name (extracts path from name).
    void set_name(const std::string&);

    /// Add block.
    void add_block(const std::string &s);

    /// Add definition.
    void add_definition(const ex &lhs, const ex &rhs, int l) {
        m_blocks.back().add_definition(lhs, rhs, l);
    }

    /// Add control variable.
    void add_controls(const vec_exint &cl) {
        m_blocks.back().add_controls(cl);
    }

    /// Add objective.
    void add_objective(const ex &obj, const ex &obj_eq, const ex &lambda, int l) {
        m_blocks.back().add_objective(obj, obj_eq, lambda, l);
    }

    /// Add constraint.
    void add_constraint(const ex &lhs, const ex &rhs, const ex &lambda, int l) {
        m_blocks.back().add_constraint(lhs, rhs, lambda, l);
    }

    /// Add identity.
    void add_identity(const ex &lhs, const ex &rhs, int l) {
        m_blocks.back().add_identity(lhs, rhs, l);
    }

    /// Add shock.
    void add_shock(const ex &s, int l) {
        m_blocks.back().add_shock(s, l);
    }

    /// Add calibrating equation.
    void add_calibr(const ex &lhs, const ex &rhs, int l, const vec_exint &pl = vec_exint()) {
        m_blocks.back().add_calibr(lhs, rhs, l, pl);
    }

    /// Do it.
    void do_it();

    /// Clear.
    void clear();

    /// Where there any errors?
    bool errors() const { return m_err.size(); }

    /// Where there any warnings?
    bool warnings() const { return m_warn.size(); }

    /// Retrieve error messages.
    std::string get_errs() const;

    /// Retrieve warning messages.
    std::string get_warns() const;

    /// Generate logfile with results.
    void write_logf() const;

    /// Generate R code and write it to file.
    void write_R(bool output_long) const;

    /// Generate LaTeX documentation and write it to file.
    void write_LaTeX() const;

    /// Write model report to cerr.
    void report() const;

  private:

    // model path and name
    std::string m_path, m_name;
    // block names
    std::set<std::string> m_names;
    // blocks
    std::vector<Model_block> m_blocks;
    // variables
    set_ex m_vars;
    // parameters
    set_ex m_params, m_params_calibr, m_params_free;
    map_ex_ex m_params_frs;
    // controls
    map_ex_str m_contr;
    // objective functions
    map_ex_str m_obj;
    // is deterministic?
    bool m_deter;
    // is static?
    bool m_static;
    // max and min lag
    int m_max_lag, m_min_lag;
    // shocks
    set_ex m_shocks;
    // Lagrange multipliers
    set_ex m_lagr_mult;
    // equations
    set_ex m_eqs;
    // steady state eq's
    set_ex m_ss;
    // calibration eq's
    set_ex m_calibr;
    // calibration eq's
    set_ex m_calibr_init;
    // Variables / equations map
    std::map<std::pair<int, int>, unsigned> m_var_eq_map;
    // Shocks / equations map
    std::set<std::pair<int, int> > m_shock_eq_map;
    // Jacobian for ss equations
    std::map<std::pair<int, int>, ex> m_jacob_ss;
    // Jacobian for ss and calibration equations
    std::map<std::pair<int, int>, ex> m_jacob_ss_calibr;
    // 1st order pertubation
    std::map<std::pair<int, int>, ex> m_Atm1, m_At, m_Atp1, m_Aeps;
    // warnings & errors
    std::vector<std::string> m_warn, m_err;

    // Check definitions
    void check_defs();
    // Substitute definitions
    void subst_defs();
    // Check if model is deterministic
    void check_deter();
    // Check controls
    void check_obj_contr();
    // Check / handle leads > 1
    void leads();
    // Check / handle lags > 1
    void lags();
    // Check if model is static
    void check_static();
    // FOCs
    void focs();
    // Collect shocks
    void collect_shocks();
    // Merge vars and parameters in blocks
    void collect_vp();
    // Collect Lagrange multipliers
    void collect_lagr();
    // Collect calibration
    void collect_calibr();
    // Merge equations
    void collect_eq();
    // Reduce equations
    void reduce();
    // Construct variables / equations map
    void var_eq_map();
    // Construct shocks / equations map
    void shock_eq_map();
    // Steady state
    void ss();
    // Steady state and calibration eq's Jacobian
    void ss_jacob();
    // 1st order derivatives
    void diff_eqs();
    // Warning
    void warning(const std::string &mes);
    // Error
    void error(const std::string &mes);
    // Error
    void terminate_on_errors();
    // Write log
    void write_log(std::ostream&) const;

};


#endif /* MODEL_MODEL_H */
