/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2013         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2013         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file model_block.cpp
 * \brief Class representing a block of DSGE model.
 */


#include <model_block.h>
#include <helper.h>
#include <utils.h>
#include <iostream>
#include <fstream>


void
Model_block::add_definition(const ex &lhs, const ex &rhs, int l)
{
    m_defs_lhs.push_back(exint(lhs, l));
    m_defs_rhs.push_back(exint(rhs, l));
}

void
Model_block::add_controls(const vec_exint &cl)
{
    m_controls = cl;
}


void
Model_block::add_objective(const ex &obj, const ex &obj_eq, const ex &lambda, int l)
{
    m_obj_var = obj;
    m_obj_eq = obj_eq;
    m_obj_eq_in = obj_eq;
    m_obj_lm = lambda;
    m_obj_line = l;
}


void
Model_block::add_constraint(const ex &lhs, const ex &rhs, const ex &lambda, int l)
{
    m_constraints.push_back(exint(rhs - lhs, l));
    m_constraints_in_lhs.push_back(exint(lhs, l));
    m_constraints_in_rhs.push_back(exint(rhs, l));
    m_lagr_mult.push_back(exint(lambda, l));
}


void
Model_block::add_identity(const ex &lhs, const ex &rhs, int l)
{
    m_identities.push_back(exint(lhs - rhs, l));
    m_identities_in_lhs.push_back(exint(lhs, l));
    m_identities_in_rhs.push_back(exint(rhs, l));
}


void
Model_block::add_shock(const ex &s, int l)
{
    m_shocks.push_back(exint(s, l));
}


void
Model_block::add_calibr(const ex &lhs, const ex &rhs, int l, const vec_exint &pl)
{
    m_calibr.push_back(exint(lhs - rhs, l));
    m_calibr_pl.push_back(pl);
}


void
Model_block::subst_defs()
{
    for (unsigned i = 0; i < m_defs_lhs.size(); ++i) {
        ex what = m_defs_lhs[i].first;
        ex with = m_defs_rhs[i].first;
        if (m_obj_var) {
            m_obj_eq_in = m_obj_eq_in.subst(what, with);
            m_obj_eq = m_obj_eq.subst(what, with);
        }
        for (unsigned j = 0; j < m_constraints.size(); ++j) {
            m_constraints_in_lhs[j].first =
                m_constraints_in_lhs[j].first.subst(what, with);
            m_constraints_in_rhs[j].first =
                m_constraints_in_rhs[j].first.subst(what, with);
            m_constraints[j].first =
                m_constraints[j].first.subst(what, with);
        }
        for (unsigned j = 0; j < m_identities.size(); ++j) {
            m_identities_in_lhs[j].first =
                m_identities_in_lhs[j].first.subst(what, with);
            m_identities_in_rhs[j].first =
                m_identities_in_rhs[j].first.subst(what, with);
            m_identities[j].first =
                m_identities[j].first.subst(what, with);
        }
        for (unsigned j = 0; j < m_calibr.size(); ++j) {
            m_calibr[j].first = m_calibr[j].first.subst(what, with);
        }
    }
}



void
Model_block::lags()
{
    map_ex_int mcontr0, mcontr, mid;
    map_ex_int::const_iterator it;

    // lags in optimization problem
    collect_lags(m_obj_eq, mcontr0);
    for (unsigned i = 0; i < m_constraints.size(); ++i) {
        collect_lags(m_constraints[i].first, mcontr0);
    }
    for (it = mcontr0.begin(); it != mcontr0.end(); ++it) {
        if (m_contr.find(it->first) != m_contr.end()) mcontr.insert(*it); else mid.insert(*it);
    }
    mcontr0.clear();
    for (it = mcontr.begin(); it != mcontr.end(); ++it) {
        int l = it->second;
        ex v = it->first;
        for (int ll = -2; ll >= l; --ll) {
            ex vl = lag(append_name(v, "__lag_"
                        + symbolic::internal::num2str(-1 - ll)), -1);
            m_obj_eq = m_obj_eq.subst(lag(v, ll), vl, false);
            for (unsigned i = 0; i < m_constraints.size(); ++i) {
                m_constraints[i].first =
                    m_constraints[i].first.subst(lag(v, ll), vl, false);
            }
        }
    }
    for (it = mcontr.begin(); it != mcontr.end(); ++it) {
        int l = it->second;
        ex v = it->first;
        ex vl = append_name(v, "__lag_1");
        std::string vname = v.str(symbolic::internal::DROP_T_IDX);
        m_constraints.push_back(exint(lag(v, -1) - vl, 0));
        m_lagr_mult.push_back(exint(ex("lambda__" + m_name + "_" + vname + "_lag_1", 0), 0));
        m_controls.push_back(exint(vl, 0));
        for (int ll = -2; ll > l; --ll) {
            ex vl1 = lag(append_name(v, "__lag_"
                        + symbolic::internal::num2str(-1 - ll)), -1);
            ex vl2 = append_name(v, "__lag_" + symbolic::internal::num2str(-ll));
            m_constraints.push_back(exint(vl1 - vl2, 0));
            m_lagr_mult.push_back(exint(ex("lambda__" + m_name + "_" + vname + "_lag_"
                                           + symbolic::internal::num2str(-ll), 0), 0));
            m_controls.push_back(exint(vl2, 0));
        }
    }

    // lags in identities
    for (unsigned i = 0; i < m_identities.size(); ++i) {
        collect_lags(m_identities[i].first, mid);
    }
    for (it = mid.begin(); it != mid.end(); ++it) {
        int l = it->second;
        ex v = it->first;
        for (int ll = -2; ll >= l; --ll) {
            ex vl = lag(append_name(v, "__lag_"
                        + symbolic::internal::num2str(-1 - ll)), -1);
            for (unsigned i = 0; i < m_identities.size(); ++i) {
                m_identities[i].first =
                    m_identities[i].first.subst(lag(v, ll), vl, false);
            }
        }
    }
    for (it = mid.begin(); it != mid.end(); ++it) {
        int l = it->second;
        ex v = it->first;
        int ls = -1;
        map_ex_int::const_iterator it2 = mcontr.find(v);
        if (it2 != mcontr.end()) {
            ls = it2->second;
        }
        if (ls == -1) {
            ex vl = append_name(v, "__lag_1");
            m_identities.push_back(exint(lag(v, -1) - vl, 0));
            --ls;
        }
        for (int ll = ls; ll > l; --ll) {
            ex vl1 = lag(append_name(v, "__lag_"
                        + symbolic::internal::num2str(-1 - ll)), -1);
            ex vl2 = append_name(v, "__lag_" + symbolic::internal::num2str(-ll));
            m_identities.push_back(exint(vl1 - vl2, 0));
        }
    }
}



void
Model_block::focs()
{
    if (!m_controls.size()) return;

    // find Es
    find_Es(m_obj_eq, m_Es);
    for (unsigned i = 0; i < m_constraints.size(); ++i) {
        find_Es(m_constraints[i].first, m_Es);
    }

    // substitute qs for Es
    set_ex::const_iterator it;
    unsigned j;
    for (it = m_Es.begin(), j = 0; it != m_Es.end(); ++it, ++j) {
        m_qs.push_back(ex("q__" + m_name + "_"+ symbolic::internal::num2str(j + 1), 0));
        // m_etas.push_back(ex("eta_" + symbolic::internal::num2str(j), 0));
        m_obj_eq = m_obj_eq.subst(E(*it, 0), m_qs[j]);
        for (unsigned i = 0; i < m_constraints.size(); ++i) {
            m_constraints[i].first = m_constraints[i].first.subst(E(*it, 0), m_qs[j]);
        }
        ex S;
        for (unsigned i = 0; i < m_constraints.size(); ++i) {
            S = S + m_lagr_mult[i].first * diff(m_constraints[i].first, m_qs[j]);
        }
        m_etas.push_back(diff(m_obj_eq, m_qs[j]) + S);
    }

    // FOC w.r.t. U
    ex Z;
    for (it = m_Es.begin(), j = 0; it != m_Es.end(); ++it, ++j) {
            Z = Z + m_etas[j] * diff(*it, lag(m_obj_var, 1));
    }
    m_focs.push_back(expair(lag(Z, -1) - m_obj_lm, m_obj_var));

    // FOCs w.r.t. xs
    for (unsigned n = 0; n < m_controls.size(); ++n) {
        ex L, P, M, Q, R, x = m_controls[n].first;
        for (unsigned i = 0; i < m_constraints.size(); ++i) {
            L = L + m_lagr_mult[i].first
                * diff(m_constraints[i].first, x);
            P = P + lag(m_lagr_mult[i].first, 1)
                * diff(lag(m_constraints[i].first, 1), x);
        }
        for (it = m_Es.begin(),  j = 0; it != m_Es.end(); ++it, ++j) {
            M = M + m_etas[j] * diff(*it, x);
            Q = Q + lag(m_etas[j], 1) * diff(lag(*it, 1), x);
        }
        R = diff(lag(m_obj_eq, 1), x) + P + Q;
        m_focs.push_back(expair(diff(m_obj_eq, x) + L + M
            + E(lag(m_obj_lm, 1) * R, 0), x));
    }

    std::vector<bool> has_lags(m_qs.size(), false);
    unsigned cnstr_init_sz = m_constraints.size();
    for (it = m_Es.begin(), j = 0; j < m_qs.size(); ++j, ++it) {
        ex qq = m_qs[j];
        ex lqm = lag(qq, -1);
        ex lqp = lag(qq, 1);
        ex EE = E(*it, 0);
        for (unsigned i = 0; i < cnstr_init_sz; ++i) {
            if (m_constraints[i].first.has(lqm)) {
                has_lags[j] = true;
                break;
            }
            if (m_constraints[i].first.has(lqp)) {
                has_lags[j] = true;
                break;
            }
        }
        for (unsigned i = 0; i < m_focs.size(); ++i) {
            if (m_focs[i].first.has(lqm)) {
                has_lags[j] = true;
                break;
            }
            if (m_focs[i].first.has(lqp)) {
                has_lags[j] = true;
                break;
            }
        }
        if (has_lags[j]) {
            m_constraints.push_back(exint(qq - EE, 0));
        }
    }
    for (it = m_Es.begin(), j = 0; j < m_qs.size(); ++j, ++it) {
        ex qq = m_qs[j];
        ex EE = E(*it, 0);

        if (!has_lags[j]) {
            for (unsigned i = 0; i < m_focs.size(); ++i) {
                m_focs[i].first = m_focs[i].first.subst(qq, EE);
            }
            for (unsigned i = 0; i < m_constraints.size(); ++i) {
                m_constraints[i].first = m_constraints[i].first.subst(qq, EE);
            }
            m_obj_eq = m_obj_eq.subst(qq, EE);
        }
    }
}



void
Model_block::focs_deter()
{
    if (!m_controls.size()) return;

    // FOC w.r.t. U
    ex A = diff(m_obj_eq, lag(m_obj_var, 1));
    for (unsigned i = 0; i < m_constraints.size(); ++i) {
        A = A + m_lagr_mult[i].first * diff(m_constraints[i].first, lag(m_obj_var, 1));
    }
    m_focs.push_back(expair(lag(A, -1) - m_obj_lm, m_obj_var));

    // FOCs w.r.t. xs
    for (unsigned n = 0; n < m_controls.size(); ++n) {
        ex K, L, M, P, x = m_controls[n].first;
        for (unsigned i = 0; i < m_constraints.size(); ++i) {
            L = L + m_lagr_mult[i].first * diff(m_constraints[i].first, x);
            P = P + lag(m_lagr_mult[i].first, 1)
                    * diff(lag(m_constraints[i].first, 1), x);
        }
        K = diff(m_obj_eq, x);
        M = diff(lag(m_obj_eq, 1), x);
        m_focs.push_back(expair(K + L + lag(m_obj_lm, 1) * (M + P), x));
    }
}



void
Model_block::collect_vp(set_ex &vars, set_ex &parms)
{
    collect(m_obj_var, vars, parms);
    collect(m_obj_eq, vars, parms);
    for (int f = 0, F = m_focs.size(); f < F; ++f) {
        collect(m_focs[f].first, vars, parms);
    }
    for (int c = 0, C = m_constraints.size(); c < C; ++c) {
        collect(m_constraints[c].first, vars, parms);
    }
    for (int id = 0, Id = m_identities.size(); id < Id; ++id) {
        collect(m_identities[id].first, vars, parms);
    }
}




void
Model_block::write_LaTeX(std::ostream &os, bool static_model) const
{
    symbolic::internal::print_flag pflag = (static_model) ? 
        symbolic::internal::DROP_T_IDX : symbolic::internal::DEFAULT;
    if (m_controls.size() || m_identities.size()) {
        os << "\\section{" << symbolic::internal::str2tex2(m_name) << "}\n\n";
    } else {
        return;
    }

    if (m_controls.size()) {
        os << "\\subsection{Optimization problem}\n\n";
        os << "\\begin{align}\n";
        os << "&\\max_{";
        for (unsigned n = 0; n < m_controls.size() - 1; ++n) {
            os << m_controls[n].first.tex(pflag);
        }
        os << m_controls.back().first.tex(pflag) << "\n} "
           << m_obj_var.tex(pflag) << " = "
           << m_obj_eq_in.tex(pflag) << "\\\\\n";
        if (m_lagr_mult.size()) {
            os << "&\\mathrm{s.t.:}\\nonumber\\\\\n";
            for (unsigned i = 0; i < m_constraints_in_rhs.size() - 1; ++i) {
                os << "& " << m_constraints_in_lhs[i].first.tex(pflag) << " = "
                   << m_constraints_in_rhs[i].first.tex(pflag)
                   << " \\quad (" << m_lagr_mult[i].first.tex(pflag)
                   << ")\\\\\n";
            }
            unsigned in_sz = m_constraints_in_rhs.size() - 1;
            os << "& " << m_constraints_in_lhs[in_sz].first.tex(pflag) << " = "
               << m_constraints_in_rhs[in_sz].first.tex(pflag)
               << " \\quad (" << m_lagr_mult[in_sz].first.tex(pflag)
               << ")\n";
        }
        os << "\\end{align}\n\n\n";
    }

    if (m_identities.size()) {
        os << "\\subsection{Identities}\n\n";
        for (unsigned id = 0; id < m_identities_in_lhs.size(); ++id) {
            os << "\\begin{equation}\n"
               << m_identities_in_lhs[id].first.tex(pflag) << " = "
               << m_identities_in_rhs[id].first.tex(pflag)
               << "\n\\end{equation}\n";
        }
        os << "\n\n";
    }

    if (m_focs.size()) {
        os << "\\subsection{First order conditions}\n\n";
        for (unsigned f = 0; f < m_focs.size(); ++f) {
            os << "\\begin{equation}\n"
               << m_focs[f].first.tex(pflag) << " = 0\n"
               << " \\quad (" << m_focs[f].second.tex(pflag)
               << ")\n\\end{equation}\n";
        }
        os << "\n\n";
    }

    os << "\n\n";
}



void
Model_block::write_logfile(std::ostream &os, bool static_model) const
{
    symbolic::internal::print_flag pflag = (static_model) ? 
        symbolic::internal::DROP_T_IDX : symbolic::internal::DEFAULT;
    os << "Block name: " << m_name << '\n';

    if (m_controls.size()) {
        os << "Controls:\n    ";
        for (unsigned i = 0; i < m_controls.size() - 1; ++i) {
            os << m_controls[i].first.str(pflag) << ", ";
        }
        os << m_controls.back().first.str(pflag) << '\n';

        os << "Objective:\n    ";
        os << m_obj_var.str(pflag) << " = " << m_obj_eq.str(pflag) 
           << "    (" << m_obj_lm.str(pflag) << ")\n";

        if (m_constraints.size()) {
            os << "Constraints:\n";
            for (unsigned i = 0; i < m_lagr_mult.size(); ++i) {
                os << "    " << m_constraints[i].first.str(pflag) << " = 0    ("
                   << m_lagr_mult[i].first.str(pflag) << ")\n";
            }
            for (unsigned i = m_lagr_mult.size(); i < m_constraints.size(); ++i) {
                os << "    " << m_constraints[i].first.str(pflag)
                   << " = 0    (auxiliary)\n";
            }
        }
    }

    if (m_identities.size()) {
        // identities
        os << "Identities:\n";
        for (unsigned i = 0; i < m_identities.size(); ++i) {
            os << "    " << m_identities[i].first.str(pflag) << " = 0\n";
        }
        os << '\n';
    }

    if (m_focs.size()) {
        // FOCs
        os << "First order conditions:\n";
        for (unsigned i = 0; i < m_focs.size(); ++i) {
            os << "    " << m_focs[i].first.str(pflag) << " = 0    ("
               << m_focs[i].second.str(pflag) << ")\n";
        }
        os << '\n';
    }
}




























