/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file helper.h
 * \brief Helper functions used in FOC derivation.
 */

#ifndef SYMBOLIC_HELPER_H

#define SYMBOLIC_HELPER_H

#include <triplet.h>
#include <ex.h>
#include <cmp.h>
#include <vector>
#include <set>


namespace symbolic {


/// Given an expression equal 0 try to find substitution for time indexed
/// vars with numbers / parameters
triplet<bool, ex, ex> find_subst(const ex &expression, const set_ex&);

/// Given an expression equal 0 try to find substitution for parameter with a number
triplet<bool, ex, ex> find_par_eq_num(const ex &expression);

/// Find expressions under expected value
void find_Es(const ex &e, set_ex&);

/// Collect variables and parameters.
void collect(const ex &e, set_ex &vars, set_ex &parms);

/// Collect variables in lag > 1
void collect_lags(const ex &e, map_ex_int &map);

namespace internal {

/// Find expressions under expected value
void find_Es(const ptr_base&, set_ex&);

/// Collect variables and parameters.
void collect(const ptr_base&, set_ex &vars, set_ex &parms);

/// Collect variables in lag > 1
void collect_lags(const ptr_base &p, map_ex_int &map);

} /* namespace internal */

} /* namespace symbolic */

#endif /* SYMBOLIC_HELPER_H */
