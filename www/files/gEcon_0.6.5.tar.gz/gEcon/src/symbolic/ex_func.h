/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex_func.h
 * \brief Functions.
 */

#ifndef SYMBOLIC_EX_FUNC_H

#define SYMBOLIC_EX_FUNC_H


#include <ex_base.h>
#include <ptr_base.h>


namespace symbolic {
namespace internal {


/// Class representing number
class ex_func : public ex_base {
  public:
    /// Constructor
    ex_func(func_code c, const ptr_base &arg)
        : ex_base(FUN | (arg->flag() & HAST) | SINGLE),
          m_code(c), m_arg(arg) { ; }
    /// Destructor
    ~ex_func() { ; }

    /// Constructor from two arguments.
    static ptr_base create(func_code c, const ptr_base &arg);
    /// Free memory (assumes that ptr is actually pointer to ex_func)
    static void destroy(ex_base *ptr);

    /// Comparison
    int compare(const ex_func&) const;

    /// String representation
    virtual std::string str(print_flag pflag) const;
    /// String representation using string 2 string map (name substitution).
    virtual std::string strmap(const map_str_str&) const;
    /// LaTeX string representation
    virtual std::string tex(print_flag pflag) const;
    /// Max lag in expression
    virtual int get_lag_max(bool stop_on_E = false) const;
    /// Min lag in expression
    virtual int get_lag_min(bool stop_on_E = false) const;

    /// Derivative wrt a variable
    virtual ptr_base diff(const ptr_base&) const;

    /// Does expression have a given subexpression?
    virtual bool has(const ptr_base &what, search_flag f) const;

    /// Evaluate function
    static Number eval(func_code c, const Number &x);

  private:
    // No default constructor
    ex_func() : ex_base(NUL), m_arg(0) { ; }
    // Function code
    func_code m_code;
    // Pointer to an argument
    ptr_base m_arg;

    friend ptr_base lag(const ptr_base &p, int l);
    friend ptr_base ss(const ptr_base &p);
    friend bool has_Es(const ptr_base &p);
    friend ptr_base subst(const ptr_base &e,
                          const ptr_base &what, const ptr_base &with,
                          bool all_leads_lags);
    friend void collect(const ptr_base &p, set_ex &vars, set_ex &parms);
    friend void collect_lags(const ptr_base &p, map_ex_int &map);
    friend void find_Es(const ptr_base&, set_ex&);
    friend ptr_base drop_Es(const ptr_base&);

}; /* class ex_func */

} /* namespace internal */
} /* namespace symbolic */

#endif /* SYMBOLIC_EX_FUNC_H */
