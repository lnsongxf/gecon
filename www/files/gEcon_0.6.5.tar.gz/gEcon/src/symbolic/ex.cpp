/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex.cpp
 * \brief Expression.
 */

#include <ex.h>
#include <ex_num.h>
#include <ex_symb.h>
#include <ex_vart.h>
#include <ops.h>
#include <cmp.h>
#include <error.h>
#ifdef R_DLL
#include <R.h>
#else /* R_DLL */
#include <cmath>
#endif /* R_DLL */

using namespace symbolic;
using namespace symbolic::internal;


ex::ex() : m_ptr(ex_num::zero())
{
}


ex::ex(const std::string &n) : m_ptr(ex_symb::create(n))
{
}

ex::ex(const std::string &n, int l) : m_ptr(ex_vart::create(n, l))
{
}


ex::ex(const Number &v) : m_ptr(ex_num::create(v))
{
}


ex&
ex::operator=(const ex &rhs)
{
    m_ptr = rhs.m_ptr;
    return *this;
}


bool
ex::operator==(const ex &rhs)
{
    return compare(m_ptr, rhs.m_ptr) ? false : true;
}


bool
ex::operator!=(const ex &rhs)
{
    return compare(m_ptr, rhs.m_ptr) ? true : false;
}


bool
ex::has(const ex &what, search_flag f) const
{
    unsigned t = what.m_ptr->type();
    if ((t != SYMB) && (t != VART) && (t != EX)) {
        USER_ERROR("trying to search for something that is not a constant, nor a variable, nor an expected value")
    }
    return m_ptr->has(what.m_ptr, f);
}


bool
ex::has_Es() const
{
    return symbolic::internal::has_Es(m_ptr);
}


ex
ex::subst(const ex &what, const ex &with, bool all_leads_lags) const
{
    unsigned t = what.m_ptr->type();
    if ((t != SYMB) && (t != VART) && (t != EX)) {
        USER_ERROR("trying to substitute for something that is not a constant, nor variable, nor expected val expression")
    }
    if (!(with.m_ptr->flag() & HAST) && (with.m_ptr->flag() & HAST)) {
        USER_ERROR("trying to substitute for constant with an expression containing variable")
    }

    return ex(symbolic::internal::subst(m_ptr, what.m_ptr, with.m_ptr, all_leads_lags));
}



std::string
ex::str(print_flag pflag) const
{
    return m_ptr->str(pflag);
}

std::string
ex::strmap(const map_str_str &mss) const
{
    return m_ptr->strmap(mss);
}

std::string
ex::tex(print_flag pflag) const
{
    return m_ptr->tex(pflag);
}


int
ex::get_lag_max(bool stop_on_E) const
{
    return m_ptr->get_lag_max(stop_on_E);
}


int
ex::get_lag_min(bool stop_on_E) const
{
    return m_ptr->get_lag_min(stop_on_E);
}



bool
ex::validnum() const
{
    Number v = m_ptr->val();
#ifdef R_DLL
    return R_FINITE(v.val());
#else /* R_DLL */
    return std::isfinite(v.val());
#endif /* R_DLL */
}



std::ostream&
symbolic::operator<<(std::ostream &s, const ex &e)
{
    s << e.str() << '\n';
    return s;
}


ex
ex::operator-() const
{
    return ex(mk_neg(m_ptr));
}

ex
symbolic::operator+(const ex &lhs, const ex &rhs)
{
    return ex(mk_add(lhs.m_ptr, rhs.m_ptr));
}

ex
symbolic::operator-(const ex &lhs, const ex &rhs)
{
    return ex(mk_sub(lhs.m_ptr, rhs.m_ptr));
}

ex
symbolic::operator*(const ex &lhs, const ex &rhs)
{
    return ex(mk_mul(lhs.m_ptr, rhs.m_ptr));
}

ex
symbolic::operator/(const ex &lhs, const ex &rhs)
{
    return ex(mk_div(lhs.m_ptr, rhs.m_ptr));
}

ex
symbolic::pow(const ex &lhs, const ex &rhs)
{
    return ex(mk_pow(lhs.m_ptr, rhs.m_ptr));
}


ex
symbolic::func(symbolic::internal::func_code fc, const ex &e)
{
    return ex(mk_func(fc, e.m_ptr));
}



ex
symbolic::diff(const ex &exp, const ex &var)
{
    unsigned t = var.m_ptr->type();
    if ((t != SYMB) && (t != VART)) {
        USER_ERROR("trying to differentiate wrt something that is not a parameter nor a variable")
    }

    if (!exp.m_ptr->has(var.m_ptr, EXACT_T)) return ex();
    return ex(exp.m_ptr->diff(var.m_ptr));
}


ex
symbolic::append_name(const ex &e, const std::string &s)
{
    return ex(internal::append_name(e.m_ptr, s));
}


ex
symbolic::lag(const ex &e, int l)
{
    return ex(lag(e.m_ptr, l));
}


ex
symbolic::ss(const ex &e)
{
    return ex(ss(e.m_ptr));
}


ex
symbolic::E(const ex &e, int l)
{
    return ex(mk_E(e.m_ptr, l));
}


ex
symbolic::drop_Es(const ex &e)
{
    return ex(internal::drop_Es(e.m_ptr));
}



void
symbolic::find_Es(const ex &e, set_ex &sex)
{
    find_Es(e.m_ptr, sex);
}


void
symbolic::collect(const ex &e, set_ex &vars, set_ex &parms)
{
    collect(e.m_ptr, vars, parms);
}


void
symbolic::collect_lags(const ex &e, map_ex_int &map)
{
    if (e.get_lag_min() >= -1) return;
    collect_lags(e.m_ptr, map);
}


triplet<bool, ex, ex>
symbolic::find_subst(const ex &e, const set_ex &se)
{
    ptr_base pb = e.m_ptr;

    if (pb->type() == VART) {
        ex v(pb.get<ex_vart>()->copy0());
        if (se.find(v) != se.end()) return triplet<bool, ex, ex>(true, e, ex());
        return triplet<bool, ex, ex>(false, ex(), ex());
    }
    if (pb->type() != ADD) return triplet<bool, ex, ex>(false, ex(), ex());

    const ex_add *p = pb.get<ex_add>();
    unsigned n = p->no_args(), i, c, m, l;

    for (i = 0, c = 0; i < n;) {
        if (p->m_ops[i].second->type() == VART) {
            const ex_vart *pv = p->m_ops[i].second.get<ex_vart>();
            ptr_base v = pv->copy0();
            if (se.find(ex(v)) != se.end()) {
                for (unsigned j = 0; j < n; ++j) {
                    if ((j != i) && (p->m_ops[j].second->has(v, ANY_T))) goto next;
                }
                m = i;
                l = pv->get_lag();
                ++c;
                break;
            }
        }
next:
        ++i;
    }

    if (!c) return triplet<bool, ex, ex>(false, ex(), ex());

    ex what(p->m_ops[m].second);
    ex coef(-p->m_ops[m].first);
    ex with = e / coef + what;
    return triplet<bool, ex, ex>(true, lag(what, -l), lag(with, -l));
}



triplet<bool, ex, ex>
symbolic::find_par_eq_num(const ex &e)
{
    ptr_base pb = e.m_ptr;

    if (pb->type() == SYMB) {
        return triplet<bool, ex, ex>(true, e, ex());
    }
    if (pb->type() != ADD) return triplet<bool, ex, ex>(false, ex(), ex());

    const ex_add *p = pb.get<ex_add>();
    unsigned n = p->no_args();

    if (n != 2) return triplet<bool, ex, ex>(false, ex(), ex());

    if ((p->m_ops[0].second->type() == NUM)
        && (p->m_ops[1].second->type() == SYMB)
        && (p->m_ops[1].first == 1.)) {
        ex par(p->m_ops[1].second);
        ex val(p->m_ops[0].second);
        return triplet<bool, ex, ex>(true, par, -val);
    }

    return triplet<bool, ex, ex>(false, ex(), ex());
}



bool
less_ex::operator()(const symbolic::ex &a, const symbolic::ex &b) const
{
    return (compare(a.m_ptr, b.m_ptr) < 0);
}







