/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

 /** \file ops.cpp
 * \brief Operations.
 */


#include <ex_num.h>
#include <ex_symb.h>
#include <ex_vart.h>
#include <ex_add.h>
#include <ex_mul.h>
#include <ex_pow.h>
#include <ex_func.h>
#include <ex_e.h>
#include <cmp.h>
#include <error.h>
#include <ops.h>
#include <iostream>
#include <cmath>
#include <climits>


using namespace symbolic;
using namespace symbolic::internal;




ptr_base
symbolic::internal::lag(const ptr_base &p, int l)
{
    if (!l) return p;
    if (!(p->flag() & HAST)) return p;
    unsigned t = p->type();
    if (t == VART) return p.get<ex_vart>()->lag(l);
    else if (t == EX) return p.get<ex_e>()->lag(l);
    else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = p.get<ex_add>()->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(in[i].first,
                                                        lag(in[i].second, l)));
        return mk_add(out);
    } else if (t == MUL) {
        num_ex_pair_vec in, out;
        in = p.get<ex_mul>()->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(in[i].first,
                                                        lag(in[i].second, l)));
        return mk_mul(out);
    } else if (t == POW) {
        const ex_pow *pt = p.get<ex_pow>();
        return mk_pow(lag(pt->m_base, l), lag(pt->m_exp, l));
    } else if (t == FUN) {
        const ex_func *pt = p.get<ex_func>();
        return ex_func::create(pt->m_code, lag(pt->m_arg, l));
    } else INTERNAL_ERROR;
}



ptr_base
symbolic::internal::ss(const ptr_base &p)
{
    if (!(p->flag() & HAST)) return p;
    unsigned t = p->type();
    if (t == VART)
        return ex_vart::create(p.get<ex_vart>()->m_hash, INT_MIN);
    else if (t == EX) return ss(p.get<ex_e>()->m_arg);
    else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = p.get<ex_add>()->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(num_ex_pair(in[i].first, ss(in[i].second)));
        return mk_add(out);
    } else if (t == MUL) {
        num_ex_pair_vec in, out;
        in = p.get<ex_mul>()->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(in[i].first, ss(in[i].second)));
        return mk_mul(out);
    } else if (t == POW) {
        const ex_pow *pt = p.get<ex_pow>();
        return reduce(mk_pow(ss(pt->m_base), ss(pt->m_exp)));
    } else if (t == FUN) {
        const ex_func *pt = p.get<ex_func>();
        return reduce(ex_func::create(pt->m_code, ss(pt->m_arg)));
    } else INTERNAL_ERROR;
}






ptr_base
symbolic::internal::drop_Es(const ptr_base &p)
{
    if (!has_Es(p)) return p;
    unsigned t = p->type();
    if (t == EX) {
        return p.get<ex_e>()->m_arg;
    } else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = p.get<ex_add>()->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(in[i].first,
                                                      drop_Es(in[i].second)));
        return mk_add(out);
    } else if (t == MUL) {
        num_ex_pair_vec in, out;
        in = p.get<ex_mul>()->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(in[i].first,
                                                      drop_Es(in[i].second)));
        return mk_mul(out);
    } else if (t == POW) {
        const ex_pow *pt = p.get<ex_pow>();
        return mk_pow(drop_Es(pt->m_base), drop_Es(pt->m_exp));
    } else if (t == FUN) {
        const ex_func *pt = p.get<ex_func>();
        return ex_func::create(pt->m_code, drop_Es(pt->m_arg));
    } else INTERNAL_ERROR;
}





ptr_base
symbolic::internal::append_name(const ptr_base &p, const std::string &s)
{
    unsigned t = p->type();
    if (t == SYMB) {
        return ex_symb::create(p.get<ex_symb>()->get_name() + s);
    }
    if (t == VART) {
        return ex_vart::create(p.get<ex_vart>()->get_name() + s, 0);
    }
    USER_ERROR("append_name expects parameter or variable")
}



ptr_base
symbolic::internal::subst(const ptr_base &p,
                          const ptr_base &what, const ptr_base &with,
                          bool all_leads_lags)
{
    if (all_leads_lags) {
        if (!p->has(what, ANY_T)) return p;
    } else {
        if (!p->has(what, EXACT_T)) return p;
    }
    unsigned t = p->type(), tw = what->type();
    if (t == EX) {
        const ex_e *pt = p.get<ex_e>();
        const ex_e *ptw = what.get<ex_e>();
        if (tw == EX) {
            int l1 = pt->m_lag, l2 = ptw->get_lag(), ld = l2 - l1;
            if (ld && (!all_leads_lags))
                return mk_E(subst(pt->m_arg, what, with, all_leads_lags), pt->m_lag);
            if (!compare(lag(pt->m_arg, ld), ptw->m_arg)) {
                return lag(with, -ld);
            }
        }
        return mk_E(subst(pt->m_arg, what, with, all_leads_lags), pt->m_lag);
    } else if (t == tw) { // primitive type that contains what, so is euqal
        if (t == SYMB) return with;
        else {
            if (all_leads_lags) {
                int l1 = p->get_lag_max(), l2 = what->get_lag_max();
                if (l1 == INT_MIN) return ss(with);
                return lag(with, l1 - l2);
            } else return with;
        }
    } else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = p.get<ex_add>()->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(
                in[i].first, subst(in[i].second, what, with, all_leads_lags)));
        return mk_add(out);
    } else if (t == MUL) {
        num_ex_pair_vec in, out;
        in = p.get<ex_mul>()->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(
                in[i].first, subst(in[i].second, what, with, all_leads_lags)));
        return mk_mul(out);
    } else if (t == POW) {
        const ex_pow *pt = p.get<ex_pow>();
        return mk_pow(subst(pt->m_base, what, with, all_leads_lags),
                      subst(pt->m_exp, what, with, all_leads_lags));
    } else if (t == FUN) {
        const ex_func *pt = p.get<ex_func>();
        return ex_func::create(pt->m_code,
                               subst(pt->m_arg, what, with, all_leads_lags));
    } else INTERNAL_ERROR;
}

















