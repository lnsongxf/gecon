/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex_pow.h
 * \brief Powers.
 */

#ifndef SYMBOLIC_EX_POW_H

#define SYMBOLIC_EX_POW_H


#include <ex_base.h>
#include <ptr_base.h>


namespace symbolic {
namespace internal {


/// Class representing power expression.
class ex_pow : public ex_base {
  public:
    /// Constructor from two arguments.
    ex_pow(const ptr_base &a, const ptr_base &b);
    /// Destructor
    virtual ~ex_pow() { ; }

    /// Constructor from two arguments.
    static ptr_base create(const ptr_base &a, const ptr_base &b);
    /// Free memory (assumes that ptr is acutally pointer to ex_pow)
    static void destroy(ex_base *ptr);

    /// Comparison
    int compare(const ex_pow&) const;

    /// String representation
    virtual std::string str(print_flag pflag) const;
    /// String representation using string 2 string map (name substitution).
    virtual std::string strmap(const map_str_str&) const;
    /// LaTeX string representation
    virtual std::string tex(print_flag pflag) const;
    /// Max lag in expression
    virtual int get_lag_max(bool stop_on_E = false) const;
    /// Min lag in expression
    virtual int get_lag_min(bool stop_on_E = false) const;

    /// Derivative wrt a variable
    virtual ptr_base diff(const ptr_base&) const;

    /// Does expression have a given subexpression?
    virtual bool has(const ptr_base &what, search_flag f) const;

  private:
    // No default constructor
    ex_pow();
    // Ops
    ptr_base m_base, m_exp;

    friend int cmp(const ptr_base &a, const ptr_base &b);
    friend ptr_base mk_pow(const ptr_base &lhs, const ptr_base &rhs);
    friend ptr_base lag(const ptr_base &p, int l);
    friend ptr_base ss(const ptr_base &p);
    friend ptr_base subst(const ptr_base &e,
                          const ptr_base &what, const ptr_base &with,
                          bool all_leads_lags);
    friend bool has_Es(const ptr_base &p);
    friend void find_Es(const ptr_base&, set_ex&);
    friend ptr_base drop_Es(const ptr_base&);
    friend void collect(const ptr_base &p, set_ex &vars, set_ex &parms);
    friend void collect_lags(const ptr_base &p, map_ex_int &map);
    friend class num_ex_pair_vec;

}; /* class ex_pow */

} /* namespace internal */
} /* namespace symbolic */

#endif /* SYMBOLIC_EX_POW_H */
