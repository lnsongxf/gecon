/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file stringhash.cpp
 * \brief Hash values for strings.
 */

#include <stringhash.h>
#include <error.h>

using namespace symbolic;
using namespace symbolic::internal;


unsigned
stringhash::get_hash(const std::string &str)
{
    std::map<std::string, unsigned>::const_iterator it;
    it = m_map2int.find(str);
    if (it != m_map2int.end()) {
        return it->second;
    }

    if (m_ind >= 67108865) {
        throw std::bad_alloc();
    }

    unsigned ids = str[0];
    if (ids > 96) ids -= 96; else ids -= 48;
    ids <<= 26;
    ids += (++m_ind);
    m_map2int[str] = ids;
    m_map2str[ids] = str;
    return ids;
}


const std::string&
stringhash::get_str(unsigned id) const
{
    std::map<unsigned, std::string>::const_iterator it;
    it = m_map2str.find(id);
    if (it == m_map2str.end()) INTERNAL_ERROR
    return it->second ;
}

