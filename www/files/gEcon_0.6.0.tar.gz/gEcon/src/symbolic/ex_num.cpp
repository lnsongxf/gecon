/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex_num.cpp
 * \brief Numbers.
 */


#include <ex_num.h>
#include <utils.h>
#include <cmp.h>
#include <climits>

using namespace symbolic;
using namespace symbolic::internal;


ptr_base
ex_num::create(const Number &n)
{
    return ptr_base(new ex_num(n));
}


void
ex_num::destroy(ex_base *ptr)
{
    delete ptr;
}


ptr_base
ex_num::copy() const
{
    return ptr_base(new ex_num(m_val));
}


int
ex_num::compare(const ex_num &b) const
{
    return compareT(m_val, b.m_val);
}


std::string
ex_num::str(print_flag pflag) const
{
    return m_val.str();
}

std::string
ex_num::strmap(const map_str_str&) const
{
    return m_val.str();
}

std::string
ex_num::tex(print_flag pflag) const
{
    return m_val.tex();
}


int
ex_num::get_lag_max(bool) const
{
    return INT_MIN;
}


int
ex_num::get_lag_min(bool) const
{
    return INT_MAX;
}

ptr_base
ex_num::subst(const ptr_base &what, const ptr_base &with, bool) const
{
    return copy();
}


ptr_base
ex_num::diff(const ptr_base&) const
{
    return zero();
}


