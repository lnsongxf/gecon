/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file helper.cpp
 * \brief Helper functions used in FOC derivation.
 */


#include <helper.h>
#include <ops.h>
#include <ex_add.h>
#include <ex_mul.h>
#include <ex_pow.h>
#include <ex_func.h>
#include <ex_e.h>
#include <ex_vart.h>
#include <error.h>


using namespace symbolic;
using namespace symbolic::internal;



triplet<bool, ex, ex>
symbolic::find_subst(const ex &e, const set_ex &se)
{
    ptr_base pb = e.m_ptr;

    if (pb->type() == VART) {
        ex v(static_cast<const ex_vart*>(pb.get())->copy0());
        if (se.find(v) != se.end()) return triplet<bool, ex, ex>(true, e, ex());
        return triplet<bool, ex, ex>(false, ex(), ex());
    }
    if (pb->type() != ADD) return triplet<bool, ex, ex>(false, ex(), ex());

    const ex_add *p = static_cast<const ex_add*>(pb.get());
    unsigned n = p->no_args(), i, c, m, l;

    for (i = 0, c = 0; i < n;) {
        if (p->m_ops[i].second->type() == VART) {
            const ex_vart *pv = static_cast<const ex_vart*>(p->m_ops[i].second.get());
            ptr_base v = pv->copy0();
            if (se.find(ex(v)) != se.end()) {
                for (unsigned j = 0; j < n; ++j) {
                    if ((j != i) && (hast(p->m_ops[j].second, v))) goto next;
                }
                m = i;
                l = pv->get_lag();
                ++c;
                break;
            }
        }
next:
        ++i;
    }

    if (!c) return triplet<bool, ex, ex>(false, ex(), ex());

    ex what(p->m_ops[m].second);
    ex coef(-p->m_ops[m].first);
    ex with = e / coef + what;
    return triplet<bool, ex, ex>(true, lag(what, -l), lag(with, -l));
}



triplet<bool, ex, ex>
symbolic::find_par_eq_num(const ex &e)
{
    ptr_base pb = e.m_ptr;

    if (pb->type() == SYMB) {
        return triplet<bool, ex, ex>(true, e, ex());
    }
    if (pb->type() != ADD) return triplet<bool, ex, ex>(false, ex(), ex());

    const ex_add *p = static_cast<const ex_add*>(pb.get());
    unsigned n = p->no_args();

    if (n != 2) return triplet<bool, ex, ex>(false, ex(), ex());

    if ((p->m_ops[0].second->type() == NUM)
        && (p->m_ops[1].second->type() == SYMB)
        && (p->m_ops[1].first == 1.)) {
        ex par(p->m_ops[1].second);
        ex val(p->m_ops[0].second);
        return triplet<bool, ex, ex>(true, par, -val);
    }

    return triplet<bool, ex, ex>(false, ex(), ex());
}



void
symbolic::internal::find_Es(const ptr_base &p, set_ex &sex)
{
    unsigned t = p->type();
    if (t == EX) {
        ptr_base pe = static_cast<const ex_e*>(p.get())->m_arg;
        int l = static_cast<const ex_e*>(p.get())->m_lag;
        sex.insert(ex(lag(pe, -l)));
        find_Es(pe, sex);
        return;
    } else if (t == ADD) {
        num_ex_pair_vec args = static_cast<const ex_add*>(p.get())->m_ops;
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            find_Es(args[i].second, sex);
        }
        return;
    } else if (t == MUL) {
        num_ex_pair_vec args = static_cast<const ex_mul*>(p.get())->m_ops;
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            find_Es(args[i].second, sex);
        }
        return;
    } else if (t == POW) {
        const ex_pow *pp = static_cast<const ex_pow*>(p.get());
        find_Es(pp->m_base, sex);
        find_Es(pp->m_exp, sex);
        return;
    } else if (t == FUN) {
        find_Es(static_cast<const ex_func*>(p.get())->m_arg, sex);
        return;
    };
}



void
symbolic::find_Es(const ex &e, set_ex &sex)
{
    find_Es(e.m_ptr, sex);
}




void
symbolic::internal::collect(const ptr_base &p, set_ex &vars, set_ex &parms)
{
    unsigned t = p->type();
    if (t == NUM) {
        return;
    } else if (t == SYMB) {
        parms.insert(ex(p));
        return;
    } else if (t == VART) {
        vars.insert(ex(static_cast<const ex_vart*>(p.get())->copy0()));
        return;
    } else if (t == EX) {
        ptr_base pe = static_cast<const ex_e*>(p.get())->m_arg;
        collect(pe, vars, parms);
        return;
    } else if (t == ADD) {
        num_ex_pair_vec args = static_cast<const ex_add*>(p.get())->m_ops;
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            collect(args[i].second, vars, parms);
        }
        return;
    } else if (t == MUL) {
        num_ex_pair_vec args = static_cast<const ex_mul*>(p.get())->m_ops;
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            collect(args[i].second, vars, parms);
        }
        return;
    } else if (t == POW) {
        const ex_pow *pp = static_cast<const ex_pow*>(p.get());
        collect(pp->m_base, vars, parms);
        collect(pp->m_exp, vars, parms);
        return;
    } else if (t == FUN) {
        collect(static_cast<const ex_func*>(p.get())->m_arg, vars, parms);
        return;
    };
}




void
symbolic::collect(const ex &e, set_ex &vars, set_ex &parms)
{
    collect(e.m_ptr, vars, parms);
}



void
symbolic::internal::collect_lags(const ptr_base &p, map_ex_int &map)
{
    unsigned t = p->type();
    if (t == NUM) {
        return;
    } else if (t == SYMB) {
        return;
    } else if (t == VART) {
        int l;
        l = static_cast<const ex_vart*>(p.get())->m_lag;
        if (l >= -1) return;
        ex v = ex(static_cast<const ex_vart*>(p.get())->copy0());
        map_ex_int::iterator it = map.find(v);
        if (it != map.end()) {
            if (it->second > l) it->second = l;
        } else {
            map.insert(std::pair<ex, int>(v, l));
        }
        return;
    } else if (t == EX) {
        ptr_base pe = static_cast<const ex_e*>(p.get())->m_arg;
        collect_lags(pe, map);
        return;
    } else if (t == ADD) {
        num_ex_pair_vec args = static_cast<const ex_add*>(p.get())->m_ops;
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            collect_lags(args[i].second, map);
        }
        return;
    } else if (t == MUL) {
        num_ex_pair_vec args = static_cast<const ex_mul*>(p.get())->m_ops;
        unsigned i, n = args.size();
        for (i = 0; i < n; ++i) {
            collect_lags(args[i].second, map);
        }
        return;
    } else if (t == POW) {
        const ex_pow *pp = static_cast<const ex_pow*>(p.get());
        collect_lags(pp->m_base, map);
        collect_lags(pp->m_exp, map);
        return;
    } else if (t == FUN) {
        collect_lags(static_cast<const ex_func*>(p.get())->m_arg, map);
        return;
    };
}



void
symbolic::collect_lags(const ex &e, map_ex_int &map)
{
    if (e.get_lag_min() >= -1) return;
    collect_lags(e.m_ptr, map);
}

























