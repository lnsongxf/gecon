/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex_e.h
 * \brief Expected value (conditional - time indexed).
 */

#ifndef SYMBOLIC_EX_E_H

#define SYMBOLIC_EX_E_H

#include <ex_base.h>
#include <ptr_base.h>


namespace symbolic {
namespace internal {


/// Class representing expected value
class ex_e : public ex_base {
  public:
    /// Constructor from string and lag
    ex_e(const ptr_base &e, int l);
    /// Destructor
    ~ex_e() { ; }

    /// Return a copy
    ptr_base copy() const;

    /// Constructor from string and lag
    static ptr_base create(const ptr_base &e, int l);
    /// Free memory (assumes that ptr is actually pointer to ex_e)
    static void destroy(ex_base *ptr);

    /// Comparison
    int compare(const ex_e&) const;

    /// String representation
    virtual std::string str(print_flag pflag) const;
    /// String representation using string 2 string map (name substitution).
    /// This ignores expected vlau operators.
    virtual std::string strmap(const map_str_str&) const;
    /// LaTeX string representation
    virtual std::string tex(print_flag pflag) const;
    /// Max lag in expression
    virtual int get_lag_max(bool stop_on_E = false) const;
    /// Min lag in expression
    virtual int get_lag_min(bool stop_on_E = false) const;
    /// Derivative wrt a variable
    virtual ptr_base diff(const ptr_base&) const;
    /// Substitution
    virtual ptr_base subst(const ptr_base &what, const ptr_base &with,
                           bool all_leads_lags = true) const;

    /// Lag
    ptr_base lag(int l) const;
    /// Get lag
    int get_lag() const { return m_lag; }

  private:
    // No default constructor
    ex_e() : ex_base(NUL), m_arg(static_cast<ex_base*>(0)) { ; }
    // Key
    ptr_base m_arg;
    // Lag
    int m_lag;

    friend ptr_base mk_E(const ptr_base &p, int l);
    friend bool has(const ptr_base &e, const ptr_base &what);
    friend bool hast(const ptr_base &p, const ptr_base &what);
    friend bool hasdifft(const ptr_base &p, const ptr_base &what);
    friend bool haslead(const ptr_base &p, const ptr_base &what);
    friend ptr_base ss(const ptr_base &p);
    friend void collect(const ptr_base &p, set_ex &vars, set_ex &parms);
    friend void collect_lags(const ptr_base &p, map_ex_int &map);
    friend void find_Es(const ptr_base&, set_ex&);
    friend ptr_base drop_Es(const ptr_base&);

}; /* class ex_e */


} /* namespace internal */
} /* namespace symbolic */

#endif /* SYMBOLIC_EX_E_H */
