/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex_symb.cpp
 * \brief Symbols.
 */

#include <ex_symb.h>
#include <ex_num.h>
#include <stringhash.h>
#include <utils.h>
#include <cmp.h>
#include <climits>


using namespace symbolic;
using namespace symbolic::internal;



ex_symb::ex_symb(const std::string &n) : ex_base(SYMB | SINGLE)
{
//     m_name = n;

    m_hash = stringhash::get_instance().get_hash(n);
}

ptr_base
ex_symb::create(const std::string &n)
{
    return ptr_base(new ex_symb(n));
}


void
ex_symb::destroy(ex_base *ptr)
{
    delete ptr;
}



ptr_base
ex_symb::copy() const
{
    return ptr_base(new ex_symb(*this));
}


int
ex_symb::compare(const ex_symb &b) const
{
    return compareT(m_hash, b.m_hash);
}


std::string
ex_symb::get_name() const
{
    return stringhash::get_instance().get_str(m_hash);
}



std::string
ex_symb::str(print_flag pflag) const
{
    return get_name();
}


std::string
ex_symb::strmap(const map_str_str &mss) const
{
    map_str_str::const_iterator it;
    std::string name = get_name();
    it = mss.find(name);
    if (it == mss.end()) {
        return name;
    }
    return it->second;
}


std::string
ex_symb::tex(print_flag pflag) const
{
    return str2tex(get_name());
}


int
ex_symb::get_lag_max(bool) const
{
	return INT_MIN;
}


int
ex_symb::get_lag_min(bool) const
{
    return INT_MAX;
}


ptr_base
ex_symb::diff(const ptr_base &p) const
{
    if (p->type() != SYMB) return ex_num::zero();
    const ex_symb *pp = static_cast<const ex_symb*>(p.get());
    if (!compare(*pp)) return ex_num::one();
    return ex_num::zero();
}


ptr_base
ex_symb::subst(const ptr_base &what, const ptr_base &with, bool) const
{
    if (what->type() != SYMB) return copy();
    const ex_symb *pp = static_cast<const ex_symb*>(what.get());
    if (!compare(*pp)) return with;
    return copy();
}





