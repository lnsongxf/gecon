# ############################################################################
# This file is a part of gEcon.iosam.                                        #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Marta Retkiewicz 2015-2016                                             #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Author: Marta Retkiewicz                                                   #
# ############################################################################
# Example for gEcon.iosam package: tables import
# ############################################################################


# load gEcon.iosam package
library(gEcon.iosam)


# Eurostat
data_file <- file.path(system.file("extdata", package = "gEcon.iosam"), "iot_eurostat.csv")
map_file <- file.path(system.file("extdata", package = "gEcon.iosam"), "map_eurostat.csv")
map_file2 <- file.path(system.file("extdata", package = "gEcon.iosam"), "map_eurostat2.csv")

iot_eur <- read_from_database(data_file, database = "eurostat")
View(as.matrix(iot_eur))
summary(iot_eur)

map_eur <- read.csv(map_file, header = FALSE, sep = ";")
map_eur2 <- read.csv(map_file2, header = FALSE, sep = ";")
iot_eur_agg <- aggregate_iosam(iot_eur, map_eur, map_eur2)
summary(iot_eur_agg)


# WIOD
data_file <- file.path(system.file("extdata", package = "gEcon.iosam"), "iot_wiod.csv")
map_file <- file.path(system.file("extdata", package = "gEcon.iosam"), "map_wiod.csv")
map_file2 <- file.path(system.file("extdata", package = "gEcon.iosam"), "map_wiod2.csv")

iot_wiod <- read_from_database(data_file, database = "wiod")
summary(iot_wiod)

map_wiod <- read.csv(map_file, header = FALSE, sep = ";")
map_wiod2 <- read.csv(map_file2, header = FALSE, sep = ";")
iot_wiod_agg <- aggregate_iosam(iot_wiod, map_wiod, map_wiod2)
summary(iot_wiod_agg)


# GTAP
#data_file <- ...
#map_file <- ...

#sam_gtap <- read_from_database(data_file, database = "gtap")

#map_gtap <- read.csv(map_file, header = FALSE, sep = ";")
#sam_gtap_agg <- aggregate_iosam(sam_gtap, map_gtap)
#summary(sam_gtap_agg)



