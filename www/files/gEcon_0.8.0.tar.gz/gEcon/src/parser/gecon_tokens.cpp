/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file gecon_tokens.cpp
 * \brief Lexer tokens.
 */

#include <gecon_tokens.h>
#include <cstring>
#include <cstdlib>

enum tokens {
    ACOS = 4,
    AND = 5,
    ASIN = 6,
    ATAN = 7,
    BACKSLASH = 8,
    BACKWARDCOMP = 9,
    BFALSE = 10,
    BLOCK = 11,
    BTRUE = 12,
    CALIBR = 13,
    CLETTER = 14,
    COLON = 15,
    COMMA = 16,
    COMMENT = 17,
    CONSTRAINTS = 18,
    CONTROLS = 19,
    COS = 20,
    COSH = 21,
    DAND = 22,
    DBLCOLON = 23,
    DDOT = 24,
    DEFS = 25,
    DELTA = 26,
    DEQ = 27,
    DID = 28,
    DIDU = 29,
    DIV = 30,
    DOLLAR = 31,
    DOR = 32,
    DOUBLE = 33,
    DQUOTE = 34,
    E = 35,
    EQ = 36,
    ERF = 37,
    EXCLAM = 38,
    EXP = 39,
    ID = 40,
    IDS = 41,
    IDU = 42,
    INF = 43,
    INT = 44,
    LANGBR = 45,
    LATEX = 46,
    LBRACE = 47,
    LBRACK = 48,
    LEQ = 49,
    LOG = 50,
    LOGF = 51,
    LONG = 52,
    LPAREN = 53,
    MINUS = 54,
    MUL = 55,
    NEQ = 56,
    OBJ = 57,
    OPTS = 58,
    OR = 59,
    OUTPUT = 60,
    PLUS = 61,
    POW = 62,
    PROD = 63,
    QUESTION = 64,
    QUOTE = 65,
    R = 66,
    RANGBR = 67,
    RARROW = 68,
    RBRACE = 69,
    RBRACK = 70,
    RPAREN = 71,
    SEMI = 72,
    SETS = 73,
    SHOCKS = 74,
    SHORT = 75,
    SIN = 76,
    SINH = 77,
    SLETTER = 78,
    SQRT = 79,
    SS = 80,
    SUM = 81,
    TAN = 82,
    TANH = 83,
    TILDE = 84,
    TRYREDUCE = 85,
    UDID = 86,
    UID = 87,
    VERBOSE = 88,
    WS = 89,
    ZERO = 90,
    END_LIST
};



unsigned char**
mk_tnames()
{
    unsigned char **tnames = (unsigned char**) malloc(sizeof(unsigned char*) * END_LIST);
    for (unsigned i = 0; i < END_LIST; ++i) {
        unsigned sz;
        switch (i) {
#define EXPAND_CASE(nn, tt) \
case nn: sz = strlen(tt) + 1; tnames[i] = (unsigned char*) malloc(sz); memcpy(tnames[i], tt, sz); \
break;
            EXPAND_CASE(TILDE, "\'~\'")
            EXPAND_CASE(QUESTION, "\'?\'")
            EXPAND_CASE(EXCLAM, "\'!\'")
            EXPAND_CASE(DOLLAR, "\'$\'")
            EXPAND_CASE(AND, "\'&\'")
            EXPAND_CASE(DAND, "\'&&\'")
            EXPAND_CASE(OR, "\'|\'")
            EXPAND_CASE(DOR, "\'||\'")
            EXPAND_CASE(SEMI, "\';\'")
            EXPAND_CASE(COLON, "\':\'")
            EXPAND_CASE(DBLCOLON, "\'::\'")
            EXPAND_CASE(DDOT, "\'..\'")
            EXPAND_CASE(COMMA, "\',\'")
            EXPAND_CASE(RARROW, "\'->\'")
            EXPAND_CASE(PLUS, "\'+\'")
            EXPAND_CASE(MINUS, "\'-\'")
            EXPAND_CASE(MUL, "\'*\'")
            EXPAND_CASE(DIV, "\'/\'")
            EXPAND_CASE(POW, "\'^\'")
            EXPAND_CASE(EQ, "\'=\'")
            EXPAND_CASE(DEQ, "\'==\'")
            EXPAND_CASE(NEQ, "\'!=\'")
            EXPAND_CASE(LEQ, "\'<=\'")
            EXPAND_CASE(QUOTE, "\'\'\'")
            EXPAND_CASE(DQUOTE, "\'\"\'")
            EXPAND_CASE(BACKSLASH, "\'\\\'")
            EXPAND_CASE(LBRACE, "\'{\'")
            EXPAND_CASE(RBRACE, "\'}\'")
            EXPAND_CASE(LPAREN, "\'(\'")
            EXPAND_CASE(RPAREN, "\')\'")
            EXPAND_CASE(LBRACK, "\'[\'")
            EXPAND_CASE(RBRACK, "\']\'")
            EXPAND_CASE(LANGBR, "\'<\'")
            EXPAND_CASE(RANGBR, "\'>\'")
            default:
                tnames[i] = (unsigned char*) malloc(1);
                tnames[i][0] = '\0';
        }
    }
    return tnames;
}


void
free_tnames(unsigned char **tnames)
{
    for (unsigned i = 0; i < END_LIST; ++i) {
        free(tnames[i]);
    }
    free(tnames);
}


