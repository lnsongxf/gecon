# ############################################################################
# This file is a part of gEcon.                                              #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2012-2015  #
# (c) Grzegorz Klima, Karol Podemski, Kaja Retkiewicz-Wijtiwiak 2015-2016    #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Grzegorz Klima, Karol Podemski, Kaja Retkiewicz-Wijtiwiak         #
# ############################################################################
# Functions make_model and load_model
# ############################################################################


# ############################################################################
# The add_r_ext function attaches the .model.R extension if the model file
# was specified without it
# ############################################################################
# Input
#   filename - character string, filename
# Output
#   character string with .model.R extension, if filename was specified
#   without it
# ############################################################################
add_r_ext <- function(filename)
{
    if (length(grep(pattern="(?i)\\.model\\.R$", x = filename, perl = TRUE))) {
        return(filename)
    } else {
        return(paste(filename, ".model.R", sep = ""))
    }
}

# ############################################################################
# The add_gcn_ext function attaches .gcn extension if the model file
# was specified without it
# ############################################################################
# Input
#   filename - character string, filename
# Output
#   character string with .gcn extension, if model filename was specified
#   without it
# ############################################################################
add_gcn_ext <- function(filename)
{
    if (length(grep(pattern="(?i)\\.gcn$", x = filename, perl = TRUE))) {
        return(filename)
    } else {
        return(paste(filename, ".gcn", sep = ""))
    }
}

# ############################################################################
# The rm_gcn_ext function removes the .gcn extension from string
# ############################################################################
# Input
#   filename - character string, filename
# Output
#   string without .gcn extension
# ############################################################################
rm_gcn_ext <- function(filename)
{
    filename <- gsub(pattern = "(?i)\\.gcn$", replacement = "",
                     x = filename, perl = TRUE)
    return(filename)
}

# ############################################################################
# The make_model function calls dynamic library, parses model file,
# generates R output and loads it into gecon_model class object
# ############################################################################
# Input
#   filename - a name of model file (.gcn file)
# Output
#   object of gecon_model class
# ############################################################################
make_model <- function(filename)
{
    if (!is.character(filename) | length(filename) != 1 | filename == "") {
        stop("filename has to be passed as a non-empty character string")
    }
    filename <- add_gcn_ext(filename)
    res <- tryCatch(expr = { filename <- normalizePath(filename,
                                                       winslash = "/",
                                                       mustWork = TRUE)
                    TRUE
        },
        error = function(e) FALSE
    )
    if (!res) {
        stop("the specified model file does not exist")
    }
    st <- proc.time()
    ok <- .Call("parse_from_R", filename)
    en <- proc.time()
    cat(paste0("model parsed in ", round(en[[3]] - st[[3]], digits = 2), "s\n"))
    filename <- rm_gcn_ext(filename)
    return(load_model(filename))
}

# ############################################################################
# The load_model function loads the already generated .model.R file and creates 
# an object of the \code{gecon_model} class
# ############################################################################
# Input
#   filename - the path to the .R file containing the model's functions and 
#              variables (a .model.R file generated earlier).
# Output
#   object of gecon_model class
# ############################################################################
load_model <- function(filename)
{
    if (!is.character(filename) | length(filename) != 1 | filename == "") {
        stop("filename has to be passed as a non-empty character string")
    }
    filename <- add_r_ext(filename)
    st <- proc.time()
    res <- eval(parse(filename))
    en <- proc.time()
    cat(paste0("model loaded in ", round(en[[3]] - st[[3]], digits = 2), "s\n"))
    return(res)
}

