# ############################################################################
# This file is a part of gEcon.                                              #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2012-2015  #
# (c) Grzegorz Klima, Karol Podemski, Kaja Retkiewicz-Wijtiwiak 2015-2016    #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Grzegorz Klima, Karol Podemski, Kaja Retkiewicz-Wijtiwiak         #
# ############################################################################
# Class for storing simulation results
# ############################################################################

# ############################################################################
# Class definition
# ############################################################################
setClass(
    Class = "gecon_simulation",
    representation = representation(
        sim = "array",
        shocks = "vector",
        shocks_tex = "vector",
        variables = "vector",
        variables_tex = "vector",
        sim_name = "character",
        model_info = "character",
        r_object_name = "character"
    )
)

# ############################################################################
# The function gecon_simulation is a constructor
# of an object of gecon_simulation class
# ############################################################################
# Input
#   sim - (array) simulation results or impulse response functions with 2 or 3
#       dimensions: (variables, time) or (variables, time, shocks)
#   shocks - vector of shock names
#   shocks_tex - vector of LaTeX shock names
#   variables - vector of variables' names
#   variables_tex - vector of LaTeX variables' names
#   sim_name - a character value, the simulation name
#   model_info - a character vector of length 3 containing information about
#                   the model: input file name, input file path and the date of creation
#   r_object_name - a character value, the name of an R object storing
#                   gecon_model object for which simulations were performed
# Output
#   an object of gecon_simulation class
# ############################################################################
gecon_simulation <- function(sim,
                             shocks, shocks_tex, variables, variables_tex,
                             sim_name, model_info, r_object_name)
{
    sim_obj <- new("gecon_simulation")

    if (!is.array(sim) || !(length(dim(sim)) %in% 2:3)) {
        stop("simulation results should be a 2- or 3-dimensional array")
    } else sim_obj@sim <- sim
    if (!is.vector(shocks)) {
        stop("shocks should be of vector type")
    } else sim_obj@shocks <- shocks
    if (!is.vector(shocks_tex)) {
        stop("shocks_tex should be of vector type")
    } else sim_obj@shocks_tex <- shocks_tex
    if (!is.vector(variables)) {
        stop("variables should be of vector type")
    } else sim_obj@variables <- variables
    if (!is.vector(variables_tex)) {
        stop("variables_tex should be of vector type")
    } else sim_obj@variables_tex <- variables_tex
    if (!is.vector(sim_name)) {
        stop("sim_name should be of character type")
    } else sim_obj@sim_name <- sim_name
    if (!is.character(model_info)) {
        stop("model_info should be of character type")
    } else sim_obj@model_info <- model_info
    if (!is.character(r_object_name)) {
        stop("r_object_name should be of character type")
    } else sim_obj@r_object_name <- r_object_name

    return(sim_obj)
}


# ############################################################################
# The get_simulation_results function returns the simulation results as
# a list
# ############################################################################
# Input
#   sim_obj - an object of gecon_simulation class
# Output
#   A matrix or list of matrices with the results of simulation
# ############################################################################
get_simulation_results <- function(sim_obj)
{
    if (!is(sim_obj, "gecon_simulation"))
        stop("sim_obj should be an object of gecon_simulation class")

    if (length(dim(sim_obj@sim)) == 3) {
        nv <- dim(sim_obj@sim)[1]
        nt <- dim(sim_obj@sim)[2]
        ns <- dim(sim_obj@sim)[3]
        res <- list()
        for (s in 1:ns) {
            sim <- as.matrix(sim_obj@sim[, , s], nrow = nv, ncol = nt)
            res <- c(res, list(sim))
        }
        names(res) <- sim_obj@shocks
        return(res)
    }

    return (sim_obj@sim)
}


# ############################################################################
# The show method controls how the gecon_simulation object is printed
# ############################################################################
# Input
#   object - an object of gecon_simulation class
# Output
#   Information about an object of gecon_simulation class
# ############################################################################
setMethod("show", signature(object = "gecon_simulation"),
function(object)
{
    cat(paste0(object@sim_name, "\n"))
    cat(paste0("Simulation horizon: ", dim(object@sim)[2], "\n"))
    nv <- length(object@variables)
    ns <- length(object@shocks)
    if (length(dim(object@sim)) == 3) {
        mes <- "Responses of "
        mes <- paste0(mes, numnoun(nv, "variable"))
        mes <- paste0(mes, " to ")
        mes <- paste0(mes, numnoun(ns, "shock"))
        cat(paste0(mes, "\n"))
    } else {
        mes <- "Evolution of "
        mes <- paste0(mes, numnoun(nv, "variable"))
        mes <- paste0(mes, " based on path of ")
        mes <- paste0(mes, numnoun(ns, "shock"))
        cat(paste0(mes, "\n"))
    }
})

# ############################################################################
# The print method prints information about simulations
# ############################################################################
# Input
#   x - an object of gecon_simulation class
# Output
#   Information about the simulation
# ############################################################################
setMethod("print", signature(x = "gecon_simulation"),
function(x)
{
    object <- x
    cat(paste0(object@sim_name, "\n"))
    cat(paste0("Simulation horizon: ", dim(object@sim)[2], "\n"))
    nv <- length(object@variables)
    ns <- length(object@shocks)
    cat(paste0("Variables (", nv, "):\n"))
    cat(list2str2(object@variables))
    cat("\n")
    cat(paste0("Shocks (", ns, "):\n"))
    cat(list2str2(object@shocks))
    cat("\n")
})


# ############################################################################
# The summary method displays the results of simulations
# ############################################################################
# Input
#   x - an object of gecon_simulation class
# Output
#   Prints the simulation results
# ############################################################################
setMethod("summary", signature(object = "gecon_simulation"),
function(object)
{
    print(object)
    if (length(dim(object@sim)) == 3) {
        ns <- dim(object@sim)[3]
        nt <- dim(object@sim)[2]
        nv <- dim(object@sim)[1]
        for (s in 1:ns) {
            cat(paste0("\n", paste(rep("-", 70), collapse = ""), "\n"))
            cat(paste0("Impulse responses to ", object@shocks[s], " shock\n\n"))
            sim <- as.matrix(object@sim[, , s], nrow = nv, ncol = nt)
            print(sim)
        }
    } else {
        cat(paste0("\n", paste(rep("-", 70), collapse = ""), "\n\n"))
        print(object@sim)
    }
})


# ############################################################################
# The plot_simulation function plots simulation results on the screen
# or saves them in the model's subdirectory /plots as .eps files
# ############################################################################
# Input
#   sim_obj - an object of gecon_simulation class
#   to_eps - a logical value, if TRUE, plots will be
#            saved as .eps file in the model's /plots subdirectory,
#            plots are also added to the a .results.tex file
# Output
#   Plots of objects of gecon_simulation class
# ############################################################################
plot_simulation <- function(sim_obj, to_eps = FALSE)
{
    if (!is(sim_obj, "gecon_simulation"))
        stop("sim_obj should be an object of gecon_simulation class")
    if (!is.logical(to_eps))
        stop("invalid to_eps argument")

    if (to_eps) {
        path <- gsub(pattern = paste0(sim_obj@model_info[1], "(.gcn)?$"),
                     replacement = "",
                     x = sim_obj@model_info[2])
        path <- paste(path, "plots", sep = "")
        dir.create(path, showWarnings = FALSE)
        files <- character()
        descriptions <- character()
    }

    # number of variables on each plot
    nvaronplot <- 5

    if (length(dim(sim_obj@sim)) == 3) {
        ns <- dim(sim_obj@sim)[3]
        nv <- dim(sim_obj@sim)[1]
        for (s in 1:ns) {
            d <- as.matrix(sim_obj@sim[, , s])
            if (nv == 1) {
                d <- as.ts(d)
            } else {
                d <- as.ts(t(d))
            }
            nplots <- ((dim(d)[2] - 1) %/% nvaronplot) + 1

            for (i in 1:nplots) {
                if (i < nplots) {
                    indices <- 1:nvaronplot + (i - 1) * nvaronplot
                } else {
                    indices <- (1 + (i - 1) * nvaronplot):dim(d)[2]
                }

                plotts <- as.ts(d[, indices, drop = FALSE])
                impresp <- "Impulse response"
                if (length(indices) > 1) impresp <- paste0(impresp, "s")

                if (to_eps) {
                    file_name <- unique_output_name(path)
                    files <- c(files, file_name)
                    file_name <- paste0(path, "/", file_name)
                    descr <- paste0(sim_obj@variables_tex[indices],
                                    collapse = ", ")
                    descr <- paste0(impresp, " ($", descr, "$) to $",
                                    sim_obj@shocks_tex[s],"$ shock")
                    descriptions <- c(descriptions, descr)
                    plot_title <- NULL
                } else {
                    file_name <- NULL
                    plot_title <- paste0(impresp, " to ", sim_obj@shocks[s],
                                         " shock")
                }

                plot_gecon(plotts,
                           serieslab = sim_obj@variables[indices],
                           main = plot_title,
                           f_name = file_name)
            }
        }
    } else {
        d <- as.ts(t(sim_obj@sim))
        nplots <- ((dim(d)[2] - 1) %/% nvaronplot) + 1

        for (i in 1:nplots) {
            if (i < nplots) {
                indices <- 1:nvaronplot + (i - 1) * nvaronplot
            } else {
                indices <- (1 + (i - 1) * nvaronplot):dim(d)[2]
            }

            plotts <- as.ts(d[, indices, drop = FALSE])

            if (to_eps) {
                file_name <- unique_output_name(path)
                files <- c(files, file_name)
                file_name <- paste0(path, "/", file_name)
                descr <- paste0(sim_obj@variables_tex[indices], collapse = ", ")
                descr <- paste0(sim_obj@sim_name, " ($", descr, "$)")
                descriptions <- c(descriptions, descr)
                plot_title <- NULL
            } else {
                file_name <- NULL
                plot_title <- sim_obj@sim_name
            }

            plot_gecon(plotts,
                       serieslab = sim_obj@variables[indices],
                       main = plot_title,
                       f_name = file_name)
        }
    }

    if (to_eps) {
        tex_out <- paste0("\n\\pagebreak\n\n\\section{", sim_obj@sim_name,"}\n\n")
        tnpl <- length(files)
        if (tnpl == 1) {
            inds2 <- numeric()
            indr <- 1
        } else {
            inds2 <- 2 * (1:(tnpl %/% 2))
            indr <- (tnpl %% 2) * (1 + 2 * (tnpl %/% 2))
        }

        for (i in inds2) {
            mpage <- paste0("\\begin{figure}[h]\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-3em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[i - 1], "}\n",
                            "\\caption{", descriptions[i - 1] ,"}\n",
                            "\\end{minipage}\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-3em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[i], "}\n",
                            "\\caption{", descriptions[i] ,"}\n",
                            "\\end{minipage}\n",
                            "\\end{figure}\n\n")
            tex_out <- paste0(tex_out, mpage)
            if (!(i %% 4)) tex_out <- paste0(tex_out, "\\pagebreak\n\n")
        }
        if (indr) {
            mpage <- paste0("\\begin{figure}[h]\n",
                            "\\centering\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-3em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[indr], "}\n",
                            "\\caption{", descriptions[indr] ,"}\n",
                            "\\end{minipage}\n",
                            "\\end{figure}")
            tex_out <- paste0(tex_out, mpage)
        }
        filenam <- paste0(rm_gcn_ext(sim_obj@model_info[2]), ".results.tex")
        if (file.exists(filenam)) {
            write(tex_out, filenam, sep = "\n", append = TRUE)
        } else {
            write(tex_out, filenam  , sep = "\n")
        }
        cat(paste0("saved ", list2str(files, "\'"), " in directory \'", path, "\'\n"))
        cat(paste0("plot(s) added to \'", filenam, "\'\n"))
    }
}

# ############################################################################
# The unique_output_name function finds files in the specified path
# created with pattern type[0-9]+ and creates following string:
# type and maximum number incremented by one
# ############################################################################
# Input
#   path - path to be searched
#   name - name to be searched
#   ext - extension to be searched
# Output
#   character:
#   A type and the maximum number incremented by one
# ############################################################################
unique_output_name <- function(path, name = "plot", ext = "eps")
{
    lof <- list.files(path, pattern = paste0(name, "_[0-9]+\\.", ext))
    if (length(lof)) {
        pat <- paste0("(?<=", name, "_).*?(?=\\.", ext, ")")
        re <- regexpr(pattern = pat, text = lof, perl = TRUE)
        pl_numbers <- as.numeric(regmatches(lof, re))
        next_number <- max(pl_numbers) + 1
    } else next_number <- 1
    nname <- paste0(name, "_", next_number, ".", ext)

    return(nname)
}


# ############################################################################
# The plot_gecon function plots simulation results
# ############################################################################
# Input
#   sim - an object of ts class
#   serieslab - a vector of series names
#   main - the plot label
#   f_name - the name of the .eps file in which plot is to be written
# Output
#   A plot on the screen or written to an .eps file
# ############################################################################
plot_gecon <- function(sim,
                       serieslab = NULL,
                       main = NULL,
                       f_name = NULL)
{
    # labels for OX
    lab <- time(sim)
    color_palette <- c("red3", "black", "gray48", "darkorange2",
                       "orangered4", "coral3", "gray73")

    # y limits
    yl <- ylimits(min(sim), max(sim), forcezero = TRUE)
    ylim <- yl[1:2]
    yby <- yl[3]
    xl <- xlimits(min(lab), max(lab))

    # for export
    if(!is.null(f_name)) {
        options(scipen = 1)
        ps.options(family = "serif", encoding = "ISOLatin1")
        setEPS()
        postscript(f_name, family = "serif")
    }

    # specifying characteristics of the plot
    layout(rbind(1, 2), heights = c(7, 1))

    # default margin parameters
    def_mar <- par()$mar

    # default axis parameters
    def_mgp <- par()$mgp
    par(mar = c(3.1, 5.1, 5.1, 3.1))
    par(mgp = c(2, 1, 0))

    if (dim(sim)[1] > 1) {
        plot(sim, plot.type = "single", yaxt = "n", xaxt = "n",
             col = color_palette,
             lwd = 2,
             main = main,
             xlab = "Periods",
             ylab = "Deviation from the steady state",
             ylim = ylim)
    } else  {
        plot(x = rep(1, length(sim)),
             y = as.vector(sim),
             col = color_palette,
             lwd = 2,
             main = main,
             xlab = "Periods",
             ylab = "Deviation from the steady state",
             ylim = ylim, xaxt = "n", yaxt = "n")
    }
    # axis formatting
    axis(1, at = (xl), labels = xl, tcl = -0.3, cex.axis = 0.7)
    axis(2, at = seq(ylim[1], ylim[2], by = yby),
             labels = pretty_labels(yl[1], yl[2], yl[3]),
             cex.axis = 0.7)

    if (is.null(nrow(sim))) {
        x1var = length(sim) + 1
    } else {
        x1var = nrow(sim) + 1
    }
    segments(x0 = 0, y0 = 0, x1 = x1var, col = "black", lwd = 1, lty = 2)

    if (!is.null(serieslab) ) {
        par(mar = c(0, 0, 0, 0))
        plot.new()
        legend("center", legend = serieslab, lty = 1, col = color_palette,
                cex = 0.7, border = F, horiz = TRUE)
    }

    if(!is.null(f_name)) dev.off()

    # resetting default parameters
    par(mar = def_mar)
    par(mgp = def_mgp)
}

# ############################################################################
# Function roundpow10 rounds a number to p power of 10
# ############################################################################
# Input
#   y - number to be rounded
#   p - specified power
#   up - parameter denoting whether rounding function
#         should be ceiling (TRUE) or floor (FALSE)
# Output
#   rounded number
# ############################################################################
roundpow10 <- function(y, p, up = TRUE)
{
    if (y == 0) return(y)
    if (y < 0) {
        y = -y;
        sgn = -1;
    } else {
        sgn = 1;
    }
    if (((up) & (sgn > 0)) | ((!up) & (sgn < 0))) {
        return(sgn * ceiling(y / 10^p) * 10^p)
    }
    return(sgn * floor(y / 10^p) * 10^p)
}


# ############################################################################
# Function ylimits finds optimal limits on plot according
# to input data
# ############################################################################
# Input
#   ymin - the minimum value of the data
#   ymax - the maximum value of the data
#   forcezero - Boolean, should 0 be always included in the range?
#               (default FALSE)
# Output
#   Vector with three elements denoting minimum, maximum and step
#   for y axis
# ############################################################################
ylimits <- function (ymin, ymax, forcezero = FALSE)
{
    if ((ymin == 0) & (ymax == 0)) { return(c(-1, 1, 1)) }
    if (ymin > ymax) { stop("invalid range (min greater than max)") }
    if (forcezero) {
        if (ymin > 0) ymin = 0;
        if (ymax < 0) ymax = 0;
    }

    if (ymax > ymin) {
        p = floor(log10(ymax - ymin))
    } else {
        p = floor(log10(ymax));
    }

    ylo = roundpow10(ymin, p, F)
    yhi = roundpow10(ymax, p, T)

    if (max(yhi, abs(ylo)) == 10^p) p = p - 1
    yby = 10^p

    if ((ymax - ymin) / 10^p > 15) { yby = yby * 5 }
    else if ((ymax - ymin) / 10^p > 8) { yby = yby * 2 }
    else if ((ymax - ymin) / 10^p > 4) {  }
    else if ((ymax - ymin) / 10^p > 2) { yby = yby / 2 }
    else { yby = yby / 4 }

    rh = ceiling(yhi / yby) - ceiling(ymax / yby);
    rl = ceiling(abs(ymin / yby)) - ceiling(abs(ylo / yby)) ;
    if (ylo < 0) rl = -rl;
    yhi = yhi - rh * yby;
    ylo = ylo + rl * yby;
    if (yhi < ymax) yhi = yhi + yby;
    if (ylo > ymin) ylo = ylo - yby;

    if ((yhi > 0) & (ylo < 0)) {
        rh = abs(yhi / yby - round(yhi / yby))
        if (rh > 2e-16) yhi = yhi + rh * yby;
        rl = abs(abs(ylo) / yby - round(abs(ylo) / yby))
        if (rl > 2e-16) ylo = ylo - rl * yby;
    }

    return(c(ylo, yhi, yby))
}

# ############################################################################
# The xlimits function finds optimal limits on x-axis according
# to input data
# ############################################################################
# Input
#   ymin - the minimum value of the data
#   ymax - the maximum value of the data
# Output
#   Scale for x- axis
# ############################################################################
xlimits <- function (xmin, xmax)
{
    if ((xmin == 1) & (xmax == 1))
        { return(c(1, 1)) }

    if ((xmin == 1) & (xmax < 10))
        { return(c(xmin : xmax))}

    if ((xmin == 1) & (xmax >= 10))
        {return(c(1, seq(5, 5 * floor(xmax /5), 5)))}
}

# ############################################################################
# The roundpow10 function rounds a number to the p power of 10
# ############################################################################
# Input
#   y - a number to be rounded
#   p - a number specifying the power
#   up - parameter denoting whether rounding function
#         should be ceiling (TRUE) or floor (false)
# Output
#   A rounded number
# ############################################################################
roundpow10 <- function(y, p, up = TRUE)
{
    if (y == 0) return(y)
    if (up) return(ceiling(y / 10^p) * 10^p)
    else return(floor(y / 10^p) * 10^p)
}


# ############################################################################
# Function returns prepared labels for axis from sequence parameters
#   (from result of ylimits function)
# ############################################################################
# Input
#   yl - initial value
#   yh - limit value
#   yb - step value
# Output
#   character vector representing axis labels
# ############################################################################
pretty_labels <- function(yl, yh, yb)
{
    return (format(round(seq(yl, yh, yb), find_signif(yb)), scientific = FALSE))
}

# ############################################################################
# Function finds number of significant digits from specified value
# ############################################################################
# Input
#   x - numeric value
#   tol - (optional) definied tolerance
# Output
#   not negative integer representing number of significant digits
# ############################################################################
find_signif <- function(x, tol = 1e-2)
{
    if (x == 0) { return (0) }
    p <- 0
    while (abs(1 - round(x, digits = p) / x) > tol) {
        p <- p + 1
    }
    return (p)
}
