/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex_vart.cpp
 * \brief Time indexed variables.
 */

#include <error.h>
#include <ex_vart.h>
#include <ex_num.h>
#include <ops.h>
#include <utils.h>
#include <climits>


using namespace symbolic;
using namespace symbolic::internal;

ex_vart::ex_vart(const std::string &n, int l)
	: ex_base(VART | ((l == INT_MIN) ? 0 : HAST) | SINGLE), m_name(n), m_lag(l)
{
}

ptr_base
ex_vart::create(const std::string &n, int l)
{
	return ptr_base(new ex_vart(n, l));
}


void
ex_vart::destroy(ex_base *ptr)
{
	delete ptr;
}


ptr_base
ex_vart::copy() const
{
	return ptr_base(new ex_vart(m_name, m_lag));
}


ptr_base
ex_vart::copy0() const
{
	return ptr_base(new ex_vart(m_name, 0));
}


int
ex_vart::compare(const ex_vart &b) const
{
    if (m_lag < b.m_lag) return -1;
    if (m_lag > b.m_lag) return 1;
    return compare_name(b);
}


int
ex_vart::compare_name(const ex_vart &b) const
{
    return m_name.compare(b.m_name);
}




std::string
ex_vart::str(print_flag pflag) const
{
    switch (pflag) {
        case DEFAULT:
            if (m_lag == INT_MIN) return m_name + "[ss]";
            else if (m_lag == 0) return m_name + "[]";
            else return m_name + '[' + num2str(m_lag) + ']';
        case CONVERT_T_IDX:
            if (m_lag == INT_MIN) return m_name + "_ss";
            if (m_lag < 0) return m_name + "_tm" + num2str(-m_lag);
            if (m_lag == 0) return m_name + "_t";
            return m_name + "_tp" + num2str(m_lag);
        case DROP_T_IDX:
            return m_name;
        default:
            USER_ERROR("invalid print flag in ex_vart::str()")
    }
}


std::string
ex_vart::tex(print_flag pflag) const
{
    switch (pflag) {
        case DEFAULT:
            if (m_lag == INT_MIN) return str2tex(m_name) + "_\\mathrm{ss}";
            if (m_lag == 0) return str2tex(m_name) + "_{t}";
            if (m_lag < 0) return str2tex(m_name) + "_{t" + num2str(m_lag) + '}';
            return str2tex(m_name) + "_{t+" + num2str(m_lag) + '}';
        case DROP_T_IDX:
            return str2tex(m_name);
        default:
            USER_ERROR("invalid print flag in ex_vart::tex()")
    }
}


int
ex_vart::get_lag_max(bool) const
{
    return m_lag;
}


int
ex_vart::get_lag_min(bool) const
{
    if (m_lag == INT_MIN) return INT_MAX;
    return m_lag;
}


ptr_base
ex_vart::diff(const ptr_base &p) const
{
    if (p->type() == VART) {
        const ex_vart *pp = static_cast<const ex_vart*>(p.get());
        if (!compare(*pp)) return ex_num::one();
    }
    return ex_num::zero();
}


ptr_base
ex_vart::subst(const ptr_base &what, const ptr_base &with, bool all_leads_lags) const
{
    if (what->type() != VART) return copy();
    const ex_vart *pw = static_cast<const ex_vart*>(what.get());
    if (!all_leads_lags) {
        if (compare(*pw)) return copy();
        return with;
    }
    if (!compare_name(*pw)) {
        if (m_lag == INT_MIN) return ss(with);
        return symbolic::internal::lag(with, m_lag - pw->m_lag);
    }
    return copy();
}


ptr_base
ex_vart::lag(int l) const
{
    return create(m_name, m_lag + l);
}








