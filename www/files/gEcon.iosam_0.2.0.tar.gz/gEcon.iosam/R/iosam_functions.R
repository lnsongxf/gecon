# ############################################################################
# This file is a part of gEcon.iosam.                                        #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Marta Retkiewicz 2015-2016                                             #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Author: Marta Retkiewicz                                                   #
# ############################################################################
# Functions acting on objects of class iosam
# ############################################################################

#' Importing tables from a .csv file
#'
#' Functions that import data from files and create \code{iosam} objects:
#' \code{read_iosam} is an universal function while
#' \code{read_from_database} is designed to import Input-Output Tables
#' from Eurostat and the World Input-Output Database or Social
#' Accounting Matrices from the GTAP database.
#' For tables from Eurostat and WIOD, it is required to change the
#' cells format to numeric before importing.
#'
#' @name iosam-import
#'
#' @param filename the location of a .csv file.
#' @param database a character string, source of the imported table
#'          ('eurostat', 'wiod' or 'gtap').
#' @param add (default TRUE) logical, should the output table include
#'            rows and columns with additional data?
#' @param sep (default ;) the field separator character.
#' @param dec (default ,) the character used in the file for decimal
#'          points.
#' @param nproducts a numeric vector, the number of products (or
#'          sectors) in the imported table.
#' @param table_ind a numeric vector, indices of the first element of
#'            the imported matrix, giving the row with column labels
#'          and the column with row labels.
#' @param data_ind a numeric vector, indices of the first data element.
#' @param data_dim a numeric vector, dimensions of the matrix with data.
#' @param products_ind a numeric vector, indices of the first element
#'          from the intermediate outputs' matrix (if not specified
#'          c(1, 1) will be taken).
#'
#' @return An object of \code{iosam} class.
#'
#' @keywords IO SAM iosam
#'
#' @examples
#' file <- file.path(system.file("extdata", package="gEcon.iosam"),
#'                   "iot_eurostat.csv")
#' pl_input_output <- read_from_database(file, database = 'eurostat',
#'                                       add = TRUE)
#' summary(pl_input_output)
#' View(as.matrix(pl_input_output))
#'
#' data_file <- file.path(system.file("extdata", package = "gEcon.iosam"),
#'              "calibr_sam.csv")
#' sam <- read_iosam(data_file,
#'                   nproducts = c(8, 8),
#'                   table_ind = c(2, 2),
#'                   data_ind = c(3, 3),
#'                   data_dim = c(18, 18),
#'                   products_ind = c(10, 10))
#' summary(sam)
#' View(as.matrix(sam))
#'
#' # Run the following code to copy the file with a detailed example to
#' # your current working directory.
#' \dontrun{
#' file.copy(file.path(system.file("examples", package="gEcon.iosam"),
#'                     "databases.R"), getwd())
#' }
#'
#' @export
#'
read_iosam <- function(filename,
                       sep = ";",
                       dec = ",",
                       nproducts,
                       table_ind,
                       data_ind,
                       data_dim,
                       add = TRUE,
                       products_ind)
{
    if (missing(filename)) stop("argument 'filename' has to be provided")
    if (missing(nproducts)) stop("argument 'nproducts' has to be provided")
    if (missing(table_ind)) stop("argument 'table_ind' has to be provided")
    if (missing(data_ind)) stop("argument 'data_ind' has to be provided")
    if (missing(data_dim)) stop("argument 'data_dim' has to be provided")
    if (nproducts[1] != nproducts[2])
        stop("the number of products in rows and columns has to be equal")
    if (missing(products_ind)) products_ind <- c(1, 1)

    skip <- table_ind[1] - 1
    n1 <- data_ind[1] - table_ind[1]

    io1 <- read.csv(file = filename, sep = sep, dec = dec,
                    stringsAsFactors = FALSE, skip = skip)
    io1[is.na(io1)] <- 0
    io2 <- as.matrix(io1[n1 : (n1 + data_dim[1] - 1),
               data_ind[2] : (data_dim[2] + data_ind[2] - 1)])

    rows <- io1[n1 : (n1 + data_dim[1] - 1), table_ind[2]]
    cols <- colnames(io1)[data_ind[2] : (data_dim[2] + data_ind[2] - 1)]
    cols[1 : nproducts[1]] <- rows[1 : nproducts[1]]

    out <- iosam(flowdata = io2,
                 nproducts = nproducts,
                 rows = rows,
                 columns = cols,
                 products_ind = products_ind)

    if (add) return(out) else return(products_x_products(out))
}

#' @rdname iosam-import
#'
#' @export
#'
read_from_database <- function(filename, database, add = TRUE)
{
    if (database == "eurostat") {
        io1 <- read_iosam(filename = filename, nproducts = c(59, 59),
                          table_ind = c(5, 3), data_ind = c(8, 4),
                          data_dim = c(77, 76), add = add,
                          products_ind = c(1, 1))
        columns <- read.csv(file = filename, sep = ";", header = F,
                            skip = 4, nrows = 1, stringsAsFactors = F)
        if (add) {
            io1@columns <- unlist(columns[4 : 79], use.names = FALSE)
        } else {
            io1@columns <- unlist(columns[4 : 62], use.names = FALSE)
        }
        return(io1)

    } else {
        if (database == "wiod") {
            io1 <- read_iosam(filename = filename, nproducts = c(35, 35),
                              table_ind = c(6, 2), data_ind = c(7, 5),
                              data_dim = c(78, 42), add = add)
            columns <- read.csv(file = filename, sep = ";", header = F,
                                skip = 3, nrows = 1, stringsAsFactors = F)
            if (add) {
                io1@columns <- unlist(columns[5 : length(columns)],
                                      use.names = FALSE)
            } else {
                io1@columns <- unlist(columns[5 : 39], use.names = FALSE)
            }
            return(io1)

        } else {
            if (database == "gtap") {
                io1 <- read_iosam(filename = filename, nproducts = c(114, 114),
                                  table_ind = c(1, 1), data_ind = c(2, 2),
                                  data_dim = c(1109, 1109), add = add,
                                  products_ind = c(1, 1))
                io1@columns <- io1@rows
                return(io1)
            } else {
                stop("incorrect database name")
            }
        }
    }
}

#' @title Export to LaTeX
#'
#' @description Function \code{iosam_to_tex} exports \code{iosam} objects
#'              to LaTeX tables. For compilation of LaTeX code
#'              \code{tabularx} LaTeX package is required.
#'
#' @param x an object of \code{iosam} class.
#'
#' @return LaTeX code.
#'
#' @keywords IO SAM iosam
#'
#' @export
#'
iosam_to_tex <- function(x)
{
    if (!is(x, "iosam")) stop("argument is not of iosam class")

    m <- nrow(x@flowdata)
    n <- ncol(x@flowdata)
    values <- matrix(0, m, 1)
    rows <- x@rows
    columns <- x@columns

    for (i in 1:m) {
        values[i, 1] <- (paste(x@flowdata[i, ], collapse = " & "))
    }

    part1 <- paste(rep("X", n), collapse = " ")
    part2 <- paste(columns, collapse = " & ")
    part3 <- paste(rows, values, sep = " & ", collapse = " \\\\ ")

    parts <- c("\\begin{table}[h]\n\\centering\n\\begin{tabularx}{\\textwidth}{|X|",
               part1, "|}\n\\hline\n& ",
               part2, " \\\\\n\\hline\n",
               part3,
               " \\\\\n\\hline\n\\end{tabularx}\n\\caption{Caption}\n\n\\end{table}")

    return(writeLines(parts))
}

#' @title Aggregation
#'
#' @description Function \code{aggregate_iosam} aggregates objects
#'              of \code{iosam} class.
#'
#' @param x an object of \code{iosam} class.
#' @param map a data frame with the map for aggregation. Its first
#'          vector should correspond to x labels in rows.
#' @param map_columns a data frame with the map for columns' aggregation
#'          (optional, used only if the table is non symmetric). Its first
#'          vector should correspond to x labels in columns.
#'
#' @return An object of \code{iosam} class with aggregated data.
#'
#' @keywords IO SAM iosam
#'
#' @examples
#' flowdata <- matrix(c(0, 0, 0, 38.1, 95.74, 133.84, 0, 0, 0, 9.44, 78.80,
#'                      88.24, 133.84, 88.24, 0, 0, 0, 222.08, 0, 0, 117.39,
#'                      68.4, 159.29, 345.08, 0, 0, 104.69, 229.14, 334.57,
#'                      668.4, 133.84, 88.24, 222.08, 345.08, 668.4, 0),
#'                    6, 6,
#'                    byrow = TRUE)
#' rows <- c("L", "K", "Household", "SectorA", "SectorB", "Total")
#' x <- iosam(flowdata, nproducts = c(2, 2),
#'            rows = rows, products_ind = c(4, 4))
#' x
#' map2 <- c("Factor", "Factor", "Household",
#'           "Sectors", "Sectors", "Total")
#' map <- data.frame(rows, map2, stringsAsFactors = FALSE)
#' xa <- aggregate_iosam(x, map)
#' xa
#'
#'
#' # Run the following code to copy the file with additional examples to
#' # your current working directory.
#' \dontrun{
#' file.copy(file.path(system.file("examples", package="gEcon.iosam"),
#'                   "databases.R"), getwd())
#' }
#'
#' @export
#'
aggregate_iosam <- function(x, map, map_columns)
{
    if (!is(x, "iosam")) stop("argument is not of iosam class")
    if (missing(map)) stop("argument 'map' has to be provided")

    # Map check
    if ((nrow(x) == ncol(x)) && all(x@rows == x@columns)) map_columns <- map
    if (any(x@rows != map[[1]])) stop("labels in x and map disagree")
    if (any(x@columns != map_columns[[1]]))
        stop("labels in x and map_columns disagree")
    map2 <- map_columns

    #
    u_map <- as.vector(unique(map[[2]]))
    u_map2 <- as.vector(unique(map2[[2]]))
    n <- length(map[[1]])
    m <- length(u_map)
    n2 <- length(map2[[1]])
    m2 <- length(u_map2)

    # Creating the indexes' matrices
    A1 <- matrix(0, m, n)
    for (i in 1:n) {
        for (j in 1:m) {
            if (map[[i, 2]] == u_map[j]) {
                A1[j, i] = 1
            }
        }
    }
    A2 <- matrix(0, m2, n2)
    for (i in 1:n2) {
        for (j in 1:m2) {
            if (map2[[i, 2]] == u_map2[j]) {
                A2[j, i] = 1
            }
        }
    }

    # Creating the aggregated matrix
    B1 <- matrix(0, m, n2)
    for (i in 1:m) {
        a <- which(A1[i, ] != 0)
        B1[i, ] = colSums(rbind(x@flowdata[a, ], rep(0, n2)))
    }
    B2 <- matrix(0, m, m2)
    for (i in 1:m2) {
        a <- which(A2[i, ] != 0)
        B2[, i] = rowSums(cbind(B1[, a], rep(0, m)))
    }

    # Output
    ind1 <- length(unique(map[[2]][1 : x@products_ind[1]]))
    ind2 <- length(unique(map2[[2]][1 : x@products_ind[2]]))
    u_products <- unique(map[[2]][x@products_ind[1] :
                                  (x@products_ind[1] + x@nproducts[1] - 1)])
    u_products <- length(u_products)
    return(iosam(B2, nproducts = c(u_products, u_products),
                  rows = u_map,
                  columns = u_map2,
                  products_ind = c(ind1, ind2)))
}

