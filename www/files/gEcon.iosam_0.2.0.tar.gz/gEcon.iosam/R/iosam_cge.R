# ############################################################################
# This file is a part of gEcon.iosam.                                        #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Marta Retkiewicz 2015-2016                                             #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Author: Marta Retkiewicz                                                   #
# ############################################################################
# get_flow_values function
# ############################################################################

#' Getting flow values from matrices and \code{iosam} objects
#'
#' Function \code{get_flow_values} returns a list with variables
#' in format "X__RowA__ColumnB" and their values.
#' \itemize{
#'    \item If x is a matrix or a vector, the list contains variables
#'    for all its elements. In this case, parameter 'rows' (and
#'    'columns') is required.
#'    \item If x is an Input-Output Table of \code{iosam} class or a
#'    part of an \code{iosam} object, the list contains variables for
#'    all its elements as well, but the parameters 'rows' and
#'    'columns' are optional - when not provided, appropriate
#'    labels are used.
#'    \item  If x is a Social Accounting Matrix of \code{iosam} class,
#'    only the part which constitutes an Input-Output Table is used.
#'    Parameters 'rows' and 'columns' are optional.}
#'
#' @param x a vector, matrix, object of \code{iosam} class or its part.
#' @param prefix (default "X") the name of the output variable.
#' @param rows a vector with sectors' names corresponding to the rows
#'             of x (and columns, if parameter 'columns' is missing and
#'             both dimensions of x are greater than 1) to be added to
#'             the output variable's name.
#' @param columns a vector with sectors' names corresponding to the
#'             columns of x to be added to the output variable's name
#'             (optional).
#'
#' @return A named list with selected data.
#'
#' @keywords IO SAM iosam gEcon
#'
#' @examples
#' flowdata <- matrix(c(0, 0, 0, 38.1, 95.74, 133.84, 0, 0, 0, 9.44, 78.80,
#'                      88.24, 133.84, 88.24, 0, 0, 0, 222.08, 0, 0, 117.39,
#'                      68.4, 159.29, 345.08, 0, 0, 104.69, 229.14, 334.57,
#'                      668.4, 133.84, 88.24, 222.08, 345.08, 668.4, 0),
#'                    6, 6,
#'                    byrow = TRUE)
#' rows <- c("L", "K", "Household", "SectorA", "SectorB", "Total")
#' x <- iosam(flowdata, nproducts = c(2, 2),
#'            rows = rows, products_ind = c(4, 4))
#' get_flow_values(x)
#' get_flow_values(x, rows = c("A", "B"), columns = c("A", "B"))
#' get_flow_values(x[1, 4:5], rows = c("L"), columns = c("A", "B"))
#' get_flow_values(x[c("L", "K"), c("SectorA", "SectorB")])
#'
#'
#' # Run the following code to copy the file with a more detailed example
#' # (CGE model calibration) to your current working directory.
#' \dontrun{
#' file.copy(file.path(system.file("examples", package = "gEcon.iosam"),
#'                   "cge_calibr_iosam.R"), getwd())
#' file.copy(file.path(system.file("examples", package = "gEcon.iosam"),
#'                   "cge_calibr_iosam.gcn"), getwd())
#' }
#'
#' @export
#'
get_flow_values <- function(x, prefix = "X", rows, columns)
{
    if (missing(x)) stop("argument 'x' has to be provided")

    if (is(x, "iosam")) {
        x <- products_x_products(x)
        if (missing(rows)) rows <- x@rows
        x2 <- x@flowdata
        dimnames(x2) <- list(c(x@rows), c(x@columns))
    } else {
        if (missing(rows)) {
            if (is.null(rownames(x))) {
                stop("row names have to be provided")
            } else {
                rows <- rownames(x)
            }
        }
        x2 <- as.matrix(x)
    }

    prefix <- rep(prefix, (dim(x2)[1] * dim(x2)[2]))
    name <- rep(0, (dim(x2)[1] * dim(x2)[2]))
    out <- as.list(x2)

    m1 <- matrix(rows, dim(x2)[1], dim(x2)[2])
    m1 <- as.vector(m1)

    if (missing(columns)) {
        if (any(dim(x2) == 1)) {
            name <- paste(prefix, m1, sep = "__")
            names(out) <- name
            two_dim <- FALSE
            return(out)
        } else {
            if (is.null(colnames(x))) {
                if (nrow(x2) == ncol(x2)) {
                    columns <- rows
                } else {
                    stop("column names have to be provided")
                }
            } else {
                columns <- colnames(x)
            }
            two_dim <- TRUE
        }
    } else {
        two_dim <- TRUE
    }

    if (two_dim) {
        m2 <- matrix(columns, dim(x2)[1], dim(x2)[2], byrow = TRUE)
        m2 <- as.vector(m2)
        name <- paste(prefix, m1, m2, sep = "__")
        names(out) <- name
        return(out)
    }
}
