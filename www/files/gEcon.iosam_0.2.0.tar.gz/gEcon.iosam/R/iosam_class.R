# ############################################################################
# This file is a part of gEcon.iosam.                                        #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Marta Retkiewicz 2015-2016                                             #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Author: Marta Retkiewicz                                                   #
# ############################################################################
# Definition for iosam class, functions and methods for accessing its contents
# ############################################################################

#' Input-Output Tables and Social Accounting Matrices for gEcon
#'
#' Package \code{gEcon.iosam} simplifies calibration of CGE (and multisector DSGE)
#' models in \code{gEcon} and provides functions for operating on Input-Output Tables
#' and Social Accounting Matrices.
#'
#' The package provides \code{iosam} class for representing Input-Output Tables
#' and Social Accounting Matrices and a set of functions for importing and manipulating
#' them. To streamline the process of calibration of CGE (and multisector DSGE) models
#' written using \code{gEcon} template mechanism, function \code{get_flow_values}
#' is provided.
#'
#' @name gEcon.iosam-package
#'
#' @author Marta Retkiewicz <marta.retkiewicz@@gmail.com>, design by Grzegorz Klima
#'
#' @keywords package
#'
#' @examples
#'
#' # Run the following code to copy the file with an example
#' # of CGE model calibration to your current working directory.
#' \dontrun{
#' file.copy(file.path(system.file("examples", package = "gEcon.iosam"),
#'                   "cge_calibr_iosam.R"), getwd())
#' file.copy(file.path(system.file("examples", package = "gEcon.iosam"),
#'                   "cge_calibr_iosam.gcn"), getwd())
#' }
#'
#' # Run the following code to copy the file with examples of data imports
#' # to your current working directory.
#' \dontrun{
#' file.copy(file.path(system.file("examples", package="gEcon.iosam"),
#'                     "databases.R"), getwd())
#' }
#'
#' @import methods utils gEcon
NULL

#' Class definition for \code{iosam}
#'
#' @slot flowdata a matrix with values of intermediate inputs (and
#'            additional data).
#' @slot nproducts a numeric vector giving the number of products in
#'            rows and columns (for an Input-Output Table without
#'          additional data, it is equal to the flowdata dimensions).
#' @slot rows a vector with labels for rows.
#' @slot columns a vector with labels for columns.
#' @slot products_ind a vector giving the location of the
#'            Input-Output Table.
#'
#'
#' @export
#'
setClass("iosam", representation(flowdata = "matrix",
                                 nproducts = "vector",
                                 rows = "vector",
                                 columns = "vector",
                                 products_ind = "vector"))

#' Constructor of objects of \code{iosam} class
#'
#' @param flowdata a matrix with the values of intermediate outputs
#'            (and additional data).
#' @param nproducts a numeric vector giving the number of products in
#'            rows and columns (for an Input-Output Table without
#'          additional data, it is equal to the flowdata dimensions).
#' @param rows a vector giving the labels for rows (and for
#'            columns, if parameter 'columns' is missing).
#' @param columns (default NULL) a vector giving the labels for
#'            columns. If missing, labels from parameter 'rows' will be taken.
#' @param products_ind (default c(1,1)) a numeric vector with the
#'            location of the Input-Output Table's first element in the whole
#'          matrix (for IO Tables - equal to c(1,1), for Social Accounting
#'          Matrices - usually different from c(1,1)).
#'
#' @return An object of \code{iosam} class.
#'
#' @keywords classes IO SAM iosam
#'
#' @examples
#' flowdata <- matrix(c(0, 0, 0, 38.1, 95.74, 133.84, 0, 0, 0, 9.44, 78.80,
#'                      88.24, 133.84, 88.24, 0, 0, 0, 222.08, 0, 0, 117.39,
#'                      68.4, 159.29, 345.08, 0, 0, 104.69, 229.14, 334.57,
#'                      668.4, 133.84, 88.24, 222.08, 345.08, 668.4, 0),
#'                    6, 6,
#'                    byrow = TRUE)
#' rows <- c("L", "K", "Household", "SectorA", "SectorB", "Total")
#' x <- iosam(flowdata, nproducts = c(2, 2),
#'            rows = rows, products_ind = c(4, 4))
#' x
#' summary(x)
#'
#' @export
#'
iosam <- function(flowdata, nproducts, rows,
                  columns = NULL, products_ind = c(1, 1))
{
    if (missing(flowdata)) stop("argument 'flowdata' has to be provided")
    if (missing(nproducts)) stop("argument 'nproducts' has to be provided")
    if (missing(rows)) stop("argument 'rows' has to be provided")
    if (missing(columns)) columns <- rows

    rows_p <- rows[products_ind[1] : (products_ind[1] + nproducts[1] - 1)]
    cols_p <- columns[products_ind[2] : (products_ind[2] + nproducts[2] - 1)]
    if (length(unique(rows_p)) != length(rows_p))
        stop("products labels for rows have to be unique")
    if (length(unique(cols_p)) != length(cols_p))
        stop("products labels for columns have to be unique")

    if (nrow(flowdata) != (length(rows)))
        stop("the size of data disagree with the number of row labels")
    if (ncol(flowdata) != (length(columns)))
        stop("the size of data disagree with the number of column labels")

    return(new("iosam", flowdata = flowdata,
                        nproducts = nproducts,
                        rows = rows,
                        columns = columns,
                        products_ind = products_ind))
}

#' Retrieving data
#'
#' Functions for accessing the contents of \code{iosam} objects.
#'
#' @name iosam-get-data
#'
#' @param x an object of \code{iosam} class.
#'
#' @return The content of x.
#'
#' @keywords attribute IO SAM iosam
#'
#'
#' @export
#'
get_flowdata <- function(x)
{
    if (is(x, "iosam")) {
        return(x@flowdata)
    } else stop("argument is not of iosam class")
}

#' @rdname iosam-get-data
#'
#' @export
#'
get_products <- function(x)
{
    if (is(x, "iosam")) {
        return(list(x@rows[x@products_ind[1] :
                    (x@products_ind[1] + x@nproducts[1] - 1)],
                    x@columns[x@products_ind[2] :
                    (x@products_ind[2] + x@nproducts[2] - 1)]))
    } else stop("argument is not of iosam class")
}

#' @rdname iosam-get-data
#'
#' @export
#'
get_add_rows <- function(x)
{
    if (!is(x, "iosam")) stop("argument is not of iosam class")
    add <- vector("list", 2)

    if (x@nproducts[1] != nrow(x)) {
        if (x@products_ind[1] != 1) {
            add[[1]] <- x@rows[1 : (x@products_ind[1] - 1)]
        }
        if ((x@products_ind[1] + x@nproducts[1] - 1) != dim(x)[1]) {
            add[[2]] <- x@rows[(x@products_ind[1] + x@nproducts[1]) :
                               length(x@rows)]
        }
    }
    return(add)
}

#' @rdname iosam-get-data
#'
#' @export
#'
get_add_columns <- function(x)
{
    if (!is(x, "iosam")) stop("argument is not of iosam class")
    add <- vector("list", 2)

    if (x@nproducts[2] != ncol(x)) {
        if (x@products_ind[2] != 1) {
            add[[1]] <- x@columns[1 : (x@products_ind[2] - 1)]
        }
        if ((x@products_ind[2] + x@nproducts[2] - 1) != dim(x)[2]) {
            add[[2]] <- x@columns[(x@products_ind[2] + x@nproducts[2]) :
                                  length(x@columns)]
        }
    }
    return(add)
}

#' Retrieving the Input-Output Table
#'
#' Function for retrieving the IO Table from an \code{iosam} object.
#'
#' @param x an object of \code{iosam} class.
#'
#' @return An object of \code{iosam} class with the part of x that constitutes
#'         an Input-Output Table.
#'
#'
#' @keywords attribute IO SAM iosam
#'
#' @export
#'
products_x_products <- function(x)
{
    if (is(x, "iosam")) {
        if (any(x@nproducts != dim(x))) {
            rows <- x@rows[x@products_ind[1] :
                           (x@products_ind[1] + x@nproducts[1] - 1)]
            columns <- x@columns[x@products_ind[2] :
                                 (x@products_ind[2] + x@nproducts[2] - 1)]
            flowdata <- x@flowdata[x@products_ind[1] :
                                   (x@products_ind[1] + x@nproducts[1] - 1),
                                   x@products_ind[2] :
                                   (x@products_ind[2] + x@nproducts[2] - 1)]
            return(iosam(flowdata, nproducts = x@nproducts, rows = rows,
                        columns = columns, products_ind = c(1, 1)))
        } else {
            return(x)
        }
    } else stop("argument is not of iosam class")
}

#' Coercion to matrix
#'
#' Method for coercing an \code{iosam} object to matrix.
#'
#' @param x object of \code{iosam} class.
#'
#' @return The underlying matrix.
#'
#' @keywords IO SAM iosam methods
#'
#' @aliases as.matrix,iosam-method
#' @export
#'
setMethod(
    "as.matrix",
    signature(x = "iosam"),
    function(x) {
        mat <- x@flowdata
        dimnames(mat) <- list(c(x@rows), c(x@columns))
        return(mat)
    }
)

#' Accessing attributes
#'
#' Methods for accessing and setting attributes of \code{iosam} objects.
#'
#' @param x an object of \code{iosam} class.
#' @param value a character vector with labels for rows or columns.
#'
#' @keywords attribute IO SAM iosam methods
#'
#' @name iosam-attributes
#' @aliases nrow,iosam-method
#'
#' @export
#'
setMethod(
    "nrow",
    signature(x = "iosam"),
    function(x) {
        return(nrow(x@flowdata))
    }
)

#' @rdname iosam-attributes
#'
#' @export
#'
setMethod(
    "ncol",
    signature(x = "iosam"),
    function(x) {
        return(ncol(x@flowdata))
    }
)

#' @rdname iosam-attributes
#'
#' @export
#'
setMethod(
    "dim",
    signature(x = "iosam"),
    function(x) {
        return(dim(x@flowdata))
    }
)

#' @rdname iosam-attributes
#'
#' @export
#'
setMethod(
    "length",
    signature(x = "iosam"),
    function(x) {
        return(length(x@flowdata))
    }
)

#' @rdname iosam-attributes
#'
#' @export
#'
setMethod(
    "rownames",
    signature(x = "iosam"),
    function(x) {
        return(c(x@rows))
    }
)

#' @rdname iosam-attributes
#' @export
#'
setMethod(
    "rownames<-",
    signature(x = "iosam", value = "character"),
    function(x, value) {
        if (length(value) != nrow(x))
            stop("products and flowdata sizes disagree")
        if (length(value) != length(unique(value)))
            stop("products labels have to be unique")
        x@rows <- value
        return(x)
    }
)

#' @rdname iosam-attributes
#'
#' @export
#'
setMethod(
    "colnames",
    signature(x = "iosam"),
    function(x) {
        return(c(x@columns))
    }
)

#' @rdname iosam-attributes
#' @export
#'
setMethod(
    "colnames<-",
    signature(x = "iosam", value = "character"),
    function(x, value) {
        if (length(value) != ncol(x))
            stop("products and flowdata sizes disagree")
        if (length(value) != length(unique(value)))
            stop("products labels have to be unique")
        x@columns <- value
        return(x)
    }
)

#' Transposition
#'
#' Transposition of \code{iosam} objects.
#'
#' @param x an object of \code{iosam} class.
#'
#' @return An object of \code{iosam} class with transposed data.
#'
#' @keywords IO SAM iosam methods
#'
#' @export
#'
setMethod(
    "t",
    signature = c(x = "iosam"),
    function(x) {
        return(iosam(t(x@flowdata),
                    nproducts = c(x@nproducts[2], x@nproducts[1]),
                    rows = x@columns,
                    columns = x@rows,
                    products_ind = x@products_ind))
    }
)


#' Overloading mathematical operators
#'
#' @param x an object of \code{iosam} class.
#' @param e1 an object of \code{iosam} class or numeric.
#' @param e2 an object of \code{iosam} class or numeric.
#'
#' @return Depending on type of operation an object of the \code{iosam}
#' class or numeric with the result.
#'
#' @keywords arith IO SAM iosam methods
#'
#' @name iosam-math
#' @aliases sum,iosam-method
#'
#' @export
#'
setMethod(
    "sum",
    signature(x = "iosam"),
    function(x) {
        return(sum(x@flowdata))
    }
)

#' @rdname iosam-math
#'
#' @export
#'
setMethod(
    "max",
    signature(x = "iosam"),
    function(x) {
        return(max(x@flowdata))
    }
)

#' @rdname iosam-math
#'
#' @export
#'
setMethod(
    "min",
    signature(x = "iosam"),
    function(x) {
        return(min(x@flowdata))
    }
)

#' @rdname iosam-math
#'
#' @export
#'
setMethod(
    "mean",
    signature(x = "iosam"),
    function(x) {
        return(mean(x@flowdata))
    }
)

#' @rdname iosam-math
#'
#' @export
#'
setMethod(
    "rowSums",
    signature(x = "iosam"),
    function(x) {
        return(rowSums(x@flowdata))
    }
)

#' @rdname iosam-math
#'
#' @export
#'
setMethod(
    "colSums",
    signature(x = "iosam"),
    function(x) {
        return(colSums(x@flowdata))
    }
)

#' @rdname iosam-math
#'
#' @export
#'
setMethod(
    "Arith",
    c("iosam", "numeric"),
    function(e1, e2) {
        e1@flowdata <- callGeneric(e1@flowdata, e2)
        return(e1)
    }
)

#' @rdname iosam-math
#'
#' @export
#'
setMethod(
    "Arith",
    c("iosam", "iosam"),
    function(e1, e2) {
        e1@flowdata <- callGeneric(e1@flowdata, e2@flowdata)
        return(e1)
    }
)

#' @rdname iosam-math
#'
#' @export
#'
setMethod(
    "Arith",
    c("numeric", "iosam"),
    function(e1, e2) {
        e2@flowdata <- callGeneric(e1, e2@flowdata)
        return(e2)
    }
)

#' Displaying objects of \code{iosam} class
#'
#' @param x an object of \code{iosam} class.
#' @param object an object of \code{iosam} class.
#'
#' @keywords IO SAM iosam methods print
#'
#' @name iosam-display
#'
#' @aliases print,iosam-method
#' @export
#'
setMethod(
    "print",
    signature(x = "iosam"),
    function(x) {
        fd <- x@flowdata
        dimnames(fd) <- list(c(x@rows), c(x@columns))
        print(fd)
    }
)

#' @rdname iosam-display
#'
#' @export
#'
setMethod(
    "show",
    signature(object = "iosam"),
    function(object) {
        fd <- object@flowdata
        dimnames(fd) <- list(c(object@rows), c(object@columns))
        show(fd)
    }
)

#' @rdname iosam-display
#'
#' @export
#'
setMethod(
    "summary",
    signature(object = "iosam"),
    function(object) {
        if (all(object@nproducts == dim(object))) {
            add <- FALSE
            cat('This is an input-output table.\n')
        } else {
        add <- TRUE
            if (any(object@products_ind != c(1, 1))) {
                cat('This is a social accounting matrix.\n')
            } else {
                cat('This is an input-output table.\n')
            }
        }
        cat('\nDimensions:', nrow(object), 'x', ncol(object), '\n')
        if (add) cat('Number of products:', object@nproducts[1],
                     'x', object@nproducts[2], '\n')

        products <- get_products(object)
        ind_r <- c(object@products_ind[1],
                   (object@products_ind[1] + object@nproducts[1] - 1))
        ind_c <- c(object@products_ind[2],
                   (object@products_ind[2] + object@nproducts[2] - 1))
        cat('\nProducts:\n')
        if(add) cat('[', ind_r[1], '-', ind_r[2], '] ')
        cat(products[[1]], sep = ', ')
        cat('\n')

        l <- c(length(products[[1]]), length(products[[2]]))
        if (any(c(products[[1]], rep(0, l[2])) !=
                c(products[[2]], rep(0, l[1])))) {
            if (add) cat('\n[', ind_c[1], '-', ind_c[2], '] ')
            cat(products[[2]], sep = ', ')
            cat('\n')
        }

        if (add) {
            add_r <- get_add_rows(object)
            add_c <- get_add_columns(object)
            if (!(is.null(add_r[[1]]) && is.null(add_r[[2]])))
                cat('\nAdditional rows:\n')
            if (!(is.null(add_r[[1]]))) {
                cat('[ 1 -', ind_r[1] - 1, '] ')
                cat(add_r[[1]], sep=', ')
                cat('\n')
            }
            if (!(is.null(add_r[[2]]))) {
                cat('[', ind_r[2] + 1, '-', nrow(object), '] ')
                cat(add_r[[2]], sep = ', ')
                cat('\n')
            }
            if (!(is.null(add_c[[1]]) && is.null(add_c[[2]])))
                cat('\nAdditional columns:\n')
            if (!(is.null(add_c[[1]]))) {
                cat('[ 1 -', ind_c[1] - 1, '] ')
                cat(add_c[[1]], sep = ', ')
                cat('\n')
            }
            if (!(is.null(add_c[[2]]))) {
                cat('[', ind_c[2] + 1, '-', ncol(object), '] ')
                cat(add_c[[2]], sep = ', ')
            }
        }
    }
)

#' Indexing objects of \code{iosam} class
#'
#' Selecting values from underlying data matrix as in
#'           matrix[i, j], matrix[, j] or matrix[i, ].
#'
#' @name iosam-indexing
#'
#' @param x an object of \code{iosam} class.
#' @param i a numeric or character vector, rows to be selected.
#' @param j a numeric or character vector, columns to be selected.
#'
#' @return Matrix with selected values.
#'
#' @keywords IO SAM iosam methods
#'
#' @aliases [,iosam,vector,vector,ANY-method
#' @export
#'
setMethod(
    "[",
    signature = c(x = "iosam", i = "vector", j = "vector"),
    function(x, i, j) {

        if (is.character(i)) {
            ii <- rep(0, length(i))
            for (a in 1 : length(i)) {
                if (all(x@rows != i[a])) stop("invalid label name")
                ii[a] <- which(x@rows == i[a])
            }
            i <- ii
        }
        if (is.character(j)) {
            jj <- rep(0, length(j))
            for (a in 1 : length(j)) {
                if (all(x@columns != j[a])) stop("invalid label name")
                jj[a] <- which(x@columns == j[a])
            }
            j <- jj
        }

        flowdata <- as.matrix(x@flowdata[i, j])
        rows <- x@rows[i]
        columns <- x@columns[j]

        if ((length(i) == 1) && (length(j) > 1)) {
            return(matrix(t(flowdata),
                          nrow = length(rows),
                          ncol = length(columns),
                          dimnames = list(c(rows), c(columns))))
        } else {
            return(matrix(flowdata,
                          nrow = length(rows),
                          ncol = length(columns),
                          dimnames = list(c(rows), c(columns))))
        }
    }
)

#' @rdname iosam-indexing
#'
#' @export
#'
setMethod(
    "[",
    signature = c(x = "iosam", i = "vector", j = "missing"),
    function(x, i, j) {
        if (is.character(i)) {
            ii <- rep(0, length(i))
            for (a in 1 : length(i)) {
                if (all(x@rows != i[a])) stop("invalid label name")
                ii[a] <- which(x@rows == i[a])
            }
            i <- ii
        }
        flowdata <- as.matrix(x@flowdata[i, ])
        rows <- x@rows[i]
        columns <- x@columns
        return(matrix(flowdata, nrow = length(rows), ncol = length(columns),
                        dimnames = list(rows, columns)))
    }
)

#' @rdname iosam-indexing
#'
#' @export
#'
setMethod(
    "[",
    signature = c(x = "iosam", i = "missing", j = "vector"),
    function(x, i, j) {
        if (is.character(j)) {
            jj <- rep(0, length(j))
            for (a in 1 : length(j)) {
                if (all(x@columns != j[a])) stop("invalid label name")
                jj[a] <- which(x@columns == j[a])
            }
            j <- jj
        }
        flowdata <- as.matrix(x@flowdata[, j])
        rows <- x@rows
        columns <- x@columns[j]
        return(matrix(flowdata, nrow = length(rows), ncol = length(columns),
                        dimnames = list(rows, columns)))
    }
)


