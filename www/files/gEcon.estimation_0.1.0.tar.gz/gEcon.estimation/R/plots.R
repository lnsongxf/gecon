# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Michał Marciniak                                                  #
# ############################################################################
# Plotting functions
# ############################################################################

#' Bar Plot
#' 
#' The \code{stackedbar_internal} function creates a bar plot with
#' vertical bars for each category. The function allows for 
#' plotting several variables for each category. 
#' If more than one variable is to be included, data should be passed 
#' as a matrix, with variables in rows and categories in columns.
#'  
#' @param data a numeric matrix (data.frame or vector) with categories 
#'        in columns and variables in rows
#' @param lin a logical value; if \code{TRUE} then sum aof values line (for each 
#'        category) will be drawn
#' @param col bar colours
#' @param main a character string, the title of the plot; by default 
#'        (\code{NULL}), the title is not displayed
#' @param submain a character string, the subtitle of the plot; by default 
#'        (\code{NULL}), the subtitle is not displayed
#' @param xlab a character string with the OX axis label
#' @param ylab a character string with the OY axis label
#' @param legend a logical value; if \code{TRUE}, the legend will be drawn
#' @param legend.text a character vector representing labels used in the legend
#' @param x.axis.at a numeric vector representing OX coordinates of the 
#'        tick-marks to be drawn (values : 1, 2, ... number of categories)
#' @param x.axis.labs a numeric or character vector representing labels to be
#'        drawn (length equal to the number of categories or to the length 
#'        of x.axis.at argument)     
#' @param eps_path the path to save the plot in .eps format; if \code{NULL},
#'        the plot is printed on the R graphics device
#'        
#' @keywords internal
stackedbar_internal <- function(data, lin = TRUE, col = bar_colours, 
                             main = NULL, submain = NULL, 
                             xlab = "period", ylab = "contribution",
                             legend = TRUE, legend.text = NULL, 
                             x.axis.labs = NULL, x.axis.at = NULL,
                             eps_path = NULL)
{
    # internal options
    lin.col <- "black"
    lin.lwd <- 2 
    lin.lty <- 3 
    border <- NA
    box <- T 
    grid <- T
    grid.col <- "gray80"
    space <- 0.2
    main.cex <- 1.3
    submain.cex <- 1
    axes.cex <- 1
    axes.labs.cex <- 1
    legend.cex <- 1
    legend.ncol <- 3
    
    # prepare data
    if (is.null(dim(data)))
        data <- matrix(data, nrow = 1)    
    if (lin) lin.data <- colSums(data, na.rm = T)
    
    # data transformation (stacked values)
    for (j in 1:ncol(data)) {
        neg_sum <- 0
        pos_sum <- 0
        for (i in nrow(data):1) {
            if (data[i, j] > 0) {
                pos_sum <- data[i, j] + pos_sum 
                data[i, j] <- pos_sum
            } else if (data[i, j] < 0) {
                neg_sum <- data[i, j] + neg_sum 
                data[i, j] <- neg_sum                
            }
        }
    }
    
    # adjust arguments
    border <- rep_len(border, nrow(data))       
    col <- rep_len(col, nrow(data))
    
    # prepare x.axis labs
    if (is.null(x.axis.at)) x.axis.at <- 1 : ncol(data)
    if (is.null(x.axis.labs)) x.axis.labs <- x.axis.at
    
    # prepare legends - bars
    if (is.null(legend.text)) rownames(data)
    if (is.null(legend.text)) legend.text <- paste("shock", 1 : nrow(data))
    
    # eps    
    if (!is.null(eps_path)) {
        options(scipen = 1)
        ps.options(family = "serif", encoding = "ISOLatin1")
        setEPS() 
        postscript(eps_path, family = "serif")
        on.exit(dev.off())
    }  
    
    # OY coordinates adjustment
    ylim <- ylim_adj(data = data, forcezero = TRUE)
    
    # margin adjustment
    mar_xy <- set_mar(
        main = main, main.cex = main.cex, submain = submain, 
        submain.cex = submain.cex,  
        ylab = ylab, axes.cex = axes.cex, 
        axes.labs.cex = axes.labs.cex, ylim = ylim, 
        xlab = xlab, legend = legend, legend.bottom = TRUE, 
        legend.cex = legend.cex, legend.text = legend.text, 
        legend.ncol = legend.ncol,  
        data = data)                                              
    
    # init plot
    bx <- barplot(data, ylim = ylim[1:2], col = "white", space = c(-1, space), 
                 border = "white", beside = T, axes = F, xpd = F)
    
    # grid
    if (grid) {
        # vertical
        abline(v = bx[1, ][x.axis.at], lty = 3, col = grid.col)
        # horizontal
        abline(h = seq(from = ylim[1], to = ylim[2], by = ylim[3]), lty = 3, 
               col = grid.col)    
    }
    
    # plot bars
    barplot <- add_bars(data = data, ylim = ylim[1:2], col = col, 
                       space = space, axes.cex = axes.cex, border = border)
    if (box) box()
    
    # line
    if (lin) lines(x = bx[1, ], y = lin.data, col = lin.col, lwd = lin.lwd, 
                   lty = lin.lty)    
    
    # add OY axis
    axis(side = 2, at = seq(ylim[1], ylim[2], by = ylim[3]), 
         labels = gEcon:::pretty_labels(ylim[1], ylim[2], ylim[3]),
         cex.axis = axes.cex, las = 1)
    
    # add OX axis
    axis(side = 1, labels = x.axis.labs[x.axis.at], at = bx[1, ][x.axis.at], 
         cex.axis = axes.cex)
    
    # add graph and axes titles
    add_titles(main = main, main_y = mar_xy$main_y, main.cex, 
               submain = submain, submain.cex = submain.cex,
               axes.labs.cex = axes.labs.cex,
               xlab = xlab, xlab_y = mar_xy$xlab_y, 
               ylab = ylab, ylab_x = mar_xy$ylab_x) 
    
    # add legend
    if (legend == TRUE)
        add_legend(legend.text = legend.text, 
                   legend.ncol = legend.ncol, 
                   fill = col, border = border, box = box, 
                   legend.cex = legend.cex, 
                   legend_y = mar_xy$legend_y, 
                   legend_x = mar_xy$legend_x)
}


#' Adding bars to the plot
#' 
#' @inheritParams stackedbar_internal
#' @param ylim a numeric vector specifying the minimum, maximum, and  
#'        subdivision values (optional) for the OY axis 
#' @param space a numeric value specifying the space between bars
#' @param axes.cex a numeric value of the font size (expansion factor) 
#'        for values on axes
#' @param border the colour to be used for the borders of the bars 
#'        (for details on colour representation see \link{colours});
#'        if \code{NA}, borders are not displayed
#' 
#' @keywords internal
#' 
add_bars <- function(data, ylim, col, space, axes.cex, border) 
{
    # copy of data
    plot_data <- data
    
    # for each category (interval)
    for (i in 1:ncol(data)) {
        
        # for every bar in interval
        while (!all(is.na(plot_data[, i]))) {
            
            # selecting bars between categories
            max_i <- which.max(plot_data[, i])
            if (length(max_i) > 0) {
                # negative value(s)
                if (plot_data[max_i, i] < 0) max_i <- which.min(plot_data[, i])
                # selected data
                act <- matrix(NA, ncol = ncol(data), nrow = nrow(data))
                act[max_i, i] <- plot_data[max_i, i]
                # ploting selected bars
                xbars <- barplot(height = act, ylim = ylim[1:2], col = col, 
                                space = c(-1, space), cex.axis = axes.cex, 
                                border = border, add = TRUE,
                                beside = T, axes = F, xpd = F)
                
                # marked as plotted
                plot_data[max_i, i] <- NA
                add_ <- T
            }
        }
    }
    
    return(xbars)
}

#' Adding grid to the plot
#' 
#' @param data ts object
#' @param ... other arguments of stackedbar_internal function
#' 
#' @keywords internal
#' 
gecon_shock_decomposition <- function(data, ...)
{
    # valid argument
    if (!is.ts(data)) 
        stop("parameter data must represent 'ts' object")
    # getting labels
    freq <- frequency(data)
    n <- nrow(data)
    if (is.null(n)) n <- length(data)
    st <- start(data)
    if (length(st) == 2) 
        st <- st[2] 
    else 
        st <- 1
    x.axis.at <- get_at(n = n, freq = freq, st = st)
    st_ind <- floor(start(data)[1])
    x.axis.labs <- get_ts_ind(st_ind = st_ind, freq = freq, st = st, n = n)
    # plot shocks
    data <- t(as.matrix(data))
    stackedbar_internal(data, x.axis.labs = x.axis.labs, x.axis.at = x.axis.at, ...)
}

#' XY lines plot
#' 
#' @param data list of two elements: 'x' and 'y' (OXY lines coordinates)
#' @param data2  (optional) list of two elements: 'x' and 'y' 
#'        (OXY lines coordinates) for second line
#' @inheritParams stackedbar_internal
#' @inheritParams add_titles
#' 
#' @keywords internal
#' 
gecon_lines <- function(data, data2 = NULL, main = NULL, main.cex = 1.3, 
                        submain = NULL, submain.cex = 1, 
                        xlab = "Values", ylab = "Density",
                        legend = TRUE, eps_path = NULL)
{
    # plot params
    col <- c("red3", "gray40")
    lwd <- 2
    lty <- 1:2
    box <- TRUE
    axes.cex <- 1 
    axes.labs.cex <- 1
    legend.cex <- 1
    legend.text <- NULL 
    legend.ncol <- 3
    
    # adjust arguments
    n <- 1 + (!is.null(data2))
    col <- rep_len(col, n)    
    lty <- rep_len(lty, n)    
    lwd <- rep_len(lwd, n)    
    
    # preparing legends - bars
    if (is.null(legend.text)) {
        legend.text <- "Prior"
        if (!is.null(data2)) legend.text <- c(legend.text, "Posterior")
    }
    
    # eps    
    if (!is.null(eps_path)) {
        options(scipen = 1)
        ps.options(family = "serif", encoding = "ISOLatin1")
        setEPS() 
        postscript(eps_path, family = "serif")
        on.exit(dev.off())
    }  
    
    # OXY axes range adjustment
    xr <- range(data$x)
    yr <- c(0, range(data$y))
    if (!is.null(data2)) {
        xr <- c(xr, range(data2$x))
        yr <- c(yr, range(data2$y))
    }
    ylim <- ylim_adj(data = yr, forcezero = TRUE)
    xlim <- ylim_adj(data = xr, forcezero = FALSE)
    
    # margin adjustment
    mar_xy <- set_mar(main = main, main.cex = main.cex, submain = submain, 
                      submain.cex = submain.cex,  
                      ylab = ylab, axes.cex = axes.cex, 
                      axes.labs.cex = axes.labs.cex, ylim = ylim, 
                      xlab = xlab, legend = legend, 
                      legend.cex = legend.cex, legend.text = legend.text, 
                      legend.ncol = legend.ncol,  
                      data = matrix(1:2, ncol = 2))                                              
    
    # init plot
    plot(NA, ylim = ylim[1:2], xlim = xlim[1:2], ylab = "", xlab = "", 
         xaxt = "n", yaxt = "n", bty = "n")
    
    # 0 line
    abline(h = 0, col = "gray40", lty = 3, lwd = 1.5)
    
    # adding lines
    lines(x = data$x, y = data$y, lty = lty[1], lwd = lwd[1], col = col[1])    
    if (!is.null(data2))
        lines(x = data2$x, y = data2$y, lty = lty[2], lwd = lwd[2], col = col[2])    
    
    if (box) box()
    
    # adding OY axis
    axis(side = 2, at = seq(ylim[1], ylim[2], by = ylim[3]), 
         labels = gEcon:::pretty_labels(ylim[1], ylim[2], ylim[3]),
         cex.axis = axes.cex, las = 1)
    
    # adding OY axis
    axis(side = 1, at = seq(xlim[1], xlim[2], by = xlim[3]), 
         labels = gEcon:::pretty_labels(xlim[1], xlim[2], xlim[3]),
         cex.axis = axes.cex, las = 1)
    
    # add graph and axes titles
    add_titles(main = main, main_y = mar_xy$main_y, main.cex, 
               submain = submain, submain.cex = submain.cex,
               axes.labs.cex = axes.labs.cex,
               xlab = xlab, xlab_y = mar_xy$xlab_y, 
               ylab = ylab, ylab_x = mar_xy$ylab_x) 
    
    # adding legend
    if (legend) add_legend(legend.text = legend.text, 
                           legend.ncol = legend.ncol, col = col, box = box, border = "white", 
                           lty = lty, lwd = lwd, legend.cex = legend.cex, 
                           legend_y = mar_xy$legend_y, legend_x = mar_xy$legend_x)
}

#' The fan chart function
#' 
#' The \code{gecon_fanchart} function creates a plot showing a variable's 
#' distribution by using confidence intervals.
#' 
#' Each column of the \code{data} matrix represents one period and the column's 
#' elements represent variable's distribution for that period.
#' 
#' The user can specify the number and range of confidence intervals 
#' using one of the parameters: \code{n}, or \code{q.left} and 
#' \code{q.right}.
#'  
#' @param data a matrix with data to be visualized; each column represents 
#'        one period; column's elements represent variable's distribution 
#'        for the given period
#' @param ts object representing time series plotted before fanchart projection
#' @param n a desired number of confidence intervals
#' @param q.left a numeric vector with the left endpoints of confidence intervals 
#'        expressed in confidence level values: from 0 to 1; note that 
#'        \code{q.left} values have to be lower than corresponding 
#'        \code{q.right} values
#' @param q.right a numeric vector with the right endpoints of confidence intervals 
#'        expressed in confidence level values: from 0 to 1; note that 
#'        \code{q.right} values have to be greater than corresponding 
#'        \code{q.left} values
#' @param mean mean values vector
#' @param var_name a string with the name of variable to be plotted
#' @inheritParams stackedbar_internal
#'
#' @keywords internal
gecon_fanchart <- function(data, ts,
                           n = 9, 
                           q.left = NULL, q.right = 1 - q.left, q_d = NULL, q_u =  1 - q_d,
                           main = NULL, submain = NULL, 
                           xlab = NULL, ylab = NULL, mean = NULL, var_name = NULL,
                           legend = TRUE, legend.text = NULL, eps_path = NULL)
{
    box <- TRUE
    ts.col <- 1
    ts.lty <- 1
    ts.lwd <- 2 
    main <- NULL
    main.cex <- 1
    submain <- NULL
    submain.cex <- 1                      
    axes.cex <- 1
    axes.labs.cex <- 1 
    legend.cex <- 1
    mean.col <- "black"
    mean.lty = 2
    mean.lwd = 2 
    
    # data object
    if (!is.numeric(data) | !is.matrix(data)) {
        stop("parameter 'data' must be a numeric matrix")
    }
    if (!is.null(ncol(ts))) if (ncol(ts) > 1) {
        stop("parameter 'ts' must represent single time series")
    }    
    
    # checking and setting parameters
    p <- check_fanchart_par(data.ncol = ncol(data), ts = ts,  n = n,
                           q.left = q.left, q.right = q.right)
    if (is.null(q.left)) {
        q.left <- p$q.left     
        q.right <- p$q.right 
    }
    x.axis.at <- p$x.axis.at
    x.axis.labs <- p$x.axis.labs
    if (is.null(legend.text)) 
        legend.text <- p$legend.text
    
    # init data
    if (is.null(q_d)) {
        q_d <- sapply(1:ncol(data), 
                    function (s) quantile(data[, s], probs = q.left, 
                                        na.rm = T))
        q_u <- sapply(1:ncol(data), 
                    function (s) quantile(data[, s], probs = q.right,
                                        na.rm = T))    
        if (is.null(dim(q_d))) q_d <- matrix(q_d, nrow = 1)
        if (is.null(dim(q_u))) q_u <- matrix(q_u, nrow = 1)
    }
    # OY axis limits
    ylim <- ylim_adj(data = c(range(ts), range(data)), forcezero = FALSE)
    
    # eps    
    if (!is.null(eps_path)) {
        options(scipen = 1)
        ps.options(family = "serif", encoding = "ISOLatin1")
        setEPS() 
        postscript(eps_path, family = "serif")
        on.exit(dev.off())
    }      
    
    # setting margins
    mar_xy = set_mar(data = data, ylim = ylim,
                     main = main, main.cex = main.cex, submain = submain, 
                     submain.cex = submain.cex, 
                     ylab = ylab, xlab = xlab, 
                     axes.cex = axes.cex, axes.labs.cex = axes.labs.cex, 
                     legend = legend, legend.bottom = FALSE, 
                     legend.cex = legend.cex, legend.text = legend.text)
    
    # xlim adjustment
    n <-  length(ts)
    xlim <- c(1, n + ncol(data))
    x.axis.val <- (n + 1) : (n + ncol(data))
    # init plot 
    plot(NA, xlim = xlim, ylim = ylim[1:2], 
         axes = F, ylab = "", xlab = "", bty = "n")
    if (box) box()
    
    # colours
    col <- 1
    n <- length(q.right)
    for (j in 1 : n) {
            col[j] <- rgb(red = 1 - 2 * (j - 1) / (6 * n), 
                          green = 1 - (j - 1) / n, blue = 0)
    }
    if (n == 1) 
        col <- "orangered"
    
    # plotting fanchart
    for (i in 1 : (ncol(data) - 1)) { 
        x0 <- x.axis.val[i] 
        x1 <- x.axis.val[i + 1] 
        for (j in 1 : length(q.right)) {
            y0u <- q_u[j, i] 
            y0d <- q_d[j, i] 
            y1u <- q_u[j, i + 1] 
            y1d <- q_d[j, i + 1] 
            # add interval
            polygon(x = c(x0, x0, x1, x1), 
                    y = c(y0d, y0u, y1u, y1d), 
                    col = col[j], border = NA)
        }
    }
    
    if (nrow(q_u) > 1)
        legend.title <- "Conf. intervals:"
    else
        legend.title <- "Conf. interval:"    
    
    # plot mean
    legend.text  <- c(legend.text, paste("mean", var_name))
    if (!is.null(mean)) {
        avg  <- rep_len(mean, ncol(data))
    } else {
        avg  <- sapply(1:ncol(data), function (s) mean(data[, s]))
    }
    lines(x = x.axis.val, y = avg, lwd = mean.lwd, lty = mean.lty, 
          col = mean.col)
    
    # ts plotting
    lines(x = 1 : (length(ts) + 1), y = c(as.numeric(ts), avg[1]), 
          col = ts.col, lty = ts.lty, lwd = ts.lwd)    
    
    # OX axis
    axis(1, at = x.axis.at, labels = x.axis.labs[x.axis.at], 
         cex.axis = axes.cex)
    
    # OY axis
    axis(2, at = seq(ylim[1], ylim[2], ylim[3]), 
         labels = gEcon:::pretty_labels(ylim[1], ylim[2], ylim[3]), 
         las = 1, cex.axis = axes.cex)
    
    # add titles
    add_titles(main = main, main_y = mar_xy$main_y, main.cex, 
               submain = submain, submain.cex = submain.cex,
               axes.labs.cex = axes.labs.cex,
               xlab = xlab, xlab_y = mar_xy$xlab_y, 
               ylab = ylab, ylab_x = mar_xy$ylab_x)         
    
    # add legend 
    if (legend) 
        add_fanchart_legend(legend.text = legend.text, legend.cex = legend.cex, 
                            legend.title = legend.title, 
                            col = col, mean = TRUE, 
                            mean.lty = mean.lty, mean.lwd = mean.lwd, 
                            mean.col = mean.col, legend_x = mar_xy$legend_x, 
                            legend_y = mar_xy$legend_y)
    
    
    # return list of parameters
    return(invisible(list(col = col, ql = q_d, qr = q_u)))
}

#' Fanchart arguments
#' 
#' The function validates \code{\link{gecon_fanchart}} function arguments 
#' and returns validated fanchart parameters.
#'         
#' @param data.ncol the number of column in data matrix (for details see  
#'        gecon_fanchart function).
#' @inheritParams gecon_fanchart
#' 
#' @return Function returns a list of validated fanchart parameters
#' \itemize{
#'      \item{\code{q.left},}
#'      \item{\code{q.right},}
#'      \item{\code{col},}
#'      \item{\code{x.axis.at},}
#'      \item{\code{x.axis.labs},}
#'      \item{\code{legend.text}.}}
#'      
#' @keywords internal                   
check_fanchart_par <- function(data.ncol, ts, n = NULL, q.left = NULL, 
                               q.right = NULL) {
    
    
    # check length and value range
    if (any((q.right < 0) | (q.right > 1 ))) 
        stop("values of parameter 'q.left' must fall into [0 , 1]")
    if (any((q.left < 0) | (q.left > 1 ))) 
        stop("values of parameter 'q.right' must fall into [0 , 1]")
    if (any(q.left >= q.right )) 
        stop("values of parameter 'q.right' must fall greater than q.left")        
    if (length(q.left) != length(q.right)) 
        stop("parameters q.right and q.left must have the same length")
    
    # quantiles
    if (is.null(q.left)) {
        q.left <- seq(from = 0.5 / (n + 1), 
                      by = 0.5 / (n + 1), 
                      length.out = n)
        if (tail(q.left, 1) + 1 / 10 ^ 6 > 0.5) 
            q.left  <- q.left[1:(length(q.left) - 1)]
        q.right  <- 1 - q.left
    } else {
        q.left  <- sort(q.left)
        q.right  <- sort(q.right, decreasing = TRUE)
    }
    
    # legend
    legend.text  <- NULL
    for (i in 1:length(q.left)) 
        legend.text  <- c(legend.text, 
                           paste0(round(100 * q.left[i], 1), "% - ", 
                                  round(100 * q.right[i], 1), "%"))
    
    # x.axis.at/labs
    n  <- length(ts) + data.ncol
    st_ind  <- start(ts)[1]
    st  <- start(ts)
    if (length(st) > 1) 
        st  <- st[2]
    x.axis.labs  <- get_ts_ind(st_ind = st_ind, st = st, 
                               freq = frequency(ts), n = n)
    x.axis.at = get_at(n = n, freq = frequency(ts), st = st)    
    
    # adjusted parameters
    return(list(q.left = q.left, q.right = q.right,
                x.axis.at = x.axis.at, x.axis.labs = x.axis.labs, 
                legend.text = legend.text))
}

#' Adding legend to fan charts
#'  
#' @inheritParams add_legend
#' @param legend.title the legend title.
#' @param mean logival value; if \code{TRUE} then mean value line will 
#'        be plotted.
#' @param mean.lty the type of mean line.
#' @param mean.lwd the width of mean line.
#' @param mean.col the colour of mean line.
#' 
#' @keywords internal
add_fanchart_legend <- function(legend.cex, legend.text, col, 
                                legend_x, legend_y, legend.title, 
                                mean, mean.lty, mean.lwd, mean.col) 
{
    
    n.lim  <- 20
    n  <- length(legend.text) - 1 * mean
    
    # reduction (too long legend)
    if (n > n.lim) {
        by_  <- (n - 1 * mean) / (n.lim - 1)
        at_  <- seq(from = 1 + by_, to = n - by_, by = by_)
        at_  <- c(1, round(at_), n)
        col  <- col[at_]
        at_  <- union(at_, n + 1 * mean)
        legend.text  <- legend.text[at_]
        n  <- length(legend.text) - 1 * mean
    }
    
    y0  <- xy.range()$y1 - lines2xy()$y
    x0  <- xy.range()$x1 + lines2xy()$x / 2
    
    # add title
    if (text.len(legend.title) > 0)
        text(x = x0, y = y0, labels = legend.title, xpd = T, pos = 4)
    
    # plotting legend
    xy  <- legend(x = x0,
                cex = legend.cex,
                y = y0 - text.lines(legend.text) * legend.cex * lines2xy()$y,
                legend = legend.text[1:n], pch = 15, col = col, pt.cex = 3, 
                bty = "n", xpd = T)
    
    # plotting mean legend
    if (mean)
        legend(x = x0,
               cex = legend.cex,
               y = xy$rect$top - xy$rect$h, 
               legend = tail(legend.text, 1), lty = mean.lty, lwd = mean.lwd, 
               col = mean.col, bty = "n", xpd = T)
}
