# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski                                                    #
# ############################################################################
# The set of functions for computing inverted gamma distribution quantiles
# and density
# ############################################################################

#' Find quantile of inverted gamma distribution
#'
#' The \code{qinvgamma} function returns p-quantile of
#' inverted gamma distribution.
#'
#' @param p a numeric, requested quantile of inverted gamma distribution.
#' 
#' @param a a numeric, a parameter of inverted gamma  distribution.
#' 
#' @param b a numeric, b parameter of inverted gamma  distribution.
#' 
#' @return a numeric with requested inverted gamma quantile value.
#'
#' @keywords internal
qinvgamma <- function(p, a, b)
{
    return(1 / sqrt(qgamma(p, shape = a / 2, rate = b / 2)))
}

#' Find quantile of inverted gamma distribution (II type)
#'
#' The \code{qinvgamma_2} function returns p-quantile of
#' inverted gamma distribution (II type).
#'
#' @param p a numeric, requested quantile of inverted gamma (II type) distribution.
#' 
#' @param a a numeric, a parameter of inverted gamma (II type)  distribution.
#' 
#' @param b a numeric, b parameter of inverted gamma (II type)  distribution.
#' 
#' @return a numeric with requested inverted gamma (II type) quantile value.
#'
#' @keywords internal
qinvgamma_2 <- function(p, a, b)
{
    return(1 / qgamma(p, shape = a / 2, rate = b / 2))
}


#' Probability density of inverted gamma distribution (I type)
#' 
#' The \code{pinvgamma} function returns density of 
#' the inverted gamma distribution of the first type.
#'
#' @param x a numeric, value of inverted gamma distribution.
#' 
#' @param a a numeric, a parameter of inverted gamma  distribution.
#' 
#' @param b a numeric, b parameter of inverted gamma  distribution.
#'
#' @param log a logical. If set to TRUE, the function returns log-density.
#' 
#' @return a numeric with requested inverted gamma density value.
#'
#' @keywords internal 
pinvgamma <- function(x, a, b, log = FALSE)
{
    ldens <- log(2) - lgamma(0.5 * a) - 0.5 * a * (log(2) - log(b)) - 
                (a + 1) * log(x) - 0.5 * b / (x * x)
   
    if (!log)
        ldens <- exp(ldens)
    return(ldens)
}

#' Probability density of inverted gamma distribution (II type)
#' 
#' The \code{pinvgamma_2} function returns density of 
#' the inverted gamma distribution of the second type.
#'
#' @param x a numeric, value of inverted gamma (II type) distribution.
#' 
#' @param a a numeric, a parameter of inverted gamma (II type) distribution.
#' 
#' @param b a numeric, b parameter of inverted gamma (II type) distribution.
#'
#' @param log a logical. If set to TRUE, the function returns log-density.
#' 
#' @return a numeric with requested inverted gamma (II type) density value.
#'
#' @keywords internal 
pinvgamma_2 <- function(x, a, b, log = FALSE)
{
    ldens <- - lgamma(0.5 * a) - 0.5 * a * (log(2) - log(b)) - 
                      0.5 * (a + 2) * log(x) - 0.5 * b / x

    if (!log)
        ldens <- exp(ldens)
    return(ldens)
}
