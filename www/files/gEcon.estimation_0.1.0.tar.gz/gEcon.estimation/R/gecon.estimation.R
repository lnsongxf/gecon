# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski, Paweł Romański                                    #
# ############################################################################
# gEcon.estimation package introduction
# ############################################################################

#' Dynamic stochastic general equilibrium (DSGE) models estimation 
#' 
#' Package for estimating dynamic stochastic general equilibrium models.
#' 
#' This package allows for estimation of models developed in \code{gEcon} using either 
#' Bayesian methods (\code{\link{bayesian_estimation}}) or classical 
#' maximum likelihood approach \code{\link{ml_estimation}}). 
#' In addition, the package includes implementation of historical shock decomposition
#' (\code{\link{shock_decomposition}}), Kalman smoother for unobservable variables
#' (\code{\link{smoother}}), and forecasting routines (\code{\link{forecast}}) and
#' (\code{\link{forecast_posterior}}) which may be helpful 
#' in model analysis and applications.
#' 
#' The likelihood function is constructed  using Kalman filter and state-space 
#' representation of model based on the 1st order perturbation solution.
#' This allows for estimation of the model parameters using either Bayesian or classical 
#' (maximum likelihood) methods. Bayesian approach involves combining the likelihood 
#' function with prior distributions of the model parameters to obtain posterior 
#' distributions of parameters. A point estimate for model parameters can be obtained 
#' as a statistic of posterior distribution (minimising specific Bayesian loss function,
#' e.g. mean minimises quadratic loss function). The maximum likelihood method involves 
#' maximisation of the likelihood  function with respect to model parameters 
#' (parameter vector maximising the likelihood function is the point estimate).
#' 
#' Mapping of the DSGE models into state-space representation requires brief description 
#' as it can give the user an insight into how to prepare model and data for estimation. 
#' The matrices used in the state-space representation are created based on the solution 
#' of the log-linearised model (model variables are expressed as percentage deviations from
#' their steady-state values) and do not contain intercept or deterministic
#' term (do not allow for deterministic trend nor seasonality). This implies that
#' to obtain meaningful results from estimation process, the data used for estimation 
#' have to be filtered for trend, seasonally adjusted, and demeaned. This can be done either by
#' HP-filtering or computing log differences and then demeaning the resulting
#' series.
#' 
#' The following state-space representation is assumed by the package:
#'     \deqn{X_t = H x_t + J u_t,}
#'     \deqn{x_t = F(\theta) x_{t-1} + G(\theta) e_t,}
#'     \deqn{e_t \sim N(0, \Sigma),}
#' where \eqn{X_t} denotes the vector of observable variables 
#' (of length \eqn{m}), \eqn{x_t} stands for 
#' the vector of model variables (of length \eqn{m + s}, 
#' where \eqn{s} is the number of state variables).
#' The second equation is called transition equation 
#' for the unobservable variables (\eqn{x_t}, the model variables) 
#' while the first equation - observation equation - maps these variables into
#' the observable data. In the current release of the package, the state-space
#' representation cannot contain explicit measurement errors 
#' (the \eqn{J} has all entries equal to zero). The \eqn{H} matrix 
#' (with dimensions \eqn{m \times m + s}) 
#' contains mapping of \eqn{x_t} to the \eqn{X_t} vector of observables. 
#' In each row it has one entry equal to 1 with all entries set to zero.
#'  
#' The \eqn{F(\theta)} and \eqn{G(\theta)} matrices from transition equation
#' are created from gEcon model's solution matrices (\eqn{P}, \eqn{Q}, \eqn{R}, 
#' \eqn{S}, for details see gEcon package Users' guide). The \eqn{F(\theta)} 
#' matrix (with dimension \eqn{(m + s)\times(m + s)} ) is created by stacking
#' rows of R matrix from the solution of DSGE model corresponding 
#' to observable variables and the entire P matrix. 
#' The \eqn{G(\theta)} matrix is created by stacking rows of S 
#' matrix from the solution of log-linearised DSGE model
#' corresponding to observable variables and the entire Q matrix.
#' Obviously, the \eqn{F(\theta)} and \eqn{G(\theta)} matrices are dependent 
#' on model parameters (\eqn{\theta}). The shock vector (\eqn{e_t}) 
#' is assumed to be normally distributed with mean zero. 
#' The variance-covariance matrix (\eqn{\Sigma})
#' can be estimated or (if assumed or known) set in object of \code{gecon_model} class.
#'
#' @name gecon.estimation-package
#' 
#' @docType package
#' 
#' @author Karol Podemski, Paweł Romański, Michał Marciniak (plotting functions),
#'         idea and design by Grzegorz Klima 
#' 
#' @keywords package
#' 
#' @examples
#' # #################################################################
#' # 1. prepare gEcon model
#' 
#' # copy the example to the current working directory
#' file.copy(from = file.path(system.file("examples", package = "gEcon.estimation"),
#'                            "dsge_model.gcn"), to = getwd())
#' dsge_model <- make_model("dsge_model.gcn")
#' 
#' # solve the model
#' dsge_model <- steady_state(dsge_model)
#' dsge_model <- solve_pert(dsge_model, loglin = TRUE)
#' 
#' # set the stochastic shocks distribution parameters
#' dsge_model <- set_shock_distr_par(dsge_model,
#'                                   distr_par = list("sd( epsilon_G )" = 0.01,
#'                                                    "sd( epsilon_Z )" = 0.01))
#' shock_info(model = dsge_model, all = TRUE)
#' 
#' # ###################################################################
#' # 2. simulate the model to obtain data for the estimation
#' 
#' # choose variables of interest
#' set.seed(250)
#' series_length <- 150
#' observables <- c("Y", "G")
#' 
#' # simulate random path
#' dsge_simulation <- random_path(model = dsge_model, 
#'                                sim_length = series_length, 
#'                                variables = observables)
#' model_data <- get_simulation_results(dsge_simulation)
#' 
#' # create data set to be used for estimation (ts object)
#' estimation_data <- ts(data = t(model_data)[, observables], 
#'                       start = c(1973, 1), 
#'                       frequency = 4, names = observables)
#' 
#' # remove mean from the data series
#' mean_var <- matrix(apply(estimation_data, 2, mean), 
#'                    byrow = TRUE,
#'                    nrow = nrow(estimation_data), 
#'                    ncol = ncol(estimation_data))
#' estimation_data <- estimation_data  - mean_var
#' 
#' # ###################################################################
#' # 3. declare prior distribution
#' 
#' dsge_prior <- gecon_prior(
#'     prior_list = list(
#'         list(par = "sd(epsilon_Z)", type = "inv_gamma",
#'              mean = 0.012, sd = 0.3, lower_bound = 0.0001, 
#'              upper_bound  = 0.9, initial = 0.0012),
#'         list(par = "sd(epsilon_G)", type = "inv_gamma",
#'              mean = 0.008, sd = 0.3, lower_bound = 0.0001, 
#'              upper_bound  = 0.9, initial = 0.006),
#'         list(par = "omega", type = "normal",
#'              mean = 1.45, sd = 0.1, lower_bound = 1, 
#'              upper_bound  = 2, initial = 1.5),
#'         list(par = "phi_G", type = "beta",
#'              mean = 0.88, sd = 0.03, lower_bound = 0.5, 
#'              upper_bound  = 0.999, initial = 0.95),
#'         list(par = "phi_Z", type = "beta",
#'              mean = 0.92, sd = 0.03, lower_bound = 0.5, 
#'              upper_bound  = 0.999, initial = 0.95)),
#'     model = dsge_model)
#' 
#' plot_prior(dsge_prior)
#' 
#' # ###################################################################
#' # 4. estimate the model (Bayesian estimation)
#' 
#' estimation_result <- bayesian_estimation(data_set = estimation_data, 
#'                                          optim_options_list = list(solver = "csminwel"),
#'                                          mcmc_options_list = list(chain_length = 1000, 
#'                                                                   burn = 200,
#'                                                                   cores = 2, chains = 2,
#'                                                                   scale = rep(0.5, 5)),
#'                                          observables =  observables,
#'                                          model = dsge_model, 
#'                                          prior = dsge_prior)
#' 
#' 
#' plot_posterior(estimation_result)
#' # retrieve estimates
#' #
#' # true model parameters were:
#' # sd(epsilon_Z) 0.01
#' # sd(epsilon_G) 0.01
#' # omega         1.45
#' # phi_G         0.9
#' # phi_Z         0.9
#' est_par <- get_estimated_par(estimation_result)
#' free_par <- est_par$free_par
#' shock_distr_par <- est_par$shock_distr_par
#' estimated_dsge_model <- set_free_par(dsge_model, free_par = free_par)
#' estimated_dsge_model <- set_shock_distr_par(estimated_dsge_model, distr_par = shock_distr_par)
#' 
#' estimated_dsge_model <- steady_state(estimated_dsge_model)
#' estimated_dsge_model <- solve_pert(estimated_dsge_model, loglin = TRUE)
#' 
#' # ###################################################################
#' # 5. historical shock decomposition and variable smoothing
#' 
#' # find historical shock decomposition
#' dsge_shock_decomp <- shock_decomposition(model = estimated_dsge_model, 
#'                                          data_set = window(estimation_data, 
#'                                                            start = c(2004, 1), 
#'                                                            end = c(2010, 1), 
#'                                                            frequency = 4), 
#'                                          observables = observables, 
#'                                          variables = observables)
#' plot_shock_decomposition(dsge_shock_decomp)
#' 
#' # use Kalman smoother to obtain smoothed variables' values
#' dsge_smoothed_variables <- smoother(model = estimated_dsge_model, 
#'                                     data_set = estimation_data, 
#'                                     observables = c("Y", "G"), 
#'                                     variables = c("K", "I", "C"))
#' 
#' # print smoothed shocks' values
#' dsge_smoothed_variables$smoothed_shock
#' # print smoothed variables' values
#' dsge_smoothed_variables$smoothed_var
#' # print the MSE matrix
#' dsge_smoothed_variables$MSE
#' 
#' # ###################################################################
#' # 6. forecast using the model
#' 
#' # forecast using point estimates of parameters
#' fc_res <- forecast(model = estimated_dsge_model, 
#'                    data_set = estimation_data, 
#'                    observables = observables, 
#'                    variables = c("Y", "G"), 
#'                    horizon = 20)
#' 
#' # forecast using posterior distribution
#' fc_res_post <- forecast_posterior(est_results = estimation_result,
#'                                   data_set = estimation_data, 
#'                                   observables = observables,
#'                                   variables = c("Y", "G"), 
#'                                   horizon = 20)
#' 
#' # plot forecasts
#' plot_forecast(fc_res_post)
#' plot_forecast(fc_res)
NULL

#' These methods print general information about objects
#' of the \code{gecon_estimation_results}
#' and \code{gecon_prior} classes.
#'
#' @name show-methods
#'
#' @param object an object for which information is to be printed.
#'
#' @section Methods:
#'  \subsection{\code{signature(object = "gecon_estimation_results")}}{
#'              Prints estimation method name and estimation statistics.
#'      }
#' 
#'  \subsection{\code{signature(object = "gecon_prior")}}{
#'              Prints number of parameters for which prior distributions
#'              have been specified.
#'      }
NULL


#' These methods print information about objects
#' of the \code{gecon_estimation_results}
#' and \code{gecon_prior} classes.
#' 
#' @param x an object for which information is to be printed.
#'
#' @name print-methods
#'
#' @section Methods:
#'  \subsection{\code{signature(x = "gecon_estimation_results")}}{
#'              Prints estimation method name, estimation statistics,
#'              and the names of estimated parameters.
#'      }
#' 
#'  \subsection{\code{signature(x = "gecon_prior")}}{
#'              Prints names of parameters for which prior distributions
#'              have been specified.
#'      }
NULL


#' These methods summarise information about objects 
#' of \code{gecon_estimation_results} 
#' and \code{gecon_prior} classes.
#' 
#' @param object an object for which the summary is to be printed.
#'
#' @name summary-methods
#'
#' @section Methods:
#'  \subsection{\code{signature(object = "gecon_estimation_results")}}{
#'          Prints a summary of an object of \code{gecon_estimation_results}
#'          class consisting of estimation method name, 
#'          estimation statistics, and estimates of model parameters.
#'      }
#' 
#'  \subsection{\code{signature(object = "gecon_prior")}}{
#'          Prints a summary of an object of \code{gecon_prior}
#'          class consisting of moments of prior distribution,
#'          values of parameters, and their initial values 
#'          used for the estimation.
#'      }
NULL


#' Example \code{gecon_estimation_results} object
#' 
#' An example \code{\link{gecon_estimation_results}} object,
#' created by estimating DSGE model specified in the \code{dsge_model.gcn}
#' file (the file can be found in the package directory)
#' using \code{\link{bayesian_estimation}} function.
#' 
#' @docType data
#' @name example_estimation_result
#'
#' @usage data(example_estimation_result)
#'
#' @export
NULL


#' Example data generated from DSGE model
#' 
#' An example data set generated from DSGE model
#' specified in the \code{dsge_model.gcn} file
#' (the file can be found in the package directory).
#' 
#' @docType data
#' @name example_estimation_data
#'
#' @usage data(example_estimation_data)
#'
#' @export
NULL


#' Example estimated DSGE model
#' 
#' An estimated DSGE model specified 
#' in the \code{dsge_model.gcn} file
#' (the file can be found in the package directory).
#' The data from \code{example_estimation_data} were
#' used to estimate model.
#' 
#' @docType data
#' @name estimated_model
#'
#' @usage data(estimated_model)
#'
#' @export
NULL

