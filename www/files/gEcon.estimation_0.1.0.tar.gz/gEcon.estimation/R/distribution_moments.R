# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski, Paweł Romański                                    #
# ############################################################################
# The set of functions for computing distribution moments 
# given values of the parameters
# ############################################################################

#' Beta distribution moments
#' 
#' The \code{beta_mom} function computes standard deviation 
#' and mean of beta distribution.
#' 
#' @param a a numeric, a parameter of beta distribution.
#' 
#' @param b a numeric, b parameter of beta distribution.
#' 
#' @param L a numeric, L parameter of beta distribution.
#' 
#' @param U a numeric, U parameter of beta distribution.
#' 
#' @return a list with mean and standard deviation of the beta distribution.
#'
#' @keywords internal
beta_mom <- function(a, b, L, U)
{
    scal <- (U - L)
    return(list(mean = L + scal * a / (a + b),
                std_dev = scal * ((a * b) / (a + b + 1)) ^ 0.5 / (a + b)))
}

#' Gamma distribution moments
#' 
#' The \code{gamma_mom} function computes standard deviation 
#' and mean of gamma distribution.
#' 
#' @param a a numeric, a parameter of gamma distribution.
#' 
#' @param b a numeric, b parameter of gamma distribution.
#' 
#' @param L a numeric, L parameter of gamma distribution.
#' 
#' @return a list with mean and standard deviation of the gamma distribution.
#'
#' @keywords internal
gamma_mom <- function(a, b, L)
{
    return(list(mean = a * b + L,
                std_dev = sqrt(a) * b))    
}

#' Norma distribution moments
#' 
#' The \code{normal_mom} function computes standard deviation 
#' and mean of normal distribution.
#' 
#' @param a a numeric, a parameter of normal distribution.
#' 
#' @param b a numeric, b parameter of normal distribution.
#' 
#' @return a list with mean and standard deviation of the normal distribution.
#'
#' @keywords internal
normal_mom <- function(a, b)
{
    return(list(mean = a,
                std_dev = b))
}


#' Inverted gamma distribution moments
#' 
#' The \code{inverted_gamma_1_mom} function computes standard deviation 
#' and mean of inverted gamma distribution.
#'
#' @param a a numeric indicating a parameter of inverted gamma distribution.
#' 
#' @param b a numeric indicating b parameter of inverted gamma distribution.
#' 
#' @param L a numeric indicating L parameter of inverted gamma distribution.
#' 
#' @return a list with mean and standard deviation of the inverted gamma distribution.
#'
#' @keywords internal
inverted_gamma_1_mom <- function(a, b, L)
{
    mu = sqrt(b / 2) * gamma((a - 1) / 2) / gamma(a / 2)
    return(list(mean = mu + L,
                std_dev =  sqrt(b / (a - 2) - mu ^ 2)))    
}

#' Inverted gamma distribution moments
#' 
#' The \code{inverted_gamma_2_mom} function computes standard deviation 
#' and mean of inverted gamma distribution.
#'
#' @param a a numeric indicating a parameter of inverted gamma (II type) distribution.
#' 
#' @param b a numeric indicating b parameter of inverted gamma (II type) distribution.
#' 
#' @return a list with mean and standard deviation of the inverted gamma (II type) distribution.
#'
#' @keywords internal
inverted_gamma_2_mom <- function(a, b, L)
{
    mu <- b / (a - 2) 
    return(list(mean = mu + L,
      std_dev =  sqrt(2 * mu ^ 2 / (a - 4))))    
}

#' Uniform distribution moments
#' 
#' The \code{uniform_mom} function computes standard deviation 
#' and mean of uniform distribution.
#'
#' @param a a numeric indicating a parameter of uniform distribution.
#' 
#' @param b a numeric indicating b parameter of uniform distribution.
#' 
#' @return a list with mean and standard deviation of the uniform distribution.
#'
#' @keywords internal
uniform_mom <- function(a, b)
{
    return(list(mean = (a + b) / 2,
                std_dev =  (b - a) / (12 ^ 0.5)))        
}
