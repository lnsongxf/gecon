# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Paweł Romański, Karol Podemski                                    #
# ############################################################################
# Calculates likelihood for given DSGE model
# ############################################################################

#' Calculates log-likelihood for given parameters of DSGE model
#'
#' The \code{likelihood} function returns value of the log-likelihood 
#' obtained from the Kalman filter.
#' 
#' @param data a matrix containing data. Its column names should correspond
#'             to model variables. 
#' 
#' @param model an object of \code{gEcon model} class.
#' 
#' @param value_on_failure any R object. It declares value which
#'                         will be returned if gEcon fails to 
#'                         solve steady-state or perturbation.
#'                         The default value is \code{NULL}.
#'  
#' @return The function returns the value of the log-likelihood.
#' 
#' @keywords internal
likelihood <- function(data, model, value_on_failure = NULL) 
{    
    # create prototype of result
    llh <- list( log_likelihood = value_on_failure, # default - returned on failure
                 model = model,
                 ss_failures = 0,                   # flag for steady state failure
                 re_failures = 0 )                  # flag for perturbation failure

    # find steady state if needed
    if ( !ss_solved(llh$model) ) {
        output_text <-  capture.output(
            ie <- tryCatch( llh$model <- steady_state( llh$model, use_jac = FALSE),
                        warning = function(w) w,
                        error = function(w) w)
        )
    }
    
    # if failed to solve steady state
    if ( !ss_solved(llh$model) ) {
            llh$ss_failures <- 1
            return ( llh )
    }
    
    output_text <- capture.output(
        if (!re_solved(llh$model))
            suppressWarnings(llh$model <- solve_pert( llh$model ))
    )
    
    # if failed to solve
    if (!re_solved(llh$model)) {
            llh$re_failures <- 1
            return ( llh )
    }
    
    # get variable names
    pert_solution <- get_pert_solution(llh$model, silent = TRUE)
    obs_vars <- names(pert_solution$ss_val[-pert_solution$state_ind])
    state_vars <- names(pert_solution$ss_val[pert_solution$state_ind])
    
    data_vars <- colnames(data)

    # create index linking observable variables to data
    # note that in data may be also some unobserved variables
    obs_index <- which( obs_vars %in% data_vars )
    
    # get solution matrices ( for R and S only rows which correspond to variables which are in data )
    P <- as.matrix( llh$model@solution$P )
    Q <- as.matrix( llh$model@solution$Q )
    R <- llh$model@solution$R[obs_index, , drop = FALSE]
    S <- llh$model@solution$S[obs_index, , drop = FALSE]
    
    # get number of state variables and variables in data
    p <- nrow(P)
    n <- ncol(data)

    # check if some matrices turned into vectors
    Q <- check_shape(Q, nrow = p)
    R <- check_shape(R, nrow = length(obs_index) )
    S <- check_shape(S, nrow = length(obs_index) )
  
    # transform model (add observed variables into state variables)
    F <- rbind(R, P)
    # add zeros on the right to make square matrix
    n_vars <- nrow( F )
    F <- cbind(matrix(0, ncol = n_vars - ncol( F ), nrow = n_vars ), F)
    
    # prepare variance covariance matrix of error terms
    G <- rbind(S, Q)
    
    # update variance covariance matrix of shocks
    GG <- G %*% get_shock_cov_mat(llh$model) %*% t(G)
    
    # find initial variance-covariance matrix of innovations
    MSE_0 <- lyapunov(F, GG)

    # prepare observation equation. For the beginning take matrix of zeros
    H <- matrix(0, nrow = n, ncol = n_vars)
    
    # get all non-lagged vars
    all_vars <- c(obs_vars[ obs_index ], state_vars)

    # create index matching vars from data to all non-laged vars
    index <- match( data_vars, all_vars)
    
    for (i in 1:n) {
        H[i, index[i]] <- 1 # add one one variable in data and variable in state equation cross
    }
    
    # there is no error term in measurement equation, so matrix of zeros is used
    J <- matrix(0, nrow = n, ncol = n)
    
    # get initial values
    # initial state vector is just zeros
    x_0 <- rep(0, n_vars)

    # run Kalman filter
    kalman <- fkf(a0 = x_0,            # initial values of state variables
                  P0 = MSE_0,          # initial variance matrix
                  ct = rep(0, n),      # constant term in measurement equation
                  dt = rep(0, n_vars), # constant term in state equation
                  Tt = F,              # 'P' matrix
                  HHt = GG,            # variance matrix for epsilon in state equation
                  Zt = H,              # mapping from model variables to observable variables
                  GGt = J,             # matrix of zeros for error term in measurement equation
                  yt = t(data),        # data
                  check.input = TRUE)

    
    # save likelihood to result list
    llh$log_likelihood <- kalman$logLik   

    return(llh)
}
