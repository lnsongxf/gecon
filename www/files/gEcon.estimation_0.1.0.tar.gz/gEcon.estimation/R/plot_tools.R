# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Michał Marciniak                                                  #
# ############################################################################
# Auxiliary functions for graph plotting
# ############################################################################

#' Axis limits adjustment
#' 
#' The \code{ylim_adj} function validates or
#' calculates the OY (OX) limits and width of interval.
#' 
#' @param data a numeric matrix or vector.
#' @param forcezero a logical value; if \code{TRUE}, 
#'                  the axis will include zero value.
#'        
#' @keywords internal
ylim_adj <- function(data, forcezero = TRUE) 
{  
    r <- range(data, na.rm = T)
    if (forcezero) {
        if (r[2] < 0) r[2] <- 0
        if (r[1] > 0) r[1] <- 0
    }    
    # data with no variability
    if (r[1] == r[2]) {
        if (r[1] == 0) {
            r[1] <- -1
            r[2] <- 1
        } else {
            if (r[1] > 0) r[1] <- 0
            if (r[1] < 0) r[2] <- 0
        }
    }
    lim_ <- pretty(x = r, n = 8, min.n = 2)
    # upper limit correction
    ii <- which(lim_ >= r[2])
    if (length(ii) > 1) lim_ <- lim_[-ii[2:length(ii)]]
    # lower limit correction
    ii <- which(lim_ <= r[1])
    if (length(ii) > 1) lim_ <- lim_[-ii[2:length(ii)]]
    # set range
    lim <- c(lim_[1], tail(lim_, 1), diff(lim_[1:2]))
    
    return (lim)
}

#' Add bottom legend
#'
#' @param legend.cex a numeric, legend text size.
#' @param legend.text a character with legend text.
#' @param legend.ncol a numeric of legend column number.
#' @param col a code (numeric or character) for 
#'            the lines' colour(s).
#' @param lty a numeric, lines' type(s).
#' @param lwd a numeric, lines' width(s).
#' @param fill symbol(s) of bars' colour(s).
#' @param border symbol(s) bars' border colour.
#' @param box a logical value; if \code{TRUE}, the legend border
#'            will be drawn.
#' @param legend_x a numeric, OX coordinate of the legend position.
#' @param legend_y a numeric, OY coordinate of the legend position.
#' 
#' @keywords internal
add_legend <- function(legend.cex = 1, 
                       legend.text = NULL, 
                       legend.ncol = 1,
                       col = "white", lty = NULL, lwd = NULL,
                       fill = NULL, border = NULL, box = TRUE, 
                       legend_x = 0, legend_y = 0)
{
    # compute coordinates range
    xy = xy.range()
    x_mid = (xy$x1 + xy$x0) / 2    
    y0 = xy$y0 - legend_y * lines2xy()$y
    if (box) bty = "l" else bty = "n"
    nl = length(legend.text)
    nc = legend.ncol
    nr = ceiling(nl / nc)
    nc.real = ceiling(nl / nr)
    nc = min(nc.real, length(legend.text))
    xy = legend(x = 0,
                y = y0,
                legend = legend.text, 
                bty = "n",
                lty = lty,
                lwd = lwd,
                fill = "white",
                col = "white",
                text.col = "white",
                border = "white", 
                cex = legend.cex,
                y.intersp = 1 + (text.lines(legend.text) > 1) * 0.5,
                ncol = nc,
                xpd = T)
    legend(x = x_mid - xy$rect$w / 2 ,
           y = y0,
           legend = legend.text, 
           bty = bty,
           lty = lty,
           lwd = lwd,
           fill = fill,
           col = col, 
           border = border, 
           cex = legend.cex,
           y.intersp = 1 + (text.lines(legend.text) > 1) * 0.5,
           ncol = nc,
           xpd = T)
}

#' Plot range
#' 
#' The \code{xy.range} function returns the plot range.
#' 
#' @return The result is a list containing elements:
#'         \itemize{
#'              \item \code{$dy} a numeric, height of the plot area with margins 
#'                    (measured in user plot coordinates),
#'              \item \code{$dx} a numeric, width of the plot area with margins 
#'                    (measured in user plot coordinates),
#'              \item \code{$x0} a numeric, x coordinates of the left plot area edge 
#'                    (measured in user plot coordinates),
#'              \item \code{$x1} a numeric, x coordinates of the right plot area edge 
#'                    (measured in user plot coordinates),
#'              \item \code{$y0} a numeric, x coordinates of the bottom plot area edge 
#'                    (measured in user plot coordinates),
#'              \item \code{$y1} a numeric, x coordinates of the top plot area edge 
#'                    (measured in user plot coordinates).}
#'                    
#' @keywords internal
xy.range <- function()
{
    dy <- diff(par()$usr[3:4])
    ddy <- diff(par()$plt[3:4])
    dy <- dy / ddy
    dx <- diff(par()$usr[1:2])
    ddx <- diff(par()$plt[1:2])
    dx <- dx / ddx
    x0 <- par()$usr[1]
    x1 <- par()$usr[2]
    y0 <- par()$usr[3]
    y1 <- par()$usr[4]
    return(list(dy = dy, dx = dx, 
                x0 = x0, x0 = x0, 
                x1 = x1, y0 = y0, 
                y1 = y1))
}


#' The number of text lines
#' 
#' The \code{text.lines} function returns 
#' the maximum number of text lines in a character 
#' vector.
#' 
#' @param txt a character vector. 
#' 
#' @return The function returns maximum number of 
#'         text lines in the \code{txt} vector.
#' 
#' @keywords internal
#'
#'  
text.lines <- function(txt) {
    if (is.null(txt)) return(0)
    txt <- as.character(txt)
    fun <- function(x) {
        lines <- 1
        x2 <- sub(pattern = "\n", replacement = "", x = x)
        while (x != x2) {
            lines <- lines + 1
            x <- x2
            x2 <- sub(pattern = "\n", replacement = "", x = x)
        }
        return(lines)
    }
    return(max(sapply(X = txt, FUN = fun)))
}

#' The length of the character string
#' 
#' The \code{text.len} function returns the maximum length 
#' of the character string represented in
#' elements of character vector (argument \code{txt}).
#' 
#' @param txt a character vector.
#' 
#' @return  The function returns maximum length of a character string
#'          passed in \code{txt} vector
#' 
#' @keywords internal
text.len <- function(txt)
{
    if (is.null(txt)) return(0)
    txt <- as.character(txt)
    fun <- function(x) {
        s <- strsplit(x = x, split = "\n")
        s <- unlist(s)
        if (length(s) == 0) s = ""
        return(max(nchar(s)))
    }
    return(max(sapply(X = txt, FUN = fun)))
}

#' Lines width/height in coordinates
#' 
#' The \code{lines2xy} function returns text line width/height
#' expressed in the user plot coordinates.
#' 
#' @return The function returns a list containing following elements:
#'         \itemize{
#'              \item \code{$x} a numeric, width of one line 
#'                    measured in the user plot coordinates,
#'              \item \code{$y} a numeric, height of one line 
#'                    measured in the user plot coordinates.}
#' 
#' @keywords internal
lines2xy <- function()
{
    xy <- xy.range()
    m <- par()$mar
    p <- par()$plt
    lx <- xy$dx / 35
    ly <- xy$dy / 35
    if (m[3] > 0) lx <- (1 - p[4]) * xy$dy / m[3] 
    if (m[1] > 0) lx <- p[3] * xy$dy / m[1] 
    if (m[4] > 0) lx <- (1 - p[2]) * xy$dx / m[4] 
    if (m[2] > 0) lx <- p[1] * xy$dx / m[2]
    return(list(x = lx, y = ly))
}

#' Margin adjustment
#' 
#' The \code{set_mar} function sets the margin of plot 
#' according to the arguments of the \code{stackedbar_internal} function.
#' 
#' @param data a matrix of data to be plotted
#' @param legend.bottom a logical value. If \code{TRUE}, legend is located 
#'                      on the bottom of the graph
#' @inheritParams stackedbar_internal
#' @inheritParams add_bars
#' @inheritParams add_titles
#' @inheritParams add_legend
#' 
#' @return The function returns a list of coordinates 
#'         (measured in number of lines):
#'         \itemize{
#'              \item \code{$main_y} a numeric, y coordinates of the main title
#'                    (starting from the top edge of plot area),
#'              \item \code{$ylab_y} a numeric, y coordinates of the top left axis label 
#'                    (starting from the top edge of plot area),
#'              \item \code{$xlab_y} a numeric, y coordinates of the OX axis label 
#'                    (starting from the bottom edge of the plot area),
#'              \item \code{$legend_y} a numeric, y coordinates of the bottom legend 
#'                    (starting from the bottom edge of the plot area),
#'              \item \code{$legend_x} a numeric, x coordinates of the right legend 
#'                    (starting from the right edge of the plot area),
#'              \item \code{$ylab_x} a numeric, x coordinates of the left axis label 
#'                    (starting from the left edge of the plot area).
#'         }
#' 
#' @keywords internal
set_mar <- function(data, ylim, 
                    main = NULL, main.cex = 1, submain = NULL, 
                    submain.cex = 1.2, xlab = NULL, ylab = NULL, 
                    axes.cex = 1, axes.labs.cex = 1, 
                    box = TRUE, legend = FALSE, legend.bottom = TRUE, 
                    legend.cex = 1, legend.text = NULL, legend.ncol = 1)
{
        
    # top margin
    # #################################################
    title_y <- 1 * (!is.null(main) | !is.null(submain)) 
    # submain
    main_y <- title_y + text.lines(submain) * submain.cex
    # main
    mar_top <- main_y + text.lines(main) * main.cex
    
    # bottom margin
    # ################################################
    mar_bottom <- 0
    # x axis
    mar_bottom <- mar_bottom + axes.cex
    x.axis_y <- 0    
    # xlab
    xlab_y <- 1.5 + axes.cex  
    mar_bottom <- xlab_y + text.lines(xlab) * axes.labs.cex 
    # legend
    legend_y <- 0
    if (legend & legend.bottom) {
        legend_y <- xlab_y + text.lines(xlab) * axes.labs.cex + box * 1.5
        mar_bottom <- legend_y + ((text.lines(legend.text) > 1) * 0.5 + 
                     text.lines(legend.text)) * ceiling(nrow(data) / 
                     legend.ncol) * legend.cex +box * 0.5 
    }
    
    # left margin
    # ################################################
    mar_left <- 0
    # axis
    lab_ <- 2 + text.len(gEcon:::pretty_labels(ylim[1], ylim[2], ylim[3])) / 2 * 
        axes.cex
    mar_left <- lab_
    # ylab
    ylab_x <- lab_
    mar_left <- max(mar_left, lab_ + text.lines(ylab) * axes.labs.cex)
    
    # right margin
    # #################################################
    mar_right <- 1
    lab_ <- 0.5 + box

    # legend
    legend_x <- lab_
    if (legend & (!legend.bottom))
        mar_right <- max(mar_right, legend_x + text.len(legend.text) / 2 * 
                        legend.cex + 2 + 0.5 * box)
    
    # set margins
    mar <- c(mar_bottom + 1, mar_left, mar_top + 1, mar_right)
    par(mar = mar)
    
    # return labels coordinates (in lines)
    return(list(main_y = main_y, x.axis_y = x.axis_y, xlab_y = xlab_y, 
                legend_y = legend_y, legend_x = legend_x, ylab_x = ylab_x))
}

#' Adding titles and labels to graph
#' 
#' @inheritParams stackedbar_internal
#' @param main_y a numeric value specifying the y coordinate of main title
#'               (measured as number of lines below the top edge of the plot area).
#' @param main.cex a numeric value setting the font size (expansion factor) 
#'                 for the main title.
#' @param submain.cex a numeric value setting the font size (expansion factor) 
#'                    for the submain title.
#' @param axes.labs.cex a numeric value setting the font size for axes' labels.
#' @param xlab_y a numeric value setting y coordinate of the OX axis title 
#'               (measured as number of lines below the top edge of the plot area).
#' @param ylab_x a numeric value setting x coordinate of OY axis title 
#'               (measured as number of lines below the top edge of the plot area).
#'  
#' @keywords internal
add_titles <- function(main, main_y, main.cex, submain, submain.cex, 
                       axes.labs.cex, xlab, ylab, xlab_y, ylab_x) 
{    
    # range
    xy <- xy.range()
    mid_x <- (xy$x0 + xy$x1) / 2
    mid_y <- (xy$y0 + xy$y1) / 2
    lx <- lines2xy()$x
    ly <- lines2xy()$y
    
    # main
    text(x = mid_x, y = xy$y1 + main_y * ly * submain.cex, labels = main, 
         cex = main.cex, pos = 3, xpd = T, font = 2)    
    
    # submain
    text(x = mid_x, y = xy$y1 + 0.7 * ly, labels = submain, cex = submain.cex, 
         pos = 3, xpd = T) 
    
    # xlab
    text(x = mid_x, y = xy$y0 - xlab_y * ly * axes.labs.cex, labels = xlab, 
         cex = axes.labs.cex, pos = 1, xpd = T)    
    
    # ylab
    text(x = xy$x0 - ylab_x * lines2xy()$x, 
         y = mid_y, labels = ylab, xpd = T, 
         cex = axes.labs.cex, pos = 3, srt = 90)        
    
}



#' Specification of the OX axis tick-marks
#' 
#' @param n a number of periods.
#' @param freq a numeric, \code{freq} attribute of \code{ts} objects.
#' @param st a numeric, the second element of vector 
#'           returned by \code{start} function.
#' @param nmin a numeric specifying the minimum number of intervals.
#' @param nmax a numeric specifying the maximum number of intervals.
#' 
#' @keywords internal
#' 
get_at <- function(n, freq, st, nmin = 4, nmax = 9)
{
    if (n < nmax | freq < 1) return (1 : n)
    if (n %/% freq >= nmin) {
        at <- (freq + 2 - st) %% freq
        if (at == 0) at <- freq
        step <- freq
        if (n %/% freq > 10 * nmin) step <- 10 * freq
        step = ceiling(n / (8 * step)) * step
    } else {
        at <- 1
        step <- floor(n / nmax)
    }
    return(seq(from = at, to = n, by = step))
}

#' Retrieving time index from \code{ts} class objects
#' 
#' @param st_ind a numeric, the first element of vector 
#'               returned by \code{start} function.
#' @inheritParams get_at
#' 
#' @keywords internal
get_ts_ind <- function(st_ind, st, freq, n)
{
    if (freq == 1) return(seq(from = st_ind, by = 1, length.out = n))
    repl <- function(i, s, f, n, sep) {
        add <- ceiling(n / f)
        res <- kronecker(i : (i + add), rep(1, f))
        ii <- 1 : f
        if (f > 10) ii <- c(paste0("0", 1:9), 10:f)
        res2 <- rep(ii, add + 1)
        paste0(res[s : (s + n - 1)], sep, res2[s : (s + n - 1)])
    }
    if (freq == 2) return(repl(st_ind, st, freq, n, "H"))
    if (freq == 4) return(repl(st_ind, st, freq, n, "Q"))
    if (freq == 12) return(repl(st_ind, st, freq, n, "-"))
    return (paste0("t", 1:n))
}

# vector of colours
bar_colours <- c("red3", "gray73", "gray48", 
                "gray20", "orangered4", 
                "darkorange2", "coral3", "yellow",
                "lightblue", "darkgreen", "black", "green3",
                "purple", "maroon", "olivedrab", "skyblue3", "black", "blue", 
                "plum", "salmon", "navy")
                