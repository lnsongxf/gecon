# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski                                                    #
# ############################################################################
# Kalman smoother for DSGE models
# ############################################################################

#' Kalman smoother for DSGE models
#'
#' The \code{smoother} function uses the Kalman smoother formulas
#' to obtain smoothed past values of variables 
#' and stochastic innovations.   
#' 
#' @param model an object of \code{gecon_model} class. The state-space 
#'              representation for the smoother is created based on 
#'              the model solution.
#' 
#' @param data_set an object of \code{ts} class containing time series
#'                 based on which the smoothing is to be performed.
#'
#' @param observables a character of the length 
#'                      equal to the number of \code{data_set} argument columns.
#'                      By this argument one has to specify names of
#'                      observable variables supplied 
#'                      in the \code{data_set} argument.
#'
#' @param variables a character vector of the model variables' names
#'                  for which the smoothing is to be performed.
#'                  If set to NULL (default), only state variables are smoothed.
#' 
#' @return The function returns a list with three elements:
#' \itemize{
#'          \item \code{smoothed_var} a \code{ts} object of smoothed values of
#'                             the variables of interest,
#'          \item \code{smoothed_shock} a \code{ts} object of smoothed shock values,
#'          \item \code{P} a matrix of the mean squared errors.
#'         }
#'
#' @details The detailed description of Kalman filter and smoother
#'          can be found in Hamilton, J. D. 1994. \emph{Time series analysis}.
#'          Princeton, NJ: Princeton Univ. Press. 
#'
#' @examples
#' # load data_set and estimation results
#' data(estimated_model)
#' data(example_estimation_data)
#' 
#' # perform smoothing
#' dsge_smoothed_variables <- smoother(model = estimated_model, 
#'                                     data_set =  example_estimation_data, 
#'                                     observables = c("Y", "G"), 
#'                                     variables = c("K", "I", "C"))
#'
#' # smoothed shock values
#' dsge_smoothed_variables$smoothed_shock
#' # smoothed variable values
#' dsge_smoothed_variables$smoothed_var
#' # MSE matrix
#' dsge_smoothed_variables$MSE
smoother <- function(model, data_set, observables, variables = NULL)
{
    if(!is.gecon_model(model))
        stop("the model argument has to be of gecon_model class")

    if((!is.ts(data_set) & !is.mts(data_set)))
        stop("the data_set argument has to be of ts class")
    
    if(!is.character(observables))
        stop("the observables argument has to be a character vector")
        
    if (is.null(variables)) {
        pert_solution <- get_pert_solution(model, silent = TRUE)
        variables <- names(pert_solution$ss_val[pert_solution$state_ind])
    }

    variables_ind <- match(variables, get_var_names(model))   
    
    # retrieve data and validate them with model
    val_data <- validate_data(model, data_set = data_set, observables = observables)
    obs_var_indices <- val_data$obs_var_indices
    observables <- val_data$observables
    series_start <- val_data$series_start
    series_freq <- val_data$series_freq
    data_set <- val_data$data_set
    n_obs <- val_data$n_obs
    n_var <- val_data$n_var

    value_on_failure <- NULL
    
    if ( n_var > length( get_shock_names(model) ) )
        stop("number of observable variables cannot be greater than number of shocks in the model")
    
    # find steady-state values
    if ( !ss_solved(model) )
        model <- steady_state( model )

    if ( !ss_solved(model) ) {
        stop("steady state for the model has not been found")
    }
    
    # find perturbation solution
    if (!re_solved(model))
        suppressWarnings(model <- solve_pert(model))
    
    if (!re_solved(model)) {
        stop("perturbation has not been solved")
    }

    pert_solution <- get_pert_solution(model, silent = TRUE)
    ns_variables <- names(pert_solution$ss_val[-pert_solution$state_ind])
    state_vars <- names(pert_solution$ss_val[pert_solution$state_ind])
    
    # get solution matrices ( for R and S only rows which correspond to variables which are in data)
    P <- as.matrix( pert_solution$P )
    Q <- pert_solution$Q
    R <- pert_solution$R
    S <- pert_solution$S
    
    # get number of state variables and variables in data
    p <- nrow(P)  
    
    # ##########################################################################
    # creating state space model
    
    # build transition equation
    F <- rbind(R, P)
    n_vars <- nrow(F)
    F <- cbind(matrix(0, ncol = n_vars - ncol( F ), nrow = n_vars), F)
   
    colnames(F) <- c(ns_variables, state_vars) 
    rownames(F) <- c(ns_variables, state_vars)
    
    obs_var_ind <- match(observables, colnames(F))
    variables_ind <- match(variables, colnames(F))    
    # build variance-covariance matrix of structural innovations 
    G <- rbind(S, Q)
    cov_mat <- get_shock_cov_mat(model)
    GG <- G %*% cov_mat %*% t(G)
    
    # solve Lyapunov equation to get initial variance-covariance matrix
    ME_0 <- lyapunov(F, GG)
  
    # prepare observation equation. For the beginning take matrix of zeros
    H <- matrix(0, nrow = n_var, ncol = n_vars)
    
    # state to observable variables mapping
    H[c(1:n_var), obs_var_ind] <- diag(n_var)
    
    # there is no error term in measurement equation, so matrix of zeros is used
    J <- matrix(0, nrow = n_var, ncol = n_var)
    
    # initial state vector is just zeros
    x_0 <- rep(0, n_vars)
    
    # state-space model formulation
    ss_model <- SSModel(data_set ~ 0 + SSMcustom(Z = H, T = F, R = diag(dim(GG)[1]), 
                                                 Q = GG, a1 = x_0, P1 = ME_0),  
                                                 H = J, tol = 1e-5)
    # ##########################################################################
    # smoother   
    smooth_list <- list(state = NULL, 
                        shock = matrix(0, dim(cov_mat)[1], n_obs),
                        P = NA)

    # smooth state variables
    smooth_list$state <- KFS(ss_model, smoothing = "state", 
                             simplify = FALSE, convtol = 1e-1)
    
    # retrieve shock realisations
    r <- rep(0, dim(GG)[1])
    
    # as KFS does not return smoothed values of shocks
    # this code runs Kalman Smoother for shocks
    inv_f <- array(dim = c(n_var, n_var, nrow(data_set)))
    pzi <- array(dim = c(nrow(F), n_var, nrow(data_set)))
    K <- array(dim = c(nrow(F), n_var, nrow(data_set)))
    err_wrt_data <- matrix( ncol = n_var,  nrow = nrow(data_set))
    
    # perform forward steps
    for (i in 1:nrow(data_set)) {
        inv_f[, , i] <- solve(H %*% smooth_list$state$P[, , i] %*% t(H))
        err_wrt_data[i, ] <- (-H %*% smooth_list$state$a[i,])
        pzi[, , i] <- smooth_list$state$P[, , i] %*% t(H)  %*% inv_f[, ,i]
        K[, ,i] <- F %*% pzi[, , i]
    }
    
    # perform backward steps
    for (i in (nrow(data_set)):1) {
        r <- t(H) %*% inv_f[ , , i]  %*% (err_wrt_data[i, ] + data_set[i, ]) +
              t(F - K[, , i]  %*% H)  %*% r
        smooth_list$shock[, i] <- cov_mat %*% t(G) %*% r
    }

    # ##########################################################################
    # retrieve the results
    
    # retrieve MSE
    smooth_list$P <- smooth_list$state$P[-c(1: nrow(R)), 
                                         -c(1: nrow(R)), nrow(data_set)]
    rownames(smooth_list$P) <- state_vars
    colnames(smooth_list$P) <- state_vars

    # retrieve smoothed values
    smooth_list$state <- smooth_list$state$alphahat 
    sm_var <- ts(data = smooth_list$state, 
                 start = series_start, 
                 frequency = series_freq,
                 names = colnames(F))

    # prepare output list
    sm_l <- vector(length = 0, mode = "list")
    sm_l$smoothed_var <- sm_var[, variables]                                    
    sm_l$smoothed_shock <- ts(data = t(smooth_list$shock), 
                              start = series_start, 
                              frequency = series_freq,
                              names = rownames(cov_mat))    
    sm_l$MSE <- smooth_list$P
    
    return(sm_l)
}
