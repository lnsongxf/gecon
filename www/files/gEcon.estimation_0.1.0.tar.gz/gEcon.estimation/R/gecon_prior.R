# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski, Paweł Romański                                    #
# ############################################################################
# A S4 class to represent the prior distributions for DSGE model parameters
# ############################################################################


#' S4 class to represent the prior distributions for model parameters
#' 
#' The \code{gecon_prior} class stores information about prior
#' distribution for estimated parameters of DSGE model. 
#'
#' For detailed description of how to specify prior distributions, see
#' \code{\link{gecon_prior}}.
#' 
#' @slot model_par a character vector of parameter names.
#' 
#' @slot parameters_tex a character vector of all parameters' LaTeX names.
#'       
#' @slot dist_type a numeric vector of distribution codes (1 - beta distribution,
#'       2 - gamma distribution, 3 - inverted gamma distribution (of the 1st type), 
#'       4 - inverted gamma distribution (of the 2nd type),
#'       5 - normal distribution, 6 - uniform distribution). 
#' 
#' @slot parameters a numeric matrix of the prior distribution 
#'                  parameter values. The first column corresponds 
#'                  to the \code{a} parameter
#'                  while the second to the \code{b} parameter.
#'       
#' @slot bounds a numeric matrix of the prior distribution bounds. 
#'               The first column corresponds to the lower bound
#'               while the second to the upper bound.
#' 
#' @slot moments a numeric matrix of the prior distribution's 
#'                statistics. The first column corresponds to the mean
#'                while the second to the standard deviations.
#'       
#' @slot initial a numeric vector of initial values of parameters
#'               for the estimation.
#'       
#' @slot par_type a numeric vector of length equal to the number
#'                of estimated parameters with the following codes:
#'                \itemize{
#'                   \item 0 denotes free parameter,
#'                   \item 1 denotes standard deviation of a shock,
#'                   \item 2 denotes correlation of shocks.
#'                }
#' 
#' @slot model_info a character vector with information
#'                  about the model the prior distribution
#'                  of parameters refers to: the input file name, 
#'                  the input file path, and the date of creation.
#' 
#' @slot shock_names_matrix a matrix of characters; the names of
#'                          shocks for which standard deviations 
#'                          and correlations have been specified.                                                     
#'                                                     
#' @section Methods:
#'          \subsection{print}{
#'              Prints number of parameters for which prior distributions
#'              have been specified.}
#'          \subsection{show}{
#'              Prints names of parameters for which prior distributions
#'              have been specified.}
#'          \subsection{summary}{
#'              Prints a summary of an object of \code{gecon_prior}
#'              class consisting of moments of prior distribution,
#'              values of parameters, and their initial values 
#'              used for the estimation.
#'          }
setClass("gecon_prior",
         slots = c(model_par = "character",
                   parameters_tex = "character",
                   dist_type = "numeric",
                   parameters = "matrix",
                   bounds = "matrix",
                   moments = "matrix",
                   initial = "numeric",
                   par_type = "numeric",
                   model_info = "character",
                   shock_names_matrix = "matrix") 
)


#' Constructor for the \code{gecon_prior} class
#' 
#' The \code{gecon_prior} function is a constructor of \code{gecon_prior} class objects.
#' 
#' Prior distributions can be specified either for model free parameters or 
#' standard deviations/correlations of shocks. In the current release of the package
#' the following distributions can be specified
#' (\eqn{L} stands for \code{lower_bound} and 
#' \eqn{U} stands for \code{upper_bound}):
#' \itemize{
#'      \item beta distribution with the parameters \eqn{a > 0}, \eqn{b > 0} and density function:  
#'            \deqn{f(x) = \Gamma(a + b)/(\Gamma(a)\Gamma(b))(x - L)^{(a - 1)}(1 - (U - x))^{(b - 1)}/(U - L) ^{(a + b - 1)}}
#'            for \eqn{L < x < U} and zero otherwise.
#'      \item gamma distribution with the parameters \eqn{a > 0}, \eqn{b > 0} and density function: 
#'            \deqn{f(x) = 1/(b^{a} \Gamma(a)) (x - L)^{(a - 1)} e^{-((x - L) / b)}}
#'            for \eqn{x > L} and zero otherwise,
#'      \item inverted gamma distribution (1st type - inverted square root of gamma distributed variable)
#'            with the parameters \eqn{a > 0}, \eqn{b > 0} and density function:
#'            \deqn{f(x) = (\frac{2}{b})^{a / 2} \Gamma(\frac{a}{2}) 2 (x - L)^{(-a - 1)} e^{-b / 2 (x - L) ^ 2}}
#'            for \eqn{x > L} and zero otherwise,
#'      \item inverted gamma distribution (2nd type - inverted gamma distributed variable) 
#'            with the parameters \eqn{a > 0}, \eqn{b > 0}:
#'            \deqn{f(x) = (\frac{2}{b})^{a/2} \Gamma(\frac{a}{2}) (x - L)^{(-a/2-1)} e^{-b / 2 (x - L)}}
#'            for \eqn{x > L} and zero otherwise,
#'      \item normal distribution with the parameters \eqn{a \in R}, \eqn{b > 0}:
#'            \deqn{f(x) = 1 / (\sqrt{2\pi} b) e^{-((x - a) ^ 2 / (2 b ^ 2))},}
#'      \item uniform distribution with the parameters \eqn{L}, \eqn{U} (\eqn{L < U}):
#'            \deqn{f(x) = 1/(U - L)} 
#'            for \eqn{L < x < U} and 0 otherwise.
#' }
#'
#' Prior distributions are declared by passing a list of named lists. 
#' Each list should contain a name of a model parameter for which prior distribution
#' is specified, type of distribution, and its mean and standard deviation
#' or parameters (the constructor calculates parameters of distribution,
#' if the distribution mean and standard deviation are supplied). 
#' Priors for standard deviations and correlations of shocks can be
#' declared using the following syntax: 
#' standard deviation: "\code{sd( shock_name )}", 
#' correlation: "\code{cor( shock_name1, shock_name2 )}". 
#'
#' Additionaly, custom bounds for the distribution parameters,
#' and initial values for computation of the posteror kernel mode
#' may be supplied. The default bounds are equal to:
#' \itemize{
#'      \item \code{lower_bound} = 0, \code{upper_bound} = 1 for beta distribution,
#'      \item \code{lower_bound} = 0 for gamma distribution,
#'      \item \code{lower_bound} = 0 for inverted gamma distributions.
#' }
#' In the case of the uniform distribution \code{l_bound} and \code{u_bound} 
#' are treated both as bounds and parameters.
#' 
#' For each distribution, the parameter \code{initial} can be also provided
#' specifying the initial values for parameter estimation.
#'  
#' @param prior_list a list of lists with the declaration of prior distribution 
#'                   for DSGE model parameters. Each sub-list should contain 
#'                   the \code{par} and \code{type} elements declaring 
#'                   name of parameter and type of the distribution, respectively.
#'                   The distribution parameters may be supplied either explicitly 
#'                   (\code{a} and \code{b}) or by mean and standard deviation of the distribution
#'                   (\code{mean} and \code{sd}).
#'                   Additionally, bounds for distribution values (\code{lower_bound} and 
#'                   \code{upper_bound}) and initial values for computation
#'                   of the posterior kernel distribution (\code{initial}) 
#'                   may be specified in each sub-list.
#'
#' @param model an object of \code{gecon_model} class 
#'              for which the parameter prior distributions are specified.
#'
#' @return The function constructs an object of \code{gecon_prior} class.
#' 
#' @examples
#' # copy the example to the current working directory
#' file.copy(from = file.path(system.file("examples", package = "gEcon.estimation"),
#'                            "dsge_model.gcn"), to = getwd())
#' dsge_model <- make_model("dsge_model.gcn")
#' 
#' # declare prior distribution
#' dsge_prior <- gecon_prior(
#'     prior_list = list(
#'         list(par = "sd(epsilon_Z)", type = "inv_gamma",
#'              mean = 0.012, sd = 0.3, lower_bound = 0.0001, 
#'              upper_bound  = 0.9, initial = 0.008),
#'         list(par = "sd(epsilon_G)", type = "inv_gamma",
#'              mean = 0.008, sd = 0.3, lower_bound = 0.0001, 
#'              upper_bound  = 0.9, initial = 0.008),
#'         list(par = "omega", type = "normal",
#'              mean = 1.45, sd = 0.1, lower_bound = 1, 
#'              upper_bound  = 2, initial = 1.5),
#'         list(par = "phi_G", type = "beta",
#'              mean = 0.88, sd = 0.03, lower_bound = 0.5, 
#'              upper_bound  = 0.999, initial = 0.92),
#'         list(par = "phi_Z", type = "beta",
#'              mean = 0.92, sd = 0.03, lower_bound = 0.5, 
#'              upper_bound  = 0.999, initial = 0.96)),
#'     model = dsge_model)
#' 
#' plot_prior(dsge_prior)
gecon_prior <- function(prior_list, model) 
{    
    if ( length( prior_list ) == 0 )
        stop("prior information has not been specified for any parameter")
    if ( !is.list( prior_list ) )
        stop("prior information should be provided as a list of lists")
    if ( class(model) != "gecon_model" )
        stop("model argument should be of gEcon_model class")
    
    # check if prior is a list of lists
    p_list <- lapply(prior_list, 'is.list')
    if (any(p_list == FALSE))
        stop("there is one or more prior_list element that is not a list")
    
    object <- new("gecon_prior")
    
    object@model_info <- model@model_info

    avail_dist <- c("beta", "gamma", 
                    "inv_gamma",  "inv_gamma2", 
                    "normal",  "uniform")

    # get names of available distributions

    # parsing list names
    param_dim <- sapply(prior_list, "length", simplify = "array")
    max_num <- max(param_dim)
    
    f_names <- function(a) {b <- names(a); c(b, rep("", max_num - length(b)))}
    param_names <- sapply(prior_list, f_names, simplify = "character")

    f_values <- function(a) {b <- a; c(b, rep("", max_num - length(b)))}
    param_values <- sapply(prior_list, f_values, simplify = "character")
    
    # validate par names
    par_ind <- which(param_names == "par", arr.ind = TRUE)

    if(!all(c(1:length(param_dim)) %in% par_ind[, 2]))
        stop("the par element is missing in one or more lists")
    par_names <- as.character(param_values[par_ind])
    par_types <- parameter_type(model = model, parameters = par_names)
    
    object@parameters_tex <- par_types$parameters_tex
    object@par_type <- par_types$par_type
    object@shock_names_matrix <- par_types$shock_names_matrix 
    object@model_par <- par_names
    
    # recode distribution names
    type_ind <- which(param_names == "type", arr.ind = TRUE)
    type_names <- as.character(param_values[type_ind])
    type_ind <- match(type_names, avail_dist)
    if (all(is.na(type_ind))) {
        # maximum likelihood case
        object@dist_type <- rep(0, length(type_ind))
    } else if (any(is.na(type_ind))) {
        stop(paste("the following distribution names: \n", paste(type_names[which(is.na(type_ind))], sep = ", "), 
                    "were misspelled"))
    } else {
        object@dist_type <- type_ind
        
        # Bayesian estimation
        object@moments <- matrix(NA, length(object@model_par), 2)
        object@parameters <- matrix(NA, length(object@model_par), 2)
        # mean
        mean_ind <- which(param_names == "mean", arr.ind = TRUE)
        object@moments[mean_ind[, 2], 1] <- as.numeric(param_values[mean_ind])
        # sd
        std_ind <- which(param_names == "sd", arr.ind = TRUE)
        object@moments[std_ind[, 2], 2] <- as.numeric(param_values[std_ind])        
        # alpha
        alpha_ind <- which(param_names == "a", arr.ind = TRUE)
        object@parameters[alpha_ind[, 2], 1] <- as.numeric(param_values[alpha_ind])   
        # beta
        beta_ind <- which(param_names == "b", arr.ind = TRUE)
        object@parameters[beta_ind[, 2], 2] <- as.numeric(param_values[beta_ind])  
    }

    init_ind <- which(param_names == "initial", arr.ind = TRUE)
    
    object@initial <- as.numeric(rep(NA, length(object@model_par)))
    object@initial[init_ind[, 2]] <- as.numeric(param_values[init_ind])   
    
    
    # bounds of distributions
    object@bounds <- matrix(NA, length(object@model_par), 2)
   
    lower_ind <- which(param_names == "lower_bound", arr.ind = TRUE)
    object@bounds[lower_ind[, 2], 1] <- as.numeric(param_values[lower_ind])  
    
    upper_ind <- which(param_names == "upper_bound", arr.ind = TRUE)
    object@bounds[upper_ind[, 2], 2] <- as.numeric(param_values[upper_ind])
    
    unspec_bounds <- rowSums(is.na(object@bounds))
    
    if (length(intersect(which(unspec_bounds == 1), which(object@dist_type == 1))))
        stop(paste("for beta distribution either no bounds should be specified (default values of 0 and 1 will be assumed)",
                    "or both lower and upper bounds have to be specified"))

    if (length(intersect(which(unspec_bounds == 2), which(object@dist_type == 1)))) {
        object@bounds[intersect(which(unspec_bounds == 2), which(object@dist_type == 1)), 1] <- 0
        object@bounds[intersect(which(unspec_bounds == 2), which(object@dist_type == 1)), 2] <- 1
    }
    
    if (length(intersect(which(unspec_bounds > 0), which(object@dist_type == 2)))) {
        object@bounds[intersect(which(is.na(object@bounds[, 1])), which(object@dist_type == 2)), 1] <- 0
        object@bounds[intersect(which(is.na(object@bounds[, 2])), which(object@dist_type == 2)), 2] <- Inf    
    }

    if (length(intersect(which(unspec_bounds > 0), which(object@dist_type == 3)))) {
        object@bounds[intersect(which(is.na(object@bounds[, 1])), which(object@dist_type == 3)), 1] <- 0
        object@bounds[intersect(which(is.na(object@bounds[, 2])), which(object@dist_type == 3)), 2] <- Inf
    }
    
    if (length(intersect(which(unspec_bounds > 0), which(object@dist_type == 4)))) {
        object@bounds[intersect(which(is.na(object@bounds[, 1])), which(object@dist_type == 4)), 1] <- 0
        object@bounds[intersect(which(is.na(object@bounds[, 2])), which(object@dist_type == 4)), 2] <- Inf
    }
    
    if (length(intersect(which(unspec_bounds > 0), which(object@dist_type == 5)))) {
        object@bounds[intersect(which(is.na(object@bounds[, 1])), which(object@dist_type == 5)), 1] <- -Inf
        object@bounds[intersect(which(is.na(object@bounds[, 2])), which(object@dist_type == 5)), 2] <- Inf
    }
    
    if (length(intersect(which(unspec_bounds > 1), which(object@dist_type == 6))))
        stop("for uniform distribution parameters both lower and upper bounds have to be specified")    
    
    
    if (any(object@dist_type == 6))
        object@parameters[which(object@dist_type == 6), ] <- object@bounds[which(object@dist_type == 6), ]
    
    par_as_mom <- rowSums(is.na(object@moments)) == 0
    par_as_par <- rowSums(is.na(object@parameters)) == 0
    
    if (any(par_as_mom & par_as_par)) {
        stop(paste("for the following parameters of model", object@model_par[which(par_as_mom & par_as_par)], 
                   "parameters were passed both as moments and distribution parameters"))
    }
    
    par_as_mom <- which(par_as_mom)
    par_as_par <- which(par_as_par)

    moments_to_par <- function(a, dist_code) {
        switch(as.character(dist_code),
               "1" = {return(beta_params(mean_b = a[1], std_b = a[2], start_b = a[3], end_b = a[4]))},
               "2" = {return(gamma_params(mean_g = a[1], std_g = a[2], start_g = a[3]))},
               "3" = {return(inverted_gamma_1_parameters(mean_i = a[1] , sd_i = a[2]))},
               "4" = {return(inverted_gamma_2_parameters(mean_i = a[1] - a[3], sd_i = a[2]))},
               "5" = {return(normal_params(mean_n = a[1], std_n = a[2]))},
               "6" = {return(uniform_params(mean_u= a[1], std_u = a[2]))}
        )
    }

    # computing parameters    
    if (length(par_as_mom)) {
        for (i in 1:length(par_as_mom)) {
            object@parameters[par_as_mom[i],] <- as.numeric(moments_to_par(c(object@moments[par_as_mom[i],], 
                                                                             object@bounds[par_as_mom[i], ]), 
                                                                           object@dist_type[par_as_mom[i]])
                                                            )
        }
    }
    
    par_to_moments <- function(a, dist_code) {
        switch(as.character(dist_code),
               "1" = {return(beta_mom(a = a[1], b = a[2], L = a[3], U = a[4]))},
               "2" = {return(gamma_mom(a = a[1], b = a[2], L = a[3]))},
               "3" = {return(inverted_gamma_1_mom(a = a[1], b = a[2], L = a[3]))},
               "4" = {return(inverted_gamma_2_mom(a = a[1], b = a[2], L = a[3]))},
               "5" = {return(normal_mom(a = a[1], b = a[2]))},
               "6" = {return(uniform_mom(a= a[1], b = a[2]))}
        )
    }
    if (length(par_as_par)) {
        for (i in 1:length(par_as_par)) {
            object@moments[par_as_par[i],] <- as.numeric(par_to_moments(c(object@parameters[par_as_par[i],], 
                                                                          object@bounds[par_as_par[i], ]), 
                                                                         object@dist_type[par_as_par[i]])
                                                         )
        }
    }

    if (any(object@bounds[, 1] > object@bounds[, 2])) {
        low_up_bounds <- which(object@bounds[, 1] > object@bounds[, 2])
        stop(paste("for the following parameters the upper bound is lower than the lower bound:\n",
             paste(object@model_par[low_up_bounds], collapse = ", ")))
    }

    init <- which(!is.na(object@initial))

    if (any(object@initial[init] < object@bounds[init, 1] |  object@initial[init] > object@bounds[init, 2])) {
        init_out_bounds <- which((object@initial[init] < object@bounds[init, 1] | object@initial > object@bounds[init, 2]))
        stop(paste("the initial values for estimation of the following parameters lie outside the distribution support:\n",
             paste(object@model_par[init_out_bounds], collapse = ", ")))
    }

    return(object)
}

#' Return prior density for plotting
#' 
#' The \code{prior_density_xy} function returns 
#' coordinates for plotting prior distributions/ 
#'  
#' @param prior an object of \code{gecon_prior} class.
#'
#' @param name a character with the name of parameter.
#'
#' @return The function returns a two element list 
#'         with x and y coordinates for 
#'        the given distribution.
#'
#' @keywords internal
prior_density_xy <- function(prior, name)
{
    if(!is.gecon_prior(prior))
        stop("the prior argument has to be of gecon_prior class")

    ind <- match(name, prior@model_par)
    
    
    plot_par <- function(a, dist_code) {
        switch(as.character(dist_code),
               "1" = {return(plot_beta(a= a[1], b = a[2], L = a[3], U = a[4]))},
               "2" = {return(plot_ggamma(a = a[1], b = a[2], L = a[3], U = a[4]))},
               "3" = {return(plot_inv_gamma(a= a[1], b= a[2], L = a[3], U = a[4]))},
               "4" = {return(plot_inv_gamma_2(a= a[1], b= a[2], L = a[3], U = a[4]))},
               "5" = {return(plot_norm(a= a[1], b= a[2], L = a[3], U = a[4]))},
               "6" = {return(plot_uniform(L= a[1], U= a[2]))}
        )
    }

    return(plot_par(c(prior@parameters[ind, ], prior@bounds[ind, ]), prior@dist_type[ind]))
}

#' Plot prior distributions
#' 
#' The \code{plot_prior} function plots prior distributions.
#'
#' @param prior an object of \code{gecon_prior} class.
#'
#' @param to_eps logical. If TRUE, plot(s) are saved as \code{.eps} 
#'        file(s) in the model's subdirectory \code{/plots} and added 
#'        to \code{.results.tex} file.
#'
#' @examples
#' # copy the example to the current working directory
#' file.copy(from = file.path(system.file("examples", package = "gEcon.estimation"),
#'                            "dsge_model.gcn"), to = getwd())
#' dsge_model <- make_model("dsge_model.gcn")
#' 
#' # declare prior distribution
#' dsge_prior <- gecon_prior(
#'     prior_list = list(
#'         list(par = "sd(epsilon_Z)", type = "inv_gamma",
#'              mean = 0.012, sd = 0.3, lower_bound = 0.0001, 
#'              upper_bound  = 0.9, initial = 0.008),
#'         list(par = "sd(epsilon_G)", type = "inv_gamma",
#'              mean = 0.008, sd = 0.3, lower_bound = 0.0001, 
#'              upper_bound  = 0.9, initial = 0.008),
#'         list(par = "omega", type = "normal",
#'              mean = 1.45, sd = 0.1, lower_bound = 1, 
#'              upper_bound  = 2, initial = 1.5),
#'         list(par = "phi_G", type = "beta",
#'              mean = 0.88, sd = 0.03, lower_bound = 0.5, 
#'              upper_bound  = 0.999, initial = 0.92),
#'         list(par = "phi_Z", type = "beta",
#'              mean = 0.92, sd = 0.03, lower_bound = 0.5, 
#'              upper_bound  = 0.999, initial = 0.96)),
#'     model = dsge_model)
#' 
#' plot_prior(dsge_prior)
plot_prior <- function(prior, to_eps = FALSE)
{
    if(!is.gecon_prior(prior))
        stop("the prior argument has to be of gecon_prior class")
        
    n_priors <- length(prior@model_par)
    
    avail_dist <- c("beta", "gamma", 
                    "inverted gamma", "inverted gamma (2nd type)", "normal", 
                    "uniform") 

    if (to_eps) {
        path_m <- gsub(pattern = paste0(prior@model_info[1], "(.gcn)?$"),
                       replacement = "",
                       x = prior@model_info[2])
        path_m <- paste(path_m, "plots", sep = "")
        dir.create(path_m, showWarnings = FALSE)
        files <- character()
        descriptions <- character()
    }
    
    for (i in 1:n_priors) {
        coord <- prior_density_xy(prior, prior@model_par[i])
        if (to_eps) {
            file_name <- gEcon:::unique_output_name(path_m)
            files <- c(files, file_name)
            file_name <- paste0(path_m, "/", file_name)
            descr <- paste0("Prior distribution for: $", prior@parameters_tex[i], "$")
            descriptions <- c(descriptions, descr)
            main <- NULL
            submain <- NULL
        } else {
            file_name <- NULL
            main <- paste("The ", prior@model_par[i], " parameter has ", avail_dist[prior@dist_type[i]],
                            " distribution", sep = "")
            submain <- paste("(mean = ", round(prior@moments[i, 1], 4), "std_dev = ", 
                                round(prior@moments[i, 2], 4), ")")
        }
        gecon_lines(data = coord, eps_path = file_name,
                    main = main, submain = submain)
    }
    
    
    if (to_eps) {
        tex_out <- paste0("\n\\pagebreak\n\n\\section{", "Prior distributions", "}\n\n")
        tnpl <- length(files)
        if (tnpl == 1) {
            inds2 <- numeric()
            indr <- 1
        } else {
            inds2 <- 2 * (1:(tnpl %/% 2))
            indr <- (tnpl %% 2) * (1 + 2 * (tnpl %/% 2))
        }
        
        for (i in inds2) {
            mpage <- paste0("\\begin{figure}[h]\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-1em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[i - 1], "}\n",
                            "\\caption{", descriptions[i - 1] , "}\n",
                            "\\end{minipage}\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-1em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[i], "}\n",
                            "\\caption{", descriptions[i] ,"}\n",
                            "\\end{minipage}\n",
                            "\\end{figure}\n\n")
            tex_out <- paste0(tex_out, mpage)
            if (!(i %% 4)) tex_out <- paste0(tex_out, "\\pagebreak\n\n")
        }
        if (indr) {
            mpage <- paste0("\\begin{figure}[h]\n",
                            "\\centering\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-1em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[indr], "}\n",
                            "\\caption{", descriptions[indr] ,"}\n",
                            "\\end{minipage}\n",
                            "\\end{figure}")
            tex_out <- paste0(tex_out, mpage)
        }
        filenam <- paste0(gsub(pattern = paste0("(.gcn)?$"),
                               replacement = "",
                               x = prior@model_info[2]), ".results.tex")
        if (file.exists(filenam)) {
            write(tex_out, filenam, sep = "\n", append = TRUE)
        } else {
            write(tex_out, filenam  , sep = "\n")
        }
        cat(paste0("saved ", gEcon:::list2str(files, "\'"), " in directory \'", path_m, "\'\n"))
        cat(paste0("plot(s) added to \'", filenam, "\'\n"))
    }
    
    return(invisible(NULL))
}

#' @rdname summary-methods
setMethod("summary",
          "gecon_prior",
          function(object) {
              avail_dist <- c("beta", "gamma", 
                              "inv_gamma", "inv_gamma2", "normal",
                              "uniform") 
              
              prior_info <- vector(length = 0, mode = "list")
              cat("Moments of the distributions specified for model parameters\n")
              prior_df <- data.frame(avail_dist[object@dist_type], object@moments, row.names=object@model_par)
              colnames(prior_df) <- c("Distribution type", "Mean", "Std. deviation")
              prior_info$distribution <- prior_df

              cat("\n----------------------------------------------------------", "\n\n")
              
              cat("\nParameters of the distributions specified for model parameters\n")
              prior_df <- data.frame(avail_dist[object@dist_type], object@parameters, object@bounds, row.names=object@model_par)
              colnames(prior_df) <- c("Distribution type", "1st parameter", "2nd parameter", "Lower bound", "Upper bound")
              print(prior_df)
              prior_info$parameters <- prior_df

              cat("\n----------------------------------------------------------", "\n\n")
              
              cat("\nInitial values of parameters for estimation \n")
              prior_df <- data.frame(object@initial, row.names=object@model_par)
              colnames(prior_df) <- c("Initial value")
              print(prior_df)
              prior_info$initial <- prior_df
          
              return(prior_info)
          }
)


#' @rdname show-methods
setMethod("show",
          "gecon_prior",
          function(object) {
              cat("Prior has been created for", object@model_info[1], "model.\n")
                            
              cat("\nDistributions have been specified for", length(object@model_par), "parameters.\n")
          }         
)

#' @rdname print-methods
setMethod("print", signature(x = "gecon_prior"),
          function (x)
          {
              cat("Prior has been created for", x@model_info[1], "model.\n")
              
              cat("\n----------------------------------------------------------", "\n\n")
              
              cat("\nDistributions have been specified for", length(x@model_par), "parameters: \n")
              var_df <- data.frame(x@model_par, row.names = c(1:length(x@model_par)))
              colnames(var_df) <- "Parameters"
              print(var_df)
          }
)


#' Log density of the prior distribution
#' 
#' The \code{prior_density} function returns
#' the logarithm of prior density at given values.
#'
#' @param prior an object of \code{gecon_prior} class.
#' 
#' @param values a vector of values of the parameters 
#'               for which the log-density should be calculated.
#' 
#' @return The function returns the value of the log-density 
#'          in the given point. If the supplied values are out of 
#'         the distribution bounds, \code{-Inf} value is returned.
#
#' @keywords internal
prior_density <- function(prior, values) 
{
    if(!is.gecon_prior(prior))
        stop("the prior argument has to be of gecon_prior class")
        
    log_density <- c( log = 0 )
    for ( i in 1:length(prior@model_par) ) {
      
        # check lower_bound
        if ( !is.na(prior@bounds[i, 1] ) )
            if ( values[i] <= prior@bounds[i, 1] ) {
                return(-Inf)
            }
        
        # check upper_bound
        if ( !is.na(prior@bounds[i, 2] ) )
            if ( values[i] >= prior@bounds[i, 2] ) {
              return(-Inf)
            }    
    
        log_density <- switch(as.character(prior@dist_type[i]),
            "1" = {log_density + dbeta((values[i] - prior@bounds[i, 1]) / (prior@bounds[i, 2] - prior@bounds[i, 1]), 
                                        prior@parameters[i, 1], prior@parameters[i, 2], log = TRUE)},
            "2" = {log_density + dgamma(values[i] - prior@bounds[i, 1], prior@parameters[i, 1], rate = 1 / prior@parameters[i, 2], log = TRUE)},
            "3" = {log_density + pinvgamma(values[i], prior@parameters[i, 1], prior@parameters[i, 2], log = TRUE)},
            "4" = {log_density + pinvgamma_2(values[i] - prior@bounds[i, 1], prior@parameters[i, 1], prior@parameters[i, 2], log = TRUE)},
            "5" = {log_density + dnorm(values[i], mean = prior@parameters[i, 1], sd = prior@parameters[i, 2], log = TRUE)},
            "6" = {log_density + dunif(values[i], min = prior@parameters[i, 1], max = prior@parameters[i, 2], log = TRUE)}
        )
    }
    return (log_density)
}


#' Retrieving names of the estimated parameters
#' 
#' The \code{get_estimated_par_names} function returns names of 
#' parameters specified in the \code{gecon_prior} class object.
#'
#' @param prior an object of \code{gecon_prior} class.
#' 
#' @return The function returns a character vector of
#'         the estimated parameter names.
#'
#' @keywords internal
get_estimated_par_names <- function(prior)
{
    if(!is.gecon_prior(prior))
        stop("the prior argument has to be of gecon_prior class")
        
    return(prior@model_par)
}

#' Retrieving types of the estimated parameters
#' 
#' The \code{get_estimated_par_types} function 
#' returns a vector of the parameter type codes.
#'
#' @param prior an object of \code{gecon_prior} class.
#' 
#' @return The function returns a numeric vector of length equal to the number
#'         of estimated parameters with the following codes:
#'         \itemize{
#'                  \item 0 denotes free parameter,
#'                  \item 1 denotes standard deviation of a shock,
#'                  \item 2 denotes correlation of shocks.}
#'
#' @keywords internal
get_estimated_par_types <- function(prior)
{
    if(!is.gecon_prior(prior))
        stop("the prior argument has to be of gecon_prior class")
        
    return(prior@par_type)
}

#' Retrieving initial values of parameters for estimation
#' 
#' The \code{get_initial_values} function returns names of 
#' parameters specified in the \code{gecon_prior} class object.
#'
#' @param prior an object of gecon_prior class.
#' 
#' @return The function returns a numeric vector 
#'         of length equal to the number
#'         of estimated parameters containing their initial 
#'         values for posterior kernel mode computation.
#'
#' @keywords internal
get_initial_values <- function(prior)
{
    if(!is.gecon_prior(prior))
        stop("the prior argument has to be of gecon_prior class")
        
    init <- prior@initial
    names(init) <- prior@model_par
    
    return(init)
}
 
#' Retrieving prior means
#' 
#' The \code{get_prior_means} function allows to retrieve means
#' of prior distributions declared in the objects of 
#' \code{gecon_prior} class.
#'
#' @param prior an object of \code{gecon_prior} class.
#' 
#' @return The function returns a numeric vector of length 
#'         equal to the number of estimated parameters 
#'         containing means for prior distributions.
#'
#' @keywords internal
get_prior_means <- function(prior)
{
    if(!is.gecon_prior(prior))
        stop("the prior argument has to be of gecon_prior class")
        
    mom <- prior@moments[, 1]
    names(mom) <- prior@model_par
    
    return(mom)
}

#' Retrieving prior standard deviations
#' 
#' The \code{get_prior_sd} function allows to retrieve 
#' standard deviations
#' of prior distributions declared in the objects of 
#' \code{gecon_prior} class.
#'
#' @param prior an object of \code{gecon_prior} class.
#' 
#' @return The function returns a numeric vector of length equal to the number
#'         of estimated parameters containing standard deviations.
#'
#' @keywords internal
get_prior_sd <- function(prior)
{
    if(!is.gecon_prior(prior))
        stop("the prior argument has to be of gecon_prior class")
        
    mom <- prior@moments[, 2]
    names(mom) <- prior@model_par
    
    return(mom)
}

#' Check if an object is \code{gecon_prior}
#' 
#' The is.gecon_prior function allows to check if supplied 
#' argument is of \code{gecon_prior} class. 
#'
#' @param x any R object
#' 
#' @return a logical value indicating if object
#' is of class "gecon_prior"
#'
#' @keywords internal
is.gecon_prior <- function(x)
{
    if (is(x, "gecon_prior"))
        return(TRUE)
    else return(FALSE)
}


#' Accessing information about the name 
#' and the creation date of the model
#' 
#' The \code{get_prior_model_info} function returns 
#' a character vector with information about the model.
#'
#' @param prior an object of \code{gecon_prior} class.
#' 
#' @return The function returns a character vector of length 3, 
#' containing information about the model for which 
#' prior has been specified: the input file name, 
#' the input file path, and the date of creation.
#'
#' @keywords internal
get_prior_model_info <- function(prior)
{
    if(!is.gecon_prior(prior))
        stop("the prior argument has to be of gecon_prior class")
        
    return(prior@model_info)
}


#' Find the type of given parameter
#' 
#' The \code{parameter_type} function allows to recognize if
#' given parameter is a model parameter or shock standard
#' deviation / correlation. 
#'
#' @param model an object of \code{gecon_model} class for which the parameters are specified.
#'
#' @param par_names a character vector of the names of parameters.
#' 
#' @return a two element list: 
#'     \itemize{
#'        \item par_type a numeric vector of length equal to the number
#'              of estimated parameters with given value range:
#'              \itemize{
#'                  \item 0 denotes free parameter,
#'                  \item 1 denotes standard deviation of a shock,
#'                  \item 2 denotes correlation of shocks.}
#' 
#'        \item shock_names_matrix a matrix of characters containing names of
#'                                  shocks for which standard deviations and correlations
#'                                   have been specified.
#'    }
#'
#' @keywords internal
parameter_type <- function(model, parameters)
{
    par_type <- rep(0, length(parameters))
    par_type <- grepl("^sd\\(\\s*[a-zA-Z]([_a-zA-Z0-9])*[_a-zA-Z0-9]\\s*\\)$", parameters, perl = T) +
                grepl("^cor\\(\\s*[a-zA-Z]([_a-zA-Z0-9])*[_a-zA-Z0-9]\\s*,\\s*[a-zA-Z]([_a-zA-Z0-9])*[_a-zA-Z0-9]\\s*\\)$", parameters, perl = TRUE) * 2
    
    shock_par <- which(par_type > 0)
    parameters_tex <- character(length = length(parameters))
    
    
    # retrive parameter LaTeX names
    if (length(which(par_type == 0))) {
        # validate parameter names
        par_as_par <- parameters[which(par_type == 0)]
        val_par_names <- match(par_as_par, get_par_names(model))
        if (any(is.na(val_par_names)))
            stop(paste("the following parameters do not correspond to any model parameters:\n",
                       paste(par_as_par[which(is.na(val_par_names))], collapse = ", ")))
        
        par_to_tex_ind <- match(par_as_par, get_par_names(model))
        par_to_tex_char <- model@parameters_tex[par_to_tex_ind]
        parameters_tex[which(par_type == 0)] <- par_to_tex_char
    }
    
    shock_names_matrix <- matrix(data = character(), length(shock_par), 2)
    
    shock_names <- regexpr("(?<=\\()(_?[\\s,_a-zA-Z0-9])*(?=\\))", parameters[shock_par], perl = TRUE)
    shock_names <- regmatches(parameters[shock_par], shock_names)
    shock_names <- gsub("\\s", "", shock_names)
    par_type_2 <- par_type[shock_par]

    shock_names_matrix[which(par_type_2 == 1), ] <- shock_names[which(par_type_2 == 1)]
    
    name_vec <- regexpr("(?<=,)(_?[\\s,_a-zA-Z0-9])*", shock_names[which(par_type_2 == 2)], perl = TRUE)
    shock_names_matrix[which(par_type_2 == 2), 2] <- regmatches(shock_names[which(par_type_2 == 2)], name_vec)
    
    name_vec <- regexpr("(_?[\\s,_a-zA-Z0-9])*(?=,)", shock_names[which(par_type_2 == 2)], perl = TRUE)
    shock_names_matrix[which(par_type_2 == 2), 1] <- regmatches(shock_names[which(par_type_2 == 2)], name_vec)

    # create tex names of shock distribution parameters
    shock_pos <- matrix(match(shock_names_matrix, get_shock_names(model)), ncol = 2)
    shock_1_tex <- paste("sd(", model@shocks_tex[shock_pos[which(par_type_2 == 1), 1]], ")", sep = "")
    shock_2_tex <- paste("cor(", model@shocks_tex[shock_pos[which(par_type_2 == 2), 1]], ", " ,
                                 model@shocks_tex[shock_pos[which(par_type_2 == 2), 2]], 
                             ")", sep = "")
    parameters_tex[which(par_type == 1)] <- shock_1_tex
    parameters_tex[which(par_type == 2)] <- shock_2_tex    
    
    if (any(is.na(shock_pos))) {
        wrong_shocks <- unique(which(is.na(shock_pos), arr.ind=T)[1, 1])
        wr_par <- parameters[shock_par]
        stop(paste("the following shock parameters do not correspond to any model shocks:\n", 
                   paste(wr_par[wrong_shocks], collapse = ", "), ".", sep = ""))
    }
    
    
    par_pos <- match(parameters[-shock_par], get_par_names(model))
    not_shock_par <- parameters[-shock_par]
    
    if (any(is.na(par_pos))) {
        wrong_parameters <- which(is.na(par_pos))
        stop(paste("the following shock parameters do not correspond to any model parameters:\n", 
                   paste(not_shock_par[wrong_parameters], collapse=", "), ".", sep = ""))
    }
    
    return(list(par_type = par_type,
                shock_names_matrix = shock_names_matrix,
                parameters_tex = parameters_tex))
}
