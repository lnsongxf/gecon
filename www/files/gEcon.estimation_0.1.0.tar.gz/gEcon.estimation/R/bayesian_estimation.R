# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski, Paweł Romański                                    #
# ############################################################################
# Bayesian estimation of DSGE models
# ############################################################################

#' Bayesian estimation of DSGE models
#' 
#' The \code{bayesian_estimation} function performs Bayesian estimation 
#' of model parameters. It has the following properties:
#' \itemize{
#'       \item uses full-information likelihood implied by the model 
#'             approximation rather than selected statistics
#'             (e.g. discrepancy between model and VAR implied IRFs), 
#'       \item allows for incorporating additional information
#'             (e.g. from panel or microeconometric studies) 
#'             about possible model parameter distribution
#'             by formulation of the prior distribution for parameters,
#'       \item allows for comparison of different model specifications
#'             by simple probabilistic formulas. 
#' }
#' Bayesian approach to estimation is relatively simple from conceptual
#' point of view, yet numerically complex. It is based on Bayes' formula:
#' \deqn{P(\theta | Y) = \frac{P(Y|\theta)P(\theta)}{P(Y)},}
#' where \eqn{\theta} are model parameters, and \eqn{Y} is the data used for estimation. 
#' The left-hand side expression \eqn{P(\theta | Y)} 
#' is called a posterior density.  The \eqn{P(Y|\theta)} expression
#' is the likelihood function.
#' The unconditional distribution of parameters is called prior
#' distribution (\eqn{P(\theta)}) and allows for incorporation of the additional information
#' into the estimation process. 
#' Probability of data \eqn{P(Y)} is usually 
#' irrelevant for estimation so the expression for posterior
#' density can be simplified to:
#' \deqn{P(\theta | Y) \sim P(Y|\theta)P(\theta).} 
#' As there is no explicit expression for posterior density,
#' it has to be simulated numerically. The \code{gEcon.estimation}
#' package uses random walk Metropolis-Hastings algorithm to sample 
#' from posterior distribution (see Details section).
#' 
#' The \code{\link{bayesian_estimation}} function uses 
#' random walk Metropolis-Hastings procedure to draw from posterior distribution
#' (precisely, from the log-transformed posterior distribution:
#' \eqn{\log(P(\theta | Y)) \sim \log(P(Y|\theta)) + \log(P(\theta)))}.
#' In this procedure, candidate draws (\eqn{\theta^{\star}}) 
#' are sampled from multivariate normal distribution \eqn{N(\theta^{s-1}, \tilde{\Sigma})},
#' with mean dependent on previously accepted draw (\eqn{\theta^{s-1}}).
#' The chain will converge to sample from posterior distribution if 
#' the proper variance of sampling density (\eqn{\tilde{\Sigma}})
#' and good initial draw are used. \code{gEcon.estimation}
#' package finds variance of sampling density and initial points
#' by performing maximisation of the logarithm of the posterior kernel 
#' \eqn{\log P(Y|\theta) + \log P(\theta) }. The inverse of Hessian of the kernel 
#' at the mode is taken as sampling density variance, while mode of 
#' the posterior kernel (\eqn{\tilde{\theta}}) is used as initial draw
#' (in case of one Markov Chain). When many chains are used, initial draws
#' for each of chains are sampled from \eqn{N(\tilde{\theta},\tilde{\Sigma}).}
#' 
#' The following steps are performed iteratively. The candidate draw 
#' \eqn{\theta^{\star}} is taken from candidate density.
#' Then jump from \eqn{\theta^{s-1}} is accepted 
#' (\eqn{\theta^{s} = \theta^{\star}}) with probability: 
#' \deqn{\min\{1, \frac{P(\theta^{\star}|Y)P(\theta^{\star})}{P(\theta^{(s-1)}|Y)P(\theta^{(s-1)})}\}} 
#' and rejected otherwise (\eqn{\theta^{s} = \theta^{s-1}}).
#' As the result, chain of draws from the posterior distribution 
#' is obtained \eqn{\theta = (\theta^{1}, \theta^{2}, ..., \theta^{N})}.
#' Any function \eqn{g(\theta)} may be then computed using that chain
#' and treated as point estimate of parameter (usually mean or median is chosen).
#' The simulated density is stored in objects of \code{\link{gecon_estimation_results}} class.
#' 
#' This procedure may be time consuming due to two computationally complex steps.
#' The maximisation of the posterior kernel is generally difficult task due 
#' to many local optima of this function and dimension of the problem.
#' Secondly, each draw from sampling density in the Metropolis-Hastings algorithm
#' may require updating steady state and perturbation solution. 
#' 
#' The \code{bayesian_estimation} function employs one of four numerical solvers 
#' in order to maximise the posterior kernel. For more information about 
#' \code{csminwel} and \code{csminwelNew} solvers, see
#' \url{http://sims.princeton.edu/yftp/optimize/}. The simulated annealing
#' solver from the \code{GenSA} package is robust against falling into local optima but
#' its efficiency is highly dependent on parametrisation 
#' (initial temperature, visiting parameter).
#' 
#' @param data_set an object of \code{ts} or \code{mts} class containing
#'        data for the estimation of the model. 
#'        The time series supplied have to be stationary, detrended, and deseasoned.
#'        The number of series supplied cannot be greater than 
#'        the number of shocks in the model. Estimation based on data sets
#'        with missing observations is not supported in the current version.
#' 
#' @param observables a character with the length 
#'        equal to the number of \code{data_set} columns.
#'        It specifies the names of observable variables
#'        (corresponding to model variables).
#'        
#' @param model an object of \code{gecon_model} class.
#' 
#' @param prior an object of \code{gecon_prior} class;
#'              declares the prior distribution of estimated parameters.
#' 
#' @param optim_options_list a list of options for 
#'        the posterior kernel maximisation routines:
#'             \itemize{
#'                  \item \code{solver} a character; the name of solver:
#'                        \itemize{
#'                             \item \code{csminwelNew} - \code{csminwelNew} solver 
#'                                   (updated version of \code{csminwel}),
#'                             \item \code{csminwel} - \code{csminwel} solver (default), 
#'                             \item \code{Nelder-Mead} - the Nelder-Mead routine 
#'                                   implemented in the \code{optim} function,
#'                             \item \code{GenSA} - a simulated annealing 
#'                                   solver from \code{GenSA} package.
#'                        }
#'                  \item \code{solver_crit} a numeric, the convergence criterion for a solver.
#'                        The default value is 1e-7. Not used by the \code{GenSA} solver.
#'                  \item \code{solver_iter} a numeric, the maximum number of iterations for a solver.
#'                        The default value is 1000.
#'                  \item \code{init_hess_scale} a numeric, size of the diagonal elements of
#'                        initial Hessian used by \code{csminwel} and \code{csminwelNew} procedures.
#'                        Not used by \code{Nelder-Mead} and \code{GenSA} solvers. 
#'                        The default value is 1e-4.
#'                  \item \code{temperature} a numeric, the initial temperature for \code{GenSA}
#'                        solver. The default value is 5230.
#'                  \item \code{visiting.param} a numeric, a visiting parameter for \code{GenSA}
#'                        solver. The default value is 2.62.
#'                  \item \code{acceptance.param} a numeric, an acceptance parameter for \code{GenSA}
#'                        solver. The default value is -5.
#'                  \item \code{max.call} a numeric, the maximum number of function calls if \code{GenSA}
#'                        solver is used. The default value is 1e+06.
#'                  \item \code{solver_hess} a logical value. If set to TRUE, the Hessian returned from
#'                        the numerical solver is used for computation of variance of sampling distribution.
#'                        By setting this value to TRUE, one can obtain only approximate Hessian.
#'                        However, such an approximate Hessian may be more often positive definite 
#'                        (thanks to rank-one updates) than one computed explicitly.
#'                        The \code{Nelder-Mead} and \code{GenSA} solvers do not return Hessian.
#'                        The default value is FALSE.
#'                  \item \code{hessian_d} a numeric, delta used to compute Hessian numerically.
#'                        The default value is 0.001.
#'                  \item \code{hessian_eps} a numeric, tolerance of the routine computing Hessian.
#'                        The default value is 1e-7.
#'             }
#' 
#' @param mcmc_options_list a list containing options of
#'        the posterior density simulator:
#'             \itemize{
#'                  \item \code{chains} a numeric, the number of Markov chains. 
#'                        The default value is 2 (if the number of cores is not specified)
#'                        or the number of cores (if this number is specified by the user). 
#'                  \item \code{cores} a numeric, the number of processor cores
#'                        used for estimation. The default value is 2 (if the number of chains 
#'                        is not specified) or the smallest value from the number of CPU cores 
#'                        and the number of chains (if number of chains is specified).
#'                  \item \code{burn} a numeric, the number of initial draws in each chain 
#'                        which will be discarded. The default value is 200.
#'                  \item \code{chain_length} a numeric, the number of draws 
#'                        which will be left in each chain. The default value is 500.
#'                  \item \code{scale} a vector of scale parameters for candidate draws. 
#'                        It should be tailored to ensure acceptance rate between 0.25 and 0.33.
#'                        If acceptance rate is too high, this argument should rise.
#'                        In the opposite case, it should be lowered. 
#'                        The default value is a vector of ones.
#'                  \item \code{output_freq} a numeric, frequency of output. 
#'                        The Metropolis-Hastings algorithm run is divided into bundles.
#'                        After each of the bundles is processed, 
#'                        short information about the progress is printed. 
#'                        Frequent output may influence computation time significantly. 
#'                        The default output frequency is 250.
#'             }
#'        
#' @return The function returns an object of \code{gEcon_estimation_results} 
#'         class with the estimation results.
#' 
#' @examples
#' # #################################################################
#' # 1. prepare gEcon model
#' 
#' # copy the example to the current working directory
#' file.copy(from = file.path(system.file("examples", package = "gEcon.estimation"),
#'                            "dsge_model.gcn"), to = getwd())
#' dsge_model <- make_model("dsge_model.gcn")
#' 
#' # solve the model
#' dsge_model <- steady_state(dsge_model)
#' dsge_model <- solve_pert(dsge_model, loglin = TRUE)
#' 
#' # set the stochastic shocks distribution parameters
#' dsge_model <- set_shock_distr_par(dsge_model,
#'                                   distr_par = list("sd( epsilon_G )" = 0.01,
#'                                                    "sd( epsilon_Z )" = 0.01))
#' shock_info(model = dsge_model, all = TRUE)
#' 
#' # load data
#' data(example_estimation_data)
#' 
#' # ###################################################################
#' # 2. declare prior distribution
#' 
#' dsge_prior <- gecon_prior(
#'     prior_list = list(
#'         list(par = "sd(epsilon_Z)", type = "inv_gamma",
#'              mean = 0.012, sd = 0.3, lower_bound = 0.0001, 
#'              upper_bound  = 0.9, initial = 0.008),
#'         list(par = "sd(epsilon_G)", type = "inv_gamma",
#'              mean = 0.008, sd = 0.3, lower_bound = 0.0001, 
#'              upper_bound  = 0.9, initial = 0.008),
#'         list(par = "omega", type = "normal",
#'              mean = 1.45, sd = 0.1, lower_bound = 1, 
#'              upper_bound  = 2, initial = 1.5),
#'         list(par = "phi_G", type = "beta",
#'              mean = 0.88, sd = 0.03, lower_bound = 0.5, 
#'              upper_bound  = 0.999, initial = 0.92),
#'         list(par = "phi_Z", type = "beta",
#'              mean = 0.92, sd = 0.03, lower_bound = 0.5, 
#'              upper_bound  = 0.999, initial = 0.96)),
#'     model = dsge_model)
#' 
#' plot_prior(dsge_prior)
#' 
#' # ###################################################################
#' # 3. estimate the model (Bayesian estimation)
#' 
#' estimation_result <- bayesian_estimation(data_set = example_estimation_data, 
#'                                          optim_options_list = list(solver = "csminwelNew"),
#'                                          mcmc_options_list = list(chain_length = 1000, 
#'                                                                   burn = 200,
#'                                                                   cores = 2, chains = 2,
#'                                                                   scale = rep(0.5, 5)),
#'                                          observables =  c("Y", "G"),
#'                                          model = dsge_model, 
#'                                          prior = dsge_prior)
#' 
#' # retrieve estimates
#' plot_posterior(estimation_result)
#'
#' # true model parameters were:
#' # sd(epsilon_Z) 0.01
#' # sd(epsilon_G) 0.01
#' # omega         1.45
#' # phi_G         0.9
#' # phi_Z         0.9
#' est_par <- get_estimated_par(estimation_result)
#' free_par <- est_par$free_par
#' shock_distr_par <- est_par$shock_distr_par
#'
#' # update the model
#' estimated_dsge_model <- set_free_par(dsge_model, free_par = free_par)
#' estimated_dsge_model <- set_shock_distr_par(estimated_dsge_model, distr_par = shock_distr_par)
#' 
#' # solve the updated model
#' estimated_dsge_model <- steady_state(estimated_dsge_model)
#' estimated_dsge_model <- solve_pert(estimated_dsge_model, loglin = TRUE)
bayesian_estimation <- function(data_set,
                                observables,
                                model, 
                                prior, 
                                optim_options_list = NULL,
                                mcmc_options_list = NULL)
{
    # start clock
    real_start <- Sys.time()
    
    # ####################################################################
    # check inputs 
    if(!is.gecon_model(model))
        stop("the model argument has to be of gecon_model class")

    if((!is.ts(data_set) & !is.mts(data_set)))
        stop("the data_set argument has to be of (m)ts class")

    if(!is.character(observables))
        stop("the observables argument has to be a character vector")
 
    if ( class(prior) != "gecon_prior" )
        stop("the prior argument must be an object of gecon_prior class")

    # retrieve information from data and validate them with model
    val_data <- validate_data(model, data_set, observables = observables)
    obs_var_indices <- val_data$obs_var_indices
    observables <- val_data$observables
    series_start <- val_data$series_start
    series_freq <- val_data$series_freq
    data_set <- val_data$data_set
    n_obs <- val_data$n_obs
    n_var <- val_data$n_var
    
    # validate model solution
    validate_model(model)
 
    # check if options are properly set
    if ((!is.null(mcmc_options_list)) & (!is.list(mcmc_options_list)))
        stop("the mcmc_options_list argument has to be a list or a NULL value")        
    
    # ####################################################################
    # set parameters for MCMC routines
    
    # default options
    mcmc_options <- list(chains = 2, 
                         cores = 2,
                         burn = 200, 
                         chain_length = 500, 
                         scale = rep(1, length(get_estimated_par_names(prior))), 
                         output_freq = 250,
                         avoid_model_recalculation = FALSE)          
    
    # overwrite default options with user-specified options (mcmc_options_list)
    if (!is.null(mcmc_options_list)) {
        fitting_options <- which(names(mcmc_options_list) %in% names(mcmc_options))
        if (length(fitting_options) < length(mcmc_options_list)) {
            warning("unrecognised options were specified for posterior simulation")
        }
        
        # overwriting default options
        mo <- match(names(mcmc_options_list[fitting_options]), names(mcmc_options))
        mcmc_options[mo] <- mcmc_options_list[fitting_options]
        
        # set number of cores = min(number of chains, number of cores) if chains are specified
        if ("chains" %in% names(mcmc_options_list) &  !("cores" %in% names(mcmc_options_list))) {
            mcmc_options$cores <- min(mcmc_options_list$chains, detectCores())
        }

        # set number of chains equal to number of cores (if chains are not explicitly specified)
        if ("cores" %in% names(mcmc_options_list) &  !("chains" %in% names(mcmc_options_list))) {
            mcmc_options$chains <- mcmc_options_list$cores
        }
    }    

    if (length(mcmc_options$scale) != length(get_estimated_par_names(prior)))
        stop("scale parameter has to be of the same length as number of estimated parameters")
    
    chains <- mcmc_options$chains
    cores <- mcmc_options$cores
    burn <- round(mcmc_options$burn, 0)
    chain_length <- mcmc_options$chain_length
    scale <- mcmc_options$scale
    output_freq <- mcmc_options$output_freq
    avoid_model_recalculation <- mcmc_options$avoid_model_recalculation
    
    initial_trials <- 10
    est_par_names <- get_estimated_par_names(prior)                   

    # ####################################################################    
    # validation of parameters /options
    
    # scale
    if ( any( scale <= 0 ) )
        stop( "the scale parameter must be a positive" )
    if ( length(scale) != length( est_par_names ) )
        stop( "the scale parameter must be a scalar or a vector of length equal to the number of estimated parameters" )
        
    # chain length
    if ( chain_length < 1 || chain_length %% 1 != 0 )
        stop( "the chain_length parameter must be a positive integer")
        
    # output frequency
    if ( output_freq <= 0 || output_freq %% 1 != 0 )
        stop( "the output_freq parameter must be a positive integer")

    # chain
    if ( chains < 1 || chains %% 1 != 0 )
        stop("the chains parameter must be a positive integer")

    # burn    
    if (burn < 0)
        stop( "the burn parameter must be a non-negative integer")
        
    # check data names
    n_var <- ncol( data_set )
    if ( anyDuplicated( colnames( data_set ) ) )
        stop("column names in data are duplicated")
    if ( n_var > length(get_shock_names(model)) )
        stop("you can not use for estimation more observable variables than shocks in the model")

    # ####################################################################
    # find posterior kernel's mode
    cat("\nFinding the posterior kernel mode... \n")
    
    # set initial values
    opt_pars_len <- length(est_par_names)
    init_pars <- rep(0.5, opt_pars_len)
    
    init_vals <- get_initial_values(prior)
    
    if (!is.null(get_shock_cov_mat(model))) {
        sh_mat <- get_shock_cov_mat(model)
        sq_sh_mat <- sqrt(diag(sh_mat))
        sh_mat <- sh_mat / kronecker(sq_sh_mat, t(sq_sh_mat))
        cov_sd_ind <- get_estimated_par_types(prior)
        if (length(which(cov_sd_ind > 0))) {
            init_pars[which(cov_sd_ind > 0)] <- sh_mat[prior@shock_names_matrix]
        }
    }

    model_par <- get_par_values(model, silent = TRUE) 
    init_pars[-which(cov_sd_ind > 0)] <- model_par[est_par_names[-which(cov_sd_ind > 0)]]
    
    # retrieve values of parameters specified in prior 
    if (any(!is.na(init_vals)))
        init_pars[which(!is.na(init_vals))] <- init_vals[which(!is.na(init_vals))]
    names(init_pars) <- est_par_names    
    
    # set lower and upper bound values for parameters
    prior_bound <- summary(prior)
    l_bound <- prior_bound$parameters["Lower bound"][[1]]
    u_bound <- prior_bound$parameters["Upper bound"][[1]]
    
    # form kernel posterior function
    kernel_post <- function(pars, par_names = NULL, ...)
    {
            if (!is.null(par_names))
                names(pars) <- par_names   
                output_text <-  capture.output(
                      suppressWarnings(
                         model_opt_tr <- update_model(model, pars, cov_sd_ind)
                      )
                )
            if (!is.null(model_opt_tr)) {
                output_text <-  capture.output(  
                    suppressWarnings(
                        pk <- posterior(parameters = pars, 
                                        data_set = data_set, 
                                        prior = prior, model = model, 
                                        update_model = TRUE)
                    )
                )
                return(-pk$log_density)
            } else {return(Inf)}
    }

    # find parameters optimising the kernel of posterior density
    opt_fun_result <- maximise_function(fun = kernel_post, 
                                        init_pars = init_pars, 
                                        l_bound = l_bound,
                                        u_bound = u_bound,
                                        optim_options_list = optim_options_list)
    post_mode <- opt_fun_result$f_mode
    post_inv_hess <- opt_fun_result$f_inv_hess
            
    # print results of the maximisation
    cat("\n")
    cat("\nMaximisation routine solution: \n")    
    names(post_mode) <- est_par_names 
    print(post_mode)
    cat("\nCandidate for posterior mode FOUND \n")

    # check if the candidate is positive definite
    if_not_pos_def <- tryCatch(expr={dispersion <- t(chol(post_inv_hess)) ; FALSE},
                     warning = function(w) TRUE, 
                     error = function(w) TRUE)
    
    # ####################################################################
    # create new gecon_estimation_results object
    result <- gecon_estimation_results(chains, prior, 
                                       est_parameters = get_estimated_par_names(prior), model)
    
    # assign sampling distribution parameters
    if (if_not_pos_def | (any(is.nan(post_inv_hess))) | (any(is.na(post_inv_hess)))) {
        result <- set_optimisation_results(est_results = result, 
                                           opt_result = post_mode, 
                                           opt_err = sqrt(diag(post_inv_hess)), 
                                           hessian_pos_def = FALSE)
        stop("the posterior kernel optimisation problem. Inverse Hessian is not positive definite. Try with different initial values") 
    } else {
        result <- set_optimisation_results(est_results = result, 
                                           opt_result = post_mode, 
                                           opt_err = sqrt(diag(post_inv_hess)), 
                                           hessian_pos_def = TRUE)
    }

    cat("\n")    
    cat("Computing marginal density (Laplace approximation)\n")    
    model <- update_model(model, post_mode, cov_sd_ind)
    lt <- marginal_density_laplace(post_mode, post_inv_hess, data_set, model, prior)
    print(lt)
    result <- set_marg_density(est_results = result, marg_density = lt)

    # ####################################################################
    # generate initial points
    initial <- vector(length = chains, mode = "list") 
    tmp <- generate_initial(est_results = result, data_set, post_mode, dispersion, 
                            chains, initial_scale = 10,
                            initial_trials)

    # assign models and initial points
    if (chains > 1) {
        result <- set_models(result, lapply( tmp, "[[", "model"))
    } else {
        result <- set_models(result, list(tmp$model))
    }

    for (i in 1:chains) {
        if (chains > 1) {
            initial[[i]] <- tmp[[i]]$initial
        } else {
            initial <- list(tmp$initial)
        }
        names(initial[[i]]) <- get_estimated_par_names(prior)
    }

    # ####################################################################
    # initialise MCMC routine 
    
    # calculate total number of draws to generate
    total_it <- chains * (chain_length + burn)   
    burning <- TRUE
    if (burn > 0)
        cat("\nRunning burn-in phase ... \n\n")
    else {
        burning <- FALSE
        cat("\nRunning proper phase of MCMC ... \n\n")
    }
    
    # set counters
    it <- 0 # number of proper iterations already made
    bit <- 0 # number of burn-in iterations already made
    
    ss_failures <- re_failures <- 0
    start <- Sys.time()

    cluster <- makeCluster(cores)
    registerDoParallel(cluster , cores = cores)

    # close cluster when function exits
    on.exit( { stopCluster( cluster ) } )

    # ####################################################################
    # run MCMC routine 
    while( it < chain_length) { 
        
        # number of draws in each chain to run in this step
        if ( burning )
            n <- min( burn - bit, output_freq )
        else
            n <- min( chain_length - it, output_freq )
            
        tmp <- { foreach (i = 1:chains, .packages = c("gEcon", "gEcon.estimation")) %dopar% 
                    {
                    mcmc_worker(model = get_models(result)[[i]], data = data_set, prior = prior, 
                                        initial = initial[[i]], dispersion = dispersion, n = n, 
                                        scale = scale)
                    } 
                }
        
        # extension of chains
        for (i in 1:chains) {        
            result <- extend_chain(result, get_chain(result, i),
                                   tmp[[i]][["model"]], chain = i, data = tmp[[i]][["data"]], 
                                   acceptance = tmp[[i]][["accept"]])
            
            # update failure counters
            ss_failures <- ss_failures + tmp[[i]][["ss_failures"]]
            re_failures <- re_failures + tmp[[i]][["re_failures"]]
        }
        
        # update iteration counters
        if ( burning )
            bit <- bit + n
        else
            it <- it + n  
            
        est_par_names <- get_estimated_par_names(get_prior(result))
        chain_list <- get_chains(result)

        # get initial points for next run
        for ( i in 1:length(initial) ) {

            # get last draw from each chain
            initial[[i]] <- chain_list[[i]][ nrow(chain_list[[i]]), ]
            # set column names
            names(initial[[i]]) <- est_par_names
        }
        
        # show progress
        cat("Progress:  ", 
            format( (bit + it) * chains, scientific = FALSE), "/", 
            format(total_it, scientific = FALSE), 
            "( ", round( ((bit + it) * chains) / total_it * 100 , 0) , "% )\n" ,sep = "")
        cat("Time consumed:  ", time_difference( real_start ) , "\n", sep = "")
        cat("Estimated time left:  ", 
            time_difference( start, total_it / ( (bit + it) * chains ) - 1 ), "\n", sep = "")
        cat("Acceptance rate:  ", round(get_acc_rate(result) * 100, 0), "%\n", sep = "" )
        cat("Steady state failures:  ", round(ss_failures, 0), "\n", sep = "" )
        cat("Perturbation failures:  ", round(re_failures, 0), "\n", sep = "" )
        cat("\n")
        if (!burning) {
            cat("Current estimates:\n\n")
            out <- as.data.frame( matrix(NA, ncol = 2, nrow=length( est_par_names ) ) )
            colnames(out) <- c("  Mean", "  Std. dev.")
            rownames(out) <- est_par_names
            out[,1] <- paste0("  ", format(get_estimates(result)$estimates, digits = 4) )
            out[,2] <- paste0("  ", format(get_estimates(result)$stddev, digits = 4) )
            print(out, right = FALSE )
            cat("\n\n")
        }
        
        # check if the burning phase should end
        if (burning && bit == burn) {
            # change flag
            burning <- FALSE
            
            # burn initial draws
            result <- burn_initial(est_results = result, n = burn)
            cat("Burn-in phase DONE.\n\nRunning proper phase of MCMC ... \n\n")
        }
    }
    
    cat("Estimation is DONE. Total time elapsed: ",
        time_difference(real_start) , "\n", sep = " ")
    
    return(result)
}


#' Kernel of posterior density 
#' 
#' The \code{posterior} function calculates logarithm of kernel of posterior density.
#' 
#' @param parameters a named vector of parameter values.
#' 
#' @param data_set a matrix containing data. 
#'        The column names should correspond to model variables.
#'        
#' @param prior an object of \code{gecon_prior} class containing information about
#'              prior distribution of parameters.
#'        
#' @param model an object of \code{gecon_model} class.
#' 
#' @param update_model a logical value. If TRUE, the model parameters
#'                     should be updated.
#' 
#' @return This function returns logarithm of kernel of posterior density.
#'
#' @keywords internal
posterior <- function (parameters, data_set, prior, model, update_model = TRUE) 
{
    # create return list 
    post <- list( log_density = -Inf,
                  model = model,
                  ss_failures = 0,
                  re_failures = 0 )
    
    if ( update_model ) {
        # update model parameters and shocks   
        tmp_model <- update_model(post$model, parameters, get_estimated_par_types(prior))
        
        # the model has not been updated
        if ( is.null( tmp_model ) ) {         
            return( post )   
        }
        
        # the model has been successfully updated
        post$model <- tmp_model
    }
  
    # get prior density
    x <- prior_density(prior, parameters)
    
    if (x == -Inf) {
        return(post)
    } else {
        # sum log-likelihood and logarithm of prior density
        llh <- likelihood(data_set, model = post$model, value_on_failure = -Inf )
        post$log_density <- llh$log_likelihood + x
        post$model <- llh$model
        post$ss_failures <- llh$ss_failures
        post$re_failures <- llh$re_failures
        return ( post )
    }
}

#' Iterative part of MCMC routine
#' 
#' The \code{mcmc_worker} function draws candidate values
#' from the candidate distribution and accepts/rejects them 
#' as the next value in the MCMC chain.
#' 
#' @param model an object of \code{gecon_model} class.
#' 
#' @param data a numeric matrix of data.
#' 
#' @param prior an object of \code{gecon_prior} class 
#'              containing information about prior 
#'              distribution of the parameters.
#'        
#' @param initial a vector of initial values for parameters.
#' 
#' @param dispersion a numeric matrix indicating variance-covariance matrix
#'                   for drawing from proposal distribution 
#'                   (dispersion around posterior kernel mode).
#' 
#' @param n a numeric indicating number of draws to be taken.
#' 
#' @param scale a numeric indicating a scale parameter for MCMC.
#' 
#' @return The function returns a list containing generated draws, 
#'         \code{gecon_model} solved for the last draw,
#'         computation time, acceptance rate, number of failures in calculation of
#'         steady state and perturbation.
#' 
#' @keywords internal
mcmc_worker <- function(model, data, prior, 
                        initial, dispersion, n, scale) 
{    
    # set counters
    ss_failures = 0
    re_failures = 0
    
    # get the initial value of posterior
    current_post <- posterior(initial, data, prior, model, FALSE)
    current_draw <- initial
    
    # initialise matrix of draws
    draws <- matrix(NA, nrow = n, ncol = length( get_estimated_par_names(prior) ) )
    
    # set acceptance counter
    accept <- 0   
    if (length(scale) == 1) {
        dispersion <- scale * dispersion    
    } else {
        dispersion <- diag(scale) * dispersion
    }
    accept_reject_prob <- runif(n, 0, 1)
    for ( i in 1:n ) {
        # generate new point
        candidate <- mrnorm(1, current_draw, dispersion)
        names(candidate) <- get_estimated_par_names(prior) 

        # get posterior density for new point
        cand_post <- posterior(candidate, data, prior, current_post$model)

        # check acceptance condition
        rnd <- log ( accept_reject_prob[i] )
        if ( cand_post$log_density - current_post$log_density >= rnd ) { 
            # if accepted save new point
            current_post <- cand_post
            current_draw <- candidate
            accept <- accept + 1
        }
        # save draw
        draws[i, ] <- current_draw
        
        # update counters
        ss_failures <- ss_failures + cand_post$ss_failures
        re_failures <- re_failures + cand_post$re_failures
    }
    
    # return results    
    return ( list(data = draws, 
                  model = current_post$model,
                  accept = accept / n,
                  ss_failures = ss_failures,
                  re_failures = re_failures))
}

#' Initial draw for MCMC routine
#' 
#' The \code{generate_intial} function generates initial draws
#' for MCMC routine.
#' 
#' @param est_results an object of \code{gecon_estimation_results} class.
#' 
#' @param data_set a numeric matrix of data.
#'
#' @param post_mode a numeric vector of posterior kernel maximisation results
#'                  (mean of distribution from which the initial draws will
#'                   be drawn).
#' 
#' @param post_inv_hess a numeric matrix indicating variance-covariance matrix
#'                      for drawing initial values (dispersion around initial draw mean).
#'
#' @param chain_nr a numeric indicating number of chains for which
#'                 the initial values are to be generated.
#' 
#' @param initial_scale a numeric parameter for scaling sample.
#' 
#' @param initial_trials a numeric indicating maximum number of 
#'                       trials to generate initial draw (default = 40).
#' 
#' @return The function returns a list with sublists containing initial values and
#'         initialised object of \code{gecon_model} class.
#' 
#' @keywords internal
generate_initial <- function(est_results, data_set, post_mode, 
                             post_inv_hess, chain_nr, 
                             initial_scale, initial_trials = 40) 
{
    it <- 0
    prior <- get_prior(est_results)
    models <- get_models(est_results)
    
    # set initial value from posterior mode
    if (chain_nr == 1) {

        initial <- post_mode
        names( initial ) <- get_estimated_par_names(prior)
        tmp_model <- update_model( models[[1]], initial, get_estimated_par_types(prior) )
        res <- list( model = tmp_model, initial = initial )

    # sample initial value from posterior kernel distribution
    } else {
        res <- vector(length = chain_nr, mode = "list") 
        for (i in 1:chain_nr) {
            ok <- FALSE
            while( !ok && it < initial_trials ) {
                # generate initial parameters
                initial <- mrnorm(1, post_mode, post_inv_hess)
                names( initial ) <- get_estimated_par_names(prior)
                tmp_model <- update_model( models[[i]], initial, get_estimated_par_types(prior))
                
                # if tmp_model == NULL - variance-covariance matrix is not positive definite
                if ( !is.null( tmp_model ) ) {
                    model <- tmp_model
                    posterior <- posterior(parameters = initial, data_set = data_set, prior, models[[i]], TRUE)                    
                    if ( posterior$log_density > -Inf ) 
                        ok <- TRUE
                    res[[i]]$model <- posterior$model
                    res[[i]]$initial <- initial
               } 
                it <- it + 1
            }
            if ( !ok ) {
                stop(paste("model has not been solved for ", initial_trials ," draws of initial parameters. ",
                     "Consider lower initial scale or specifying different prior distribution. ",
                     "Executing code again or increasing initial_trials parameter may also solve the problem."))
            }
        }
    }
    
    return(res)
}


#' Draw from multivariate normal distribution
#' 
#' The \code{mrnorm} function generates random draws from
#' the multivariate normal distribution. The function uses 
#' as argument Cholesky decomposition of variance/covariance matrix 
#' rather than the matrix itself to avoid calling this decomposition 
#' in each step of Metropolis-Hastings algorithm.
#' 
#' @param n a numeric indicating number of random variables 
#'          that are to be generated. 
#' 
#' @param mean a vector specifying mean of the 
#'             multivariate normal distribution. 
#' 
#' @param t_ch a (lower triangular) matrix with the (transpose) Cholesky 
#'              decomposition of the distribution variance-covariance matrix 
#'              (lower triangular matrix). 
#' 
#' @return The function returns a matrix of random variables
#'         drawn from the specified distribution. 
#'
#' @keywords internal
mrnorm <- function(n, mean, t_ch)
{
    ndim <- dim(t_ch)[2]
    if (n == 1) {
        return(as.vector(mean + t_ch %*% rnorm(ndim)))
    } else {
        shocks <- matrix(rnorm(ndim * n), ndim, n)
        output <- matrix(rep(mean, ndim * n), ndim, n)
        for (i in 1:n) {
            output[ ,i] <- output[ ,i] + t_ch %*% shocks[, i]
        }
        return(output)
    }
}
