# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski                                                    #
# ############################################################################
# The set of functions computing coordinates for plotting 
# theoretical distributions.
# ############################################################################

#' Find coordinates for plotting beta distribution density
#' 
#' The \code{plot_beta} function finds coordinates for plotting
#' beta distribution.
#'
#' @param a a numeric, a parameter of beta distribution.
#' 
#' @param b a numeric, b parameter of beta distribution.
#' 
#' @param L a numeric, L lower bound of beta distribution.
#' 
#' @param U a numeric, U upper bound of beta distribution.
#' 
#' @param dpoint a numeric, value of distribution function for
#'        which the tails are truncated.
#' 
#' @param length.out a numeric, number of gridpoints used
#'                   for plotting distribution.
#'
#' @return a list with XY coordinates for plotting beta distribution.
#'
#' @keywords internal
plot_beta <- function (a, b, L, U, dpoint = 1e-4, length.out = 200)
{
    loc <- L
    scal <- (U - L)   
    low <- loc + scal * qbeta(p= dpoint, a, b)
    high <- loc + scal * qbeta(p= 1 - dpoint, a, b)
    coord <- seq(from = low, to = high, length.out = length.out)
    y = dbeta(x = (coord - loc) / scal, shape1 = a, shape2 = b) / scal
    out_bounds <- which(coord < L | coord > U) 
    y[out_bounds] <- 0
    return(list(x = coord, 
                y = y))
}

#' Find coordinates for plotting gamma distribution density
#'  
#' The \code{plot_ggamma} function finds coordinates for plotting
#' gamma distribution.
#'
#' @param a a numeric, a parameter of gamma distribution.
#' 
#' @param b a numeric, b parameter of gamma distribution.
#' 
#' @param L a numeric, L lower bound of gamma distribution.
#' 
#' @param U a numeric, U upper bound of gamma distribution.
#' 
#' @param dpoint a numeric, value of distribution function for
#'        which the tails are truncated.
#' 
#' @param length.out a numeric, number of gridpoints used
#'                   for plotting distribution.
#'
#' @return a list with XY coordinates for plotting gamma distribution.
#'
#' @keywords internal
plot_ggamma <- function (a, b, L, U, dpoint = 1e-4, length.out = 200)
{
    low <- qgamma(dpoint, shape = a,  rate = 1 /  b) + L
    high <- qgamma(1 - dpoint, shape = a,  rate = 1 /  b) + L
    coord <- seq(from = low, to = high, length.out = length.out)
    y <- dgamma(x= coord - L, shape = a, rate = 1 / b)
    out_bounds <- which(coord < L | coord > U) 
    y[out_bounds] <- 0
    return(list(x = coord, 
                y = y))
}

#' Find coordinates for plotting uniform distribution density
#' 
#' The \code{plot_uniform} function finds coordinates for plotting
#' uniform distribution.
#'
#' @param L a numeric, L parameter of uniform distribution.
#' 
#' @param U a numeric, U parameter of uniform distribution.
#' 
#' @param dpoint a numeric, value of distribution function for
#'        which the tails are truncated.
#' 
#' @param length.out a numeric, number of gridpoints used
#'                   for plotting distribution.
#'
#' @return a list with XY coordinates for plotting uniform distribution.
#'
#' @keywords internal
plot_uniform <- function (L, U, dpoint = 1e-3, length.out = 200)
{
    L <- L
    high <- U
    coord <- seq(from = L, to = high, length.out = length.out)
    y = rep(1 / (U - L), length.out)
    out_bounds <- which(coord < L | coord > U) 
    y[out_bounds] <- 0
    return(list(x = coord, 
                y = y))
}

#' Find coordinates for plotting normal distribution density
#' 
#' The \code{plot_norm} function finds coordinates for plotting
#' normal distribution.
#' 
#' @param a a numeric, a parameter of normal distribution.
#' 
#' @param b a numeric, b parameter of normal distribution.
#'  
#' @param L a numeric, L lower bound of normal distribution.
#' 
#' @param U a numeric, U upper bound of normal distribution.
#'
#' @param dpoint a numeric, value of distribution function for
#'        which the tails are truncated.
#' 
#' @param length.out a numeric, number of gridpoints used
#'                   for plotting distribution.
#'
#' @return a list with XY coordinates for plotting normal distribution.
#'
#' @keywords internal
plot_norm <- function (a, b, L, U, dpoint = 1e-4, length.out = 200)
{
    low <- qnorm(p= dpoint, mean = a, sd = b)
    high <- qnorm(p= 1 - dpoint, mean = a, sd = b)
    coord <- seq(from = low, to = high, length.out = length.out)
    y <- dnorm(x = coord, mean = a, sd = b)
    out_bounds <- which(coord < L | coord > U) 
    y[out_bounds] <- 0
    return(list(x = coord, 
                y = y))
}

#' Find coordinates for plotting inverted gamma (I type) distribution density
#' 
#' The \code{plot_inv_gamma} function finds coordinates for plotting
#' inverted gamma distribution.
#' 
#' @param a a numeric, a parameter of inverted gamma  distribution.
#' 
#' @param b a numeric, b parameter of inverted gamma distribution.
#'   
#' @param L a numeric, L lower bound of inverted gamma distribution.
#' 
#' @param U a numeric, U upper bound of inverted gamma distribution.
#'
#' @param dpoint a numeric, value of distribution function for
#'        which the tails are truncated.
#' 
#' @param length.out a numeric, number of gridpoints used
#'                   for plotting distribution.
#'
#' @return a list with XY coordinates for plotting inverted gamma distribution.
#'
#' @keywords internal
plot_inv_gamma <- function (a, b, L, U, dpoint = 1e-4, length.out = 200)
{
    low <- qinvgamma(p = 1- 10 * dpoint, a = a, b = b) + L
    high <- qinvgamma(p = 10 * dpoint, a = a, b = b) + L
    coord <- seq(from = low, to = high, length.out = length.out)
    y <- pinvgamma(x = coord - L, a = a, b = b)
    out_bounds <- which(coord < L | coord > U) 
    y[out_bounds] <- 0
    return(list(x = coord, 
                y = y))
}

#' Find coordinates for plotting inverted gamma (II type) distribution density
#' 
#' The \code{plot_inv_gamma} function finds coordinates for plotting
#' inverted gamma distribution (II type).
#' 
#' @param a a numeric, a parameter of inverted gamma  distribution (II type).
#' 
#' @param b a numeric, b parameter of inverted gamma distribution (II type).
#'   
#' @param L a numeric, L lower bound of inverted gamma distribution (II type).
#' 
#' @param U a numeric, U upper bound of inverted gamma distribution (II type).
#'
#' @param dpoint a numeric, value of distribution function for
#'        which the tails are truncated.
#' 
#' @param length.out a numeric, number of gridpoints used
#'                   for plotting distribution.
#'
#' @return a list with XY coordinates for plotting inverted gamma distribution.
#'
#' @keywords internal
plot_inv_gamma_2 <- function (a, b, L, U, dpoint = 1e-4, length.out = 200)
{
    low <- qinvgamma_2(p = 1 - 10 * dpoint, a = a, b = b) + L
    high <- qinvgamma_2(p = 10 * dpoint, a = a, b = b) + L
    coord <- seq(from = low, to = high, length.out = length.out)
    y <- pinvgamma_2(x = coord - L, a = a, b = b)
    out_bounds <- which(coord < L | coord > U) 
    y[out_bounds] <- 0
    return(list(x = coord, 
                y = y))
}
