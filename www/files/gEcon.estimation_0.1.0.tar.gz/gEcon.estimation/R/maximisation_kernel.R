# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski, Paweł Romański                                    #
# ############################################################################
# Posterior kernel / likelihood function optimisation
# ############################################################################

#' Posterior kernel / likelihood function optimisation
#'
#' The \code{maximise_function} finds optimum value and inverse Hessian
#' at optimum value for posterior kernel / likelihood function.
#' 
#' @param fun a function; a posterior kernel or likelihood function.
#'
#' @param init_pars a numeric of initial values of parameters.
#'
#' @param l_bound a numeric of parameter range lower bounds.
#'
#' @param u_bound a numeric of parameter range upper bounds.
#'
#' @param optim_options_list a list of options for 
#'        the likelihood / posterior kernel maximisation routines:
#'             \itemize{
#'                  \item \code{solver} a character; the name of solver:
#'                        \itemize{
#'                             \item \code{csminwelNew} - \code{csminwelNew} solver 
#'                                   (updated version of \code{csminwel}),
#'                             \item \code{csminwel} - \code{csminwel} solver (default), 
#'                             \item \code{Nelder-Mead} - the Nelder-Mead routine 
#'                                   implemented in the \code{optim} function,
#'                             \item \code{GenSA} - simulated annealing 
#'                                   solver from \code{GenSA} package.
#'                        }
#'                  \item \code{solver_crit} a numeric, the convergence criterion for a solver.
#'                        The default value is 1e-7. Not used by the \code{GenSA} solver.
#'                  \item \code{solver_iter} a numeric, the maximum number of iterations for a solver.
#'                        The default value is 1000.
#'                  \item \code{init_hess_scale} a numeric, size of the diagonal elements of
#'                        initial Hessian used by \code{csminwel} and \code{csminwelNew} procedures.
#'                        Not used by \code{Nelder-Mead} and \code{GenSA} solvers. 
#'                        The default value is 1e-4.
#'                  \item \code{temperature} a numeric, the initial temperature for \code{GenSA}
#'                        solver. The default value is 5230.
#'                  \item \code{visiting.param} a numeric, a visiting parameter for \code{GenSA}
#'                        solver. The default value is 2.62.
#'                  \item \code{acceptance.param} a numeric, an acceptance parameter for \code{GenSA}
#'                        solver. The default value is -5.
#'                  \item \code{max.call} a numeric, the maximum number of function calls if \code{GenSA}
#'                        solver is used. The default value is 1e+06.
#'                  \item \code{solver_hess} a logical value. If set to TRUE, the Hessian returned from
#'                        the numerical solver is used for computation of variance of sampling distribution.
#'                        By setting this value to TRUE, one can obtain only approximate Hessian.
#'                        However, such an approximate Hessian may be more often positive definite 
#'                        (thanks to rank-one updates) than one computed explicitly.
#'                        The \code{Nelder-Mead} and \code{GenSA} solvers do not return Hessian.
#'                        The default value is FALSE.
#'                  \item \code{hessian_d} a numeric, delta used to compute Hessian numerically.
#'                        The default value is 0.001.
#'                  \item \code{hessian_eps} a numeric, tolerance of the routine computing Hessian.
#'                        The default value is 1e-7.
#'             }
#'
#' @keywords internal
maximise_function <- function(fun, init_pars, l_bound, u_bound, 
                              optim_options_list)
{
    if ((!is.null(optim_options_list)) & (!is.list(optim_options_list)))
        stop("the optim_options_list argument has to be a list or a NULL value")
        
    def_optim_options = list(solver = "csminwel",
                             solver_crit = 1e-7,
                             solver_hess = FALSE,
                             solver_iter = 1000,
                             init_hess_scale = 1e-4, 
                             hessian_d = 0.001,
                             hessian_eps = 1e-7,
                             temperature = 5230,
                             nb.stop.improvement = 500,
                             max.call = 1e+06, 
                             visiting.param = 2.62,
                             acceptance.param = -5)

    # check if the user specified options are correct
    if (!is.null(optim_options_list)) {
        fitting_options <- which(names(optim_options_list) %in% names(def_optim_options))
        if (length(fitting_options) < length(optim_options_list)) {
            warning("unrecognised options were specified for posterior mode computation")
        }
        
        # overwrite default options
        mo <- match(names(optim_options_list[fitting_options]), names(def_optim_options))
        def_optim_options[mo] <- optim_options_list[fitting_options]
    }

    # retrieve default options
    init_hess_scale <- def_optim_options$init_hess_scale
    solver <- def_optim_options$solver
    solver_hess <- def_optim_options$solver_hess
    solver_crit <- def_optim_options$solver_crit
    solver_iter <- def_optim_options$solver_iter
    hessian_d <- def_optim_options$hessian_d
    hessian_eps <- def_optim_options$hessian_eps   
    temperature <- def_optim_options$temperature
    visiting.param <- def_optim_options$visiting.param
    acceptance.param <- def_optim_options$acceptance.param
    nb.stop.improvement <- def_optim_options$nb.stop.improvement
    max.call <- def_optim_options$max.call

    available_solvers <- c("csminwelNew", "csminwel", "Nelder-Mead", "GenSA")
    solver_ind <- match(solver, available_solvers)
    
    if (is.na(solver_ind)) {
        stop("the optimization solver's name has been misspecified or the solver is unavailable")
    }
    cat("\nInitial values of the parameters:\n")
    print(init_pars)

    if (solver_ind == 1) {
        mode_comp <- csminwelNew(fun, 
                                 init_pars, 
                                 H0 = diag(length(init_pars)) * init_hess_scale, 
                                 nit = solver_iter, crit = solver_crit)
        f_mode <- mode_comp$xh
        if (solver_hess) {
            cat("\nThe solver has stopped searching for the solution.\n\n")
            cat("\nComputes inverse Hessian of the posterior kernel at the mode: ")
            f_inv_hess <- mode_comp$H
        } else {
            cat("\nThe solver has stopped searching for the solution.\n\n")
            cat("\nComputes inverse Hessian of the posterior kernel at the mode: ")
            output_text <-  capture.output(suppressWarnings(
                hess <- hessian(fun, f_mode, method="Richardson", 
                                method.args = list(eps= hessian_eps, d = hessian_d))
            ))
            f_inv_hess <- solve(hess)
        }
    } else if (solver_ind == 2) { 
        mode_comp <- csminwel(fun, init_pars, H0 = diag(length(init_pars)) * init_hess_scale, 
                            nit = solver_iter, crit = solver_crit)
        f_mode <- mode_comp$xh
        if (solver_hess) {
             cat("\nThe solver has stopped searching for the solution.\n\n")
             cat("\nComputes inverse Hessian of the posterior kernel at the mode: ")
            f_inv_hess <- mode_comp$H
        } else {
            cat("\nThe solver has stopped searching for the solution.\n\n")
            cat("\nComputes inverse Hessian of the posterior kernel at the mode: ")
            output_text <-  capture.output(suppressWarnings(
                hess <- hessian(fun, f_mode, method="Richardson", 
                            method.args = list(eps= hessian_eps, d = hessian_d))
            ))
            f_inv_hess <- solve(hess)
        }
    } else if (solver_ind == 3) {
        hes_comp <- FALSE
        if (solver_hess) {
            hes_comp <- TRUE
        }
        mode_comp <- optim(par = init_pars, fn = fun, 
                           method = c("Nelder-Mead"), 
                           control = list(trace = TRUE, reltol = solver_crit, 
                                          maxit = solver_iter), 
                           hessian = hes_comp)
        f_mode <- mode_comp$par        
        if (solver_hess) {
            cat("\nThe solver has stopped searching for the solution.\n\n")
            cat("\nComputes inverse Hessian of the posterior kernel at the mode: ")
            hess <- mode_comp$hessian
            f_inv_hess <- solve(hess)
        } else {
            cat("\nThe solver has stopped searching for the solution.\n\n")
            cat("\nComputes inverse Hessian of the posterior kernel at the mode: ")
            output_text <-  capture.output(suppressWarnings(
                hess <- hessian(fun, f_mode, method="Richardson", 
                            method.args = list(eps= hessian_eps, d = hessian_d))
            ))
            f_inv_hess <- solve(hess)        
        }
    } else if (solver_ind == 4) {
        if (requireNamespace("GenSA", quietly = TRUE)) {
            mode_comp <- GenSA::GenSA(par = init_pars, fn = fun, 
                                  lower = l_bound, upper = u_bound, 
                                  control = list(verbose = TRUE,
                                  temperature = temperature, 
                                  nb.stop.improvement = nb.stop.improvement,
                                  maxit = solver_iter,
                                  max.call = max.call,
                                  visiting.param = visiting.param, 
                                  acceptance.param = acceptance.param),
                                  par_names = names(init_pars)
                          ) 
            f_mode <- mode_comp$par
            names(f_mode) <- names(init_pars)
            cat("\nThe solver has stopped searching for the solution.\n\n")
            cat("\nComputes inverse Hessian of the posterior kernel at the mode: ")
            output_text <-  capture.output(suppressWarnings(
                hess <- hessian(fun, f_mode, method = "Richardson", 
                                method.args = list(eps = hessian_eps, d = hessian_d))
            ))
            f_inv_hess <- solve(hess)
        } else {
            stop ("the installation of GenSA package is required before using simulated annealing solver")
        }
    } else {
        stop("the optimization solver's name has been misspecified or the solver is unavailable")
    }
    
    cat("DONE.\n")
    return(list(f_mode = f_mode,
                f_inv_hess = f_inv_hess))
}
