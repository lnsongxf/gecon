# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski                                                    #
# ############################################################################
# The set of functions computing distribution parameters
# given values of their moments
# ############################################################################

#' Find a and b parameters of beta distribution given mean and standard
#' deviation.
#'
#' The \code{beta_params} function finds parameters of beta distribution
#' given its moments.
#' 
#' @param mean_b a numeric, mean of beta distribution.
#' 
#' @param std_b a numeric, standard deviation of beta distribution.
#' 
#' @param start_b a numeric, L parameter of beta distribution.
#' 
#' @param end_b a numeric, U parameter of beta distribution.
#' 
#' @return a list with a and b parameters of beta distribution.
#'
#' @keywords internal
beta_params <- function(mean_b, std_b, start_b = 0, end_b = 1)
{
    mu <- (mean_b - start_b) / (end_b - start_b)
    std <- std_b / (end_b - start_b)
    
    alpha <- (1 - mu) * mu ^ 2 / std ^ 2 - mu
    beta <- alpha * (1 /  mu - 1)
    return(list(alpha = alpha,
                beta = beta))
}

#' Find a and b parameters of gamma distribution given mean and standard
#' deviation.
#' 
#' The \code{gamma_params} function finds parameters of beta distribution
#' given its moments.
#'
#' @param mean_g a numeric, mean of gamma distribution.
#' 
#' @param std_g a numeric, standard deviation of gamma distribution.
#' 
#' @param start_g a numeric, L parameter of gamma distribution.
#' 
#' @return a list with a and b parameters of gamma distribution.
#'
#' @keywords internal
gamma_params <- function(mean_g, std_g, start_g = 0)
{
    lambda <- std_g ^ 2 / (mean_g - start_g)
    alpha <- (mean_g - start_g) / lambda
    return(list(alpha = alpha,
                lambda = lambda))
}

#' Find a and b parameters of uniform distribution given mean and standard
#' deviation.
#' 
#' The \code{uniform_params} function finds parameters of uniform distribution
#' given its moments.
#' 
#' @param mean_u a numeric, mean of uniform distribution.
#' 
#' @param std_u a numeric, standard deviation of uniform distribution.
#' 
#' @return a list with a and b parameters of uniform distribution.
#'
#' @keywords internal
uniform_params <- function(mean_u, std_u)
{
    a <- mean_u - std_u * sqrt(12) / 2
    b <- mean_u + std_u * sqrt(12) / 2
    
    return(list(a = a,
                b = b))
}

#' Find a and b parameters of normal distribution given mean and standard
#' deviation.
#'  
#' The \code{normal_params} function finds parameters of normal distribution
#' given its moments.
#'
#' @param mean_n a numeric, mean of normal distribution.
#' 
#' @param std_n a numeric, standard deviation of normal distribution.
#' 
#' @return a list with a and b parameters of normal distribution.
#'
#' @keywords internal
normal_params <- function(mean_n, std_n)
{
    a <- mean_n
    b <- std_n
    
    return(list(a = a,
                b = b))
}

#' Find a and b parameters of inverted gamma distribution given mean and standard
#' deviation.
#'  
#' The \code{inverted_gamma_1_parameters} function finds parameters of 
#' inverted distribution (I type) given its moments.
#' 
#' @param mean_i a numeric, mean of inverted gamma distribution.
#' 
#' @param sd_i a numeric, standard deviation of inverted gamma distribution.
#' 
#' @return a list with a and b parameters of inverted gamma distribution.
#'
#' @keywords internal
inverted_gamma_1_parameters <- function(mean_i, sd_i)
{
    mean_i_2 <- mean_i ^ 2
    sd_i_2 <- sd_i ^ 2
    
    if (sd_i_2 < Inf) {
        dd <- (mean_i ^ 2 / sd_i ^ 2)
        dd2 <- 2 * (2 + dd)
        a <- sqrt(dd2)
        a_2 <- 2 * a
        a_1 <- 2
        err <- ig1fun(a, mean_i_2, sd_i_2)
        err_2 <- ig1fun(a_2, mean_i_2, sd_i_2)
        if (err_2 > 0) {
            while (a_2 < 1e12) {
                a_1 <- a_2
                a_2 <- a_2 * 2
                err_2 <- ig1fun(a_2, mean_i_2, sd_i_2)
                if (err_2 < 0)
                    break
            }
            if (err_2 > 0)
                stop("wrong specification of distribution")
        }
        while (abs(a_2 / a_1 - 1) > 1e-14) {
            if (err > 0) {
                a_1 <- a
                if (a < a_2)
                    a <- a_2
                else {
                    a <- 2 * a
                    a_2 <- a
                }
            } else {
                a_2 <- a
            }
            a <- (a_1 + a_2) / 2
            err <- ig1fun(a, mean_i_2, sd_i_2)
        }
        b <- (sd_i_2 + mean_i_2) * (a - 2)
    } else {
        a <- 2
        b <- 2 * mean_i_2 / pi
    }
    return(list(a = a,
                b = b))
}

#' Find a and b parameters of inverted gamma (II type) distribution given mean and standard
#' deviation.
#'  
#' The \code{inverted_gamma_2_parameters} function finds parameters of 
#' inverted distribution (II type) given its moments.
#' 
#' @param mean_i a numeric, mean of inverted gamma (II type) distribution.
#' 
#' @param sd_i a numeric, standard deviation of inverted gamma (II type) distribution.
#' 
#' @return a list with a and b parameters of inverted gamma (II type) distribution.
#'
#' @keywords internal
inverted_gamma_2_parameters <- function(mean_i, sd_i)
{
    mean_i_2 <- mean_i ^ 2
    sd_i_2 <- sd_i ^ 2

    return(list(a = 2 * (2 + mean_i_2 / sd_i_2),
                b  = 2 * mean_i * (1 + mean_i_2 / sd_i_2)))
}

#' Auxilliary function for computation of inverse gamma distribution
#' parameters.
#'
#' The \code{ig1fun} returns a numeric of difference between moments
#' implied by distribution parameters and moments supplied the user.
#'
#' @param nu a numeric, inverse gamma distribution parameter.
#'
#' @param mu2 a numeric, inverse gamma distribution parameter.
#'
#' @param sigma2 a numeric, inverse gamma distribution parameter.
#' 
#' @return The function returns a numeric of difference between moments
#'         implied by distribution parameters and moments supplied
#'         the user.
#'
#' @keywords internal
ig1fun <- function(nu, mu2, sigma2)
{
    res <- log(2 * mu2) - log( (sigma2 + mu2) * (nu - 2)) + 
           2 * ( lgamma(nu / 2) - lgamma((nu - 1)/2))
    return(res)
}
