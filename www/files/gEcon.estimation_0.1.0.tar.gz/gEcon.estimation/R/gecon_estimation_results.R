# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski, Paweł Romański                                    #
# ############################################################################
# Class for storing the results of estimation
# ############################################################################

#' DSGE model estimation results
#' 
#' The \code{gecon_estimation_results} class stores
#' the results of estimation. 
#' 
#' @slot chains a list of matrices. Each matrix represents Markov 
#'              chain drawn from posterior distribution. 
#'       
#' @slot acceptance_rate a numeric value indicating 
#'                       acceptance rate for Metropolis-Hastings procedure.
#'       
#' @slot prior an object of \code{gecon_prior} class. This object
#'             declares prior distribution for the estimated parameters.
#' 
#' @slot models a list of objects of \code{gecon_model} class. 
#'              Each of the list elements contains model solved during
#'              the last iteration of the random walk
#'              Metropolis-Hastings algorithm.
#' 
#' @slot est_parameters a character vector of estimated 
#'                     parameter names.
#'
#' @slot total_n a numeric, the total number of draws
#'               from posterior distribution.
#' 
#' @slot opt_result a numeric vector of parameter values returned from
#'                  the maximisation routine.
#'        
#' @slot opt_err a numeric vector of std. errors for parameter estimates
#'                 returned from the maximisation routine.
#' 
#' @slot hessian_pos_def a logical. If TRUE, the Hessian of optimised
#'                       function computed at its maximum
#'                       was positive definite.
#' 
#' @slot marg_density a numeric, the Laplace approximation to
#'                    the marginal density of posterior.
#'
#' @slot estimates a numeric vector of posterior means.
#'                 Relevant for Bayesian estimation only.
#' 
#' @slot square_estimates a numeric vector of expected 
#'                        squared values for each parameter
#'                        (computed based on posterior sample).
#'                        Relevant for Bayesian estimation only.
#'                         
#' @slot stddev a numeric vector of standard deviations
#'              for each estimated parameter.
#' 
#' @slot naive_se a numeric vector of naive standard errors 
#'                for each estimated parameter.
#' 
#' @slot method a character indicating the method of estimation. 
#'               Equals to either "Bayes" for Bayesian 
#'               estimation or "ML" for maximum likelihood 
#'               estimation.
#'                                                     
#' @section Methods:
#'          \subsection{show}{
#'              Prints name of estimation method performed and estimation statistics.}
#'          \subsection{print}{
#'              Prints name of estimation method, estimation statistics,
#'              and the names of estimated parameters.}
#'          \subsection{summary}{
#'              Prints a summary of an object of \code{gecon_estimation_results}
#'              class consisting of name of estimation method, 
#'              estimation statistics, and estimates of model parameters.}
setClass("gecon_estimation_results",
          slots = c(chains = "list",
                    acceptance_rate = "numeric",
                    prior = "gecon_prior",
                    models = "list",
                    est_parameters = "character",
                    total_n = "numeric", 
                    opt_result = "numeric",
                    opt_err = "numeric",
                    hessian_pos_def = "logical", 
                    marg_density = "numeric",
                    estimates = "numeric",
                    square_estimates = "numeric",
                    stddev = "numeric", 
                    naive_se = "numeric",
                    method = "character"),
          prototype = list( chains = list(),
                            total_n = 0,
                            estimates = numeric(),
                            square_estimates = 0,
                            hessian_pos_def = FALSE,
                            stddev = 0,
                            naive_se = 0,
                            acceptance_rate = 0 ) )

                            
#' Constructor for objects of \code{gecon_estimation_results} class
#' 
#' The constructor for objects of \code{gecon_estimation_results}
#' class. The objects of this class store results of estimation.
#' 
#' @param chains a numeric specifying the number of 
#'               Markov chains which will be created.
#' 
#' @param prior an object of \code{gecon_prior} class
#'              specifying prior distribution of parameters.
#'        
#' @param models an object of \code{gecon_model} class 
#'               or list of \code{chains} objects of 
#'               \code{gecon_model} class.
#' 
#' @param est_parameters a character vector of parameter names.
#'
#' @param method a character indicating the method of estimation. 
#'               Two values are possible: "Bayes" for Bayesian 
#'               estimation and "ML" for maximum likelihood 
#'               estimation.
#' 
#' @return an object of \code{gecon_estimation_results} class.
#'
#' @keywords internal
gecon_estimation_results  <- function(chains = NULL, prior = NULL, 
                                      models, est_parameters, method = "Bayes") 
{
    object <- new("gecon_estimation_results")       
              
    if (method == "Bayes") {
        object@est_parameters <- est_parameters
        object@estimates <- rep(0, length(get_estimated_par_names(prior) ))
        object@chains <- as.list( rep(NA, chains) )

        # save prior and gecon models
        object@prior <- prior
        for (i in 1:chains) {
            if ( length(models) == 1 )
                object@models[[i]] <- models
            else
                object@models[[i]] <- models[[i]]
        }  
        object@method <- "Bayes"       
    } else if (method == "ML") {
        object@est_parameters <- est_parameters
        object@method <- "ML"
        object@models[[1]] <- models
    }
    
    return(object) 
}

#' Setting results of optimisation routine to an object of 
#' gecon_estimation_results class.
#' 
#' The \code{set_optimisation_results} function sets the results
#' of the optimisation routine to an object of 
#' gecon_estimation_results class. In case of Bayesian estimation,
#' these results are modes of posterior kernel, while in case of
#' maximum likelihood method the results are maximum likelihood
#' estimates of parameters.
#' 
#' @param est_results an object of \code{gecon_estimation_results} class.
#' 
#' @param opt_result a numeric vector of parameter values returned from
#'                  the maximisation routine.
#'        
#' @param opt_err a numeric vector of std. errors for parameter estimates
#'                 returned from the maximisation routine.
#' 
#' @slot hessian_pos_def a logical. If TRUE, the Hessian of optimised
#'                       function computed at its maximum
#'                       was positive definite.
#'
#' @return an object of \code{gecon_estimation_results} class.
#'
#' @keywords internal                     
set_optimisation_results <- function(est_results, opt_result, 
                                     opt_err, hessian_pos_def = TRUE)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class") 
    
    if (est_results@method == "Bayes") {
        est_results@opt_result <- opt_result
        est_results@opt_err <- opt_err
        est_results@hessian_pos_def <- hessian_pos_def
    } else {
        est_results@estimates <- opt_result
        est_results@stddev <- opt_err
        est_results@hessian_pos_def <- hessian_pos_def    
    }
    return(est_results)    
}
                            

#' Extend stored chain by new data
#' 
#' Method adds new draws from posterior distribution to one of the chains and updates information
#' about estimation, such as means and standard deviations.
#' 
#' @param est_results an object of \code{gecon_estimation_results} class.
#' 
#' @param model a solved model of \code{gecon_model} class.
#' 
#' @param chain a numeric, index of the chain.
#' 
#' @param data a matrix of new draws from posterior distribution.
#' 
#' @param time a time for calculation of new part of draw.
#' 
#' @return The function returns an updated object 
#'         of \code{gecon_estimation_results} class.
#'
#' @keywords internal
extend_chain <- function(est_results, chain_data, model, chain, data, acceptance) 
{        
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")

              n <- nrow(data)
              
              # update acceptance rate
              est_results@acceptance_rate <- (est_results@acceptance_rate * est_results@total_n + acceptance * n ) / 
                                             (est_results@total_n + n)
              
              # update means
              est_results@estimates <- (est_results@estimates * est_results@total_n + colSums(data) ) / 
                                       (est_results@total_n + n)
              
              # update squares
              est_results@square_estimates <- (est_results@square_estimates * est_results@total_n + colSums(data ^ 2) ) /
                                              (est_results@total_n + n) 
              
              # update total number of observations           
              est_results@total_n <- est_results@total_n + n
              
              # calculate standard deviation
              est_results@stddev <- sqrt(est_results@square_estimates - est_results@estimates ^ 2)
              
              # calculate naive standard error
              est_results@naive_se <- est_results@stddev / sqrt(est_results@total_n)
              
              # check if any data already exist
              if ( is.na( est_results@chains[[chain]][1]) &  (length(est_results@chains[[chain]]) = 1)) {
                  est_results@chains[[chain]] <- data
                  colnames( est_results@chains[[chain]] ) <- get_estimated_par_names(est_results@prior)
              }
              else { # if any data exist - extend the chain 
                  temp <- rbind(chain_data, data)
                  est_results@chains[[chain]] <- temp
                  colnames( est_results@chains[[chain]] ) <- get_estimated_par_names(est_results@prior)
              }
              # save gecon_model object
              est_results@models[[chain]] <- model
              
              return(est_results)
}

#' Burns initial draws
#' 
#' @param est_results an object of \code{gecon_estimation_results} class.
#' 
#' @param n a numeric indicating number of draws to burn.
#' 
#' @return The function returns an updated object 
#'         of \code{gecon_estimation_results} class.
#' 
#' @keywords internal
burn_initial <- function(est_results, n) 
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")
   
    len <- nrow( est_results@chains[[1]] )
    chains <- length( est_results@chains )
       
    if ( len > n ) { 
        # draws will be burn
        for ( i in 1:chains ) {
            rem_chain <- check_shape( est_results@chains[[i]][ (n+1):len, ], 
                                      ncol = ncol( est_results@chains[[i]] ) )
            est_results@chains[[i]] <- 0
            # calculate acceptance rate ( coda package )
            accept <- 1 - max( rejectionRate( mcmc( rem_chain ) ) )
            # save part of chain which is left
            est_results <- extend_chain( est_results, est_results@models[[i]], 
                                         chain = i, data = rem_chain,
                                         acceptance = accept )
        }
    } else {
        for ( i in 1:chains ) {
            est_results@models[[i]] <- est_results@models[[i]]
            est_results@chains[[i]] <- 0
        }
    }
    return( est_results )
}

#' Create an object of \code{mcmc.list} class
#' 
#' The \code{create_mcmc.list} function retrieves Markov chains from
#' an object of \code{gecon_estimation_results} class and transforms them
#' into an object which may be analysed by the \code{coda-package} package.
#' 
#' @param est_results an object of \code{gecon_estimation_results} class.
#' 
#' @return The function returns a \code{mcmc.list} object
#'         created based on the estimation results.
#'
#' @examples
#' # load example estimation results
#' data(example_estimation_result)
#' summary(example_estimation_result)
#' 
#' # create an object for the analysis with the coda package
#' dsge_mcmc_list <- create_mcmc.list(example_estimation_result)
create_mcmc.list <- function(est_results) 
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")

    tmp <- list()
    for ( i in 1:length( est_results@chains ) ) {
      tmp[[i]] <- mcmc( as.matrix(est_results@chains[[i]]) )
    }
    mcmc <- do.call("mcmc.list", tmp)
    return(mcmc)
}


#' @rdname print-methods
setMethod("print",
          "gecon_estimation_results",
          function(x) {
            if (length(x@est_parameters) == 1)
                cat("One parameter for the model", get_model_info(x@models[[1]])[1], "has been estimated.\n")
            else {
                cat(length(x@est_parameters), "parameters of the", get_model_info(x@models[[1]])[1], "model have been estimated.\n")
            }
              
            if (x@method == "Bayes") { 
                  cat("\n")
                  cat("Model has been estimated using Bayesian methods.\n")
                  cat("\n")
                  cat("DSGE model MCMC estimation results\n\n")
                  cat("Total sample size: ", x@total_n, "\n")
                  cat("Number of chains: ", length(x@chains), "\n" )
                  cat("Acceptance rate: ", round( x@acceptance_rate * 100, 0) , "%\n")
                  cat("Marginal density(Laplace transform): ", x@marg_density, "\n" )
                  cat("\n")
                  
                  cat("Posterior info:\n\n")
                  out <- as.data.frame( matrix(NA, ncol = 2, nrow = length( get_estimated_par_names(x@prior) ) ) )
                  colnames(out) <- c("  Mean ", " Std. dev.")
                  rownames(out) <- get_estimated_par_names(x@prior)
                  out[,1] <- paste0("  ", format(x@estimates, digits = 4) )
                  out[,2] <- paste0("  ", format(x@stddev, digits = 4) )
                  print(out, right=FALSE)
                  cat("\n")
            } else {
                  cat("\n")
                  cat("Model has been estimated using maximum likelihood method.")
                  if (x@hessian_pos_def) {  
                    cat("\n Inverse Hessian is positive definite.\n\n")
                    cat("\nThe following parameters have been estimated:\n")
                    var_df <- data.frame(x@est_parameters, row.names = c(1:length(x@est_parameters)))
                    colnames(var_df) <- "Parameters"
                    print(var_df)
                  } else
                    cat("\n Inverse Hessian is NOT positive definite. The estimation results are likely to be incorrect. \n\n")
            }
            cat("\n----------------------------------------------------------", "\n\n")
        return(invisible(list(est = x@estimates,
                              marg_density = x@marg_density)))
        }
)

#' @rdname show-methods
setMethod("show",
          "gecon_estimation_results",
          function(object) {

              if (object@method == "Bayes") {
                  mcmc <- create_mcmc.list(object)              
                  cat("Model has been estimated using Bayesian methods\n")
                  cat("\n")
                  cat("DSGE model MCMC estimation results\n\n")
                  cat("Total sample size: ", object@total_n, "\n")
                  cat("Number of chains: ", length(object@chains), "\n" )
                  cat("Acceptance rate: ", round( object@acceptance_rate * 100, 0) , "%\n")
                  cat("\n")
              } else {
                  cat("Model has been estimated using maximum likelihood method")
                  if (object@hessian_pos_def)
                      cat("\n Inverse Hessian is positive definite.\n\n")
                  else
                      cat("\n Inverse Hessian is NOT positive definite. The estimation results are likely to be incorrect. \n\n")
              }
          }
)

#' @rdname summary-methods
setMethod("summary",
          "gecon_estimation_results",
          function(object) {
              if (object@method == "Bayes") {
                  mcmc <- create_mcmc.list(object)
                  chains <- length(object@chains)
                  cat("\nDSGE model MCMC estimation results\n\n")
                  cat("Total sample size: ", object@total_n, "\n")
                  cat("Number of chains: ", chains, "\n" )
                  cat("Acceptance rate: ", round( object@acceptance_rate * 100, 0) , "%\n")
                  cat("Marginal density(Laplace transform): ", object@marg_density, "\n" )
                  
                  cat("\n-----------------------------------------------------------\n\n")
                  cat("Prior info:\n\n")
                  out <- as.data.frame( matrix(NA, ncol = 2, nrow = length( get_estimated_par_names(object@prior) ) ))
                  colnames(out) <- c("  Mean ", " Std. dev.")
                  rownames(out) <- get_estimated_par_names(object@prior)
                  out[,1] <- paste0("  ", format( get_prior_means(object@prior), digits = 4))
                  out[,2] <- paste0("  ", format( get_prior_sd(object@prior), digits = 4))
                  print(out, right = FALSE)
                  
                  cat("\n-----------------------------------------------------------\n\n")
                  cat("Posterior info:\n\n")
                  out <- as.data.frame( matrix(NA, ncol = 7, nrow = length(  get_estimated_par_names(object@prior)) ) )
                  colnames(out) <- c(" Mean ", " Std. dev.", " Naive SE (mean)", 
                                     " Eff. sample", " Eff. SE (mean)",
                                     " Conf. interval (95%)", " HPD interval (95%)")
                  rownames(out) <- get_estimated_par_names(object@prior)
                  out[,1] <- paste0("  ", format(object@estimates, digits = 4) )
                  out[,2] <- paste0("  ", format(object@stddev, digits = 4) )
                  out[,3] <- paste0("  ", format(object@naive_se, digits = 4) )
                  eff_size <- effectiveSize( mcmc )  
                  out[,4] <- paste0("  ", round(eff_size, 0))
                  out[,5] <- paste0("  ", format( object@stddev / sqrt(eff_size), digits = 4))
                  
                  big_sample <- do.call("rbind", object@chains)
                  big_mcmc <- mcmc( big_sample )
                  hpd <- HPDinterval( big_mcmc )
                  
                  for (i in 1:nrow(out) ) {
                      # quantiles
                      out[i,6] <- paste0("  ", 
                                         paste0( format( quantile(big_sample[,i], c(0.025, 0.975)), digits = 4), 
                                                 collapse = " - " ) )
                      
                      # HPD interval
                      out[i,7] <- paste0("  ", 
                                         paste0( format(hpd[i, 1:2], digits = 4), 
                                                        collapse = " - " ) )
                      
                  }
                  
                  print(out[ ,1:5], right = FALSE)
                  cat("\n")
                  print(out[ ,6:7], right = FALSE)
                  
                  cat("\n-----------------------------------------------------------\n\n")
                  
                  cat("Geweke diagnostics: \n\n")
                  out <- as.data.frame( matrix(NA, 
                                               ncol = chains, 
                                               nrow = length( get_estimated_par_names(object@prior) ) ) )
                  rownames(out) <- get_estimated_par_names(object@prior)
                  colnames(out) <- paste0("p-value (chain ", 1:chains, ")")
                  geweke <- geweke.diag( mcmc )
                  
                  for (i in 1:chains) {
                      out[, i] <- paste0("   ", round(2 * pnorm( - abs( geweke[[i]]$z ) ), 4) )
                   }
                  
                  print(out, right = FALSE)
                  cat("\n")
                  cat("Low p-values indicate problem with chain convergence.\n", 
                      "For Geweke statistic fractions 0.1 and 0.5 were used.\n", sep = "")
                  cat("\n")
              } else {
                  cat("Model has been estimated using maximum likelihood method")
                  if (object@hessian_pos_def) {  
                      cat("\nInverse Hessian is positive definite.\n\n")
                      cat("\nThe estimation results:\n")
                      get_optimisation_statistics(object)
                  } else
                      cat("\n Inverse Hessian is NOT positive definite. The estimation results are likely to be incorrect. \n\n")

              }
              
          return(invisible(list(est = object@estimates,
                                 marg_density = object@marg_density)))
          }
)        
          
#' Plot posterior distributions
#' 
#' The \code{plot_posterior} function plots posterior distributions 
#' for the estimated parameters. The prior distributions are plotted 
#' for comparison.
#'
#' @param est_results an object of \code{gecon_estimation_results} class.
#' 
#' @param kernel a character specifying the name of smoothing kernel
#'               to be used. One of the following kernels can be used:
#'               \code{"gaussian"}, \code{"rectangular"}, \code{"triangular"},
#'               \code{"epanechnikov"}, \code{"biweight"}, \code{"cosine"}
#'               or \code{"optcosine"}. The default value is \code{"epanechnikov"}.
#'
#' @param bw_adjust a numeric. The adjustment parameter for bandwith. 
#'                  It allows the user to control degree of smoothness for
#'                  non-parametric density estimation results.                   
#'
#' @param to_eps logical. If TRUE, plot(s) are saved as \code{.eps} 
#'        file(s) in the model's subdirectory \code{/plots} and added 
#'        to \code{.results.tex} file.
#'
#' @examples
#' # load example estimation results
#' data(example_estimation_result)
#'
#' # plot posterior
#' plot_posterior(example_estimation_result)
plot_posterior <- function(est_results, kernel = "epanechnikov", bw_adjust = 1.5, to_eps = FALSE)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")
        
    parameters <- get_estimated_par_names(est_results@prior)
    n_priors <- length(parameters)    

    prior <- est_results@prior
    if (to_eps) {
        path_m <- gsub(pattern = paste0(prior@model_info[1], "(.gcn)?$"),
                       replacement = "",
                       x = prior@model_info[2])
        path_m <- paste(path_m, "plots", sep = "")
        dir.create(path_m, showWarnings = FALSE)
        files <- character()
        descriptions <- character()
    }

    for (i in 1:n_priors) {
        prior_coord <- prior_density_xy(prior, parameters[i])
        chains <- do.call("rbind", est_results@chains)
        x_min <- quantile(x = chains[, i], probs = c(0.01))
        x_max <- quantile(x = chains[, i], probs = c(0.99))
        x_min2 <- x_min  - (x_max - x_min) * 1 / 3
        x_max2 <- x_max  + (x_max - x_min) * 1 / 3
        posterior_coord <- density(chains[, i], 
                                   bw = "nrd0", 
                                   adjust = bw_adjust,
                                   kernel = kernel, 
                                   weights = NULL, 
                                   window = kernel, 
                                   from = x_min2, to = x_max2,
                                   give.Rkern = FALSE,
                                   na.rm = FALSE)           
                if (to_eps) {
                    file_name <- gEcon:::unique_output_name(path_m)
                    files <- c(files, file_name)
                    file_name <- paste0(path_m, "/", file_name)
                    descr <- paste0("Prior and posterior distributions for: $", 
                                    prior@parameters_tex[i], "$")
                    descriptions <- c(descriptions, descr)
                    main <- NULL
                } else {
                    file_name <- NULL
                    main <- parameters[i]
                }

        gecon_lines(data = prior_coord, data2 = posterior_coord, main = main,
                    eps_path = file_name)
    }  
    
    if (to_eps) {
        tex_out <- paste0("\n\\pagebreak\n\n\\section{", "Posterior distributions", "}\n\n")
        tnpl <- length(files)
        if (tnpl == 1) {
            inds2 <- numeric()
            indr <- 1
        } else {
            inds2 <- 2 * (1:(tnpl %/% 2))
            indr <- (tnpl %% 2) * (1 + 2 * (tnpl %/% 2))
        }
        
        for (i in inds2) {
            mpage <- paste0("\\begin{figure}[h]\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-1em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[i - 1], "}\n",
                            "\\caption{", descriptions[i - 1] , "}\n",
                            "\\end{minipage}\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-1em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[i], "}\n",
                            "\\caption{", descriptions[i] ,"}\n",
                            "\\end{minipage}\n",
                            "\\end{figure}\n\n")
            tex_out <- paste0(tex_out, mpage)
            if (!(i %% 4)) tex_out <- paste0(tex_out, "\\pagebreak\n\n")
        }
        if (indr) {
            mpage <- paste0("\\begin{figure}[h]\n",
                            "\\centering\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-1em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[indr], "}\n",
                            "\\caption{", descriptions[indr] ,"}\n",
                            "\\end{minipage}\n",
                            "\\end{figure}")
            tex_out <- paste0(tex_out, mpage)
        }
        filenam <- paste0(gsub(pattern = paste0("(.gcn)?$"),
                               replacement = "",
                               x = prior@model_info[2]), ".results.tex")
        if (file.exists(filenam)) {
            write(tex_out, filenam, sep = "\n", append = TRUE)
        } else {
            write(tex_out, filenam  , sep = "\n")
        }
        cat(paste0("saved ", gEcon:::list2str(files, "\'"), " in directory \'", path_m, "\'\n"))
        cat(paste0("plot(s) added to \'", filenam, "\'\n"))
    }
    
    return(invisible(NULL))
}


#' Retrieve model parameters based on estimation results
#' 
#' The \code{get_estimated_par} function allows to 
#' retrieve estimated parameters' values from
#' the object of \code{gecon_estimation_results} class. 
#' For models estimated using Bayesian
#' methods, point estimates are computed as a mean of posterior
#' distribution (default) or as a result of a function specified by user.
#'
#' @param est_results an object of \code{gecon_estimation results} class.
#'
#' @param est_function a list of the names of functions that are to be 
#'                     used to transform the posterior into point estimates.
#'
#' @return A list of parameter values. The \code{free_par} element contains
#'         values of estimated model parameters while the \code{shock_distr_par}
#'         element contains values of shock distibution parameters.
#'
#' @examples
#' # load example estimation results
#' data(example_estimation_result)
#' summary(example_estimation_result) 
#' 
#' # retrieve point estimates of parameter values
#' # (computed as a mean and as a median of the posterior distribution)
#' dsge_estimated_par_mean <- get_estimated_par(est_results = example_estimation_result)
#'
#' dsge_estimated_par_median <- get_estimated_par(est_results = example_estimation_result,
#'                                                est_function = list("sd(epsilon_G)" = "median",
#'                                                                    "sd(epsilon_Z)" = "median",
#'                                                                    "phi_G" = "median",
#'                                                                    "phi_Z" = "median",
#'                                                                    "omega" = "median"))
#'
#' cbind(dsge_estimated_par_mean$free_par, dsge_estimated_par_median$free_par)
#' cbind(dsge_estimated_par_mean$shock_distr_par, dsge_estimated_par_median$shock_distr_par)
get_estimated_par <- function(est_results, est_function = NULL)
{  
    if (est_results@method ==  "Bayes") {
        est_par <- est_results@est_parameters
        chain <- vector(length = 0)
        for (i in 1:length(est_results@chains)) {
            chain <- rbind(chain, est_results@chains[[i]])
        }
        
        if (is.null(est_function)) {
            par_list <- apply(chain, MARGIN = 2, FUN = mean)
            names(par_list) <- est_par       
        } else {
            est_parameters <- names(est_function)
            est <- match(est_par, names(est_function))
            if (any(is.na(est))) {
                stop(paste("the est_function function has not been specified for the following parameters of the model",
                           paste(est_par[which(is.na(est))], col = ", ")))
            }
            par_list <- rep(NA, length(est_par))
            names(par_list) <- est_parameters
            for (i in 1:length(est_par)) {   
                par_list[i] <- do.call(what = est_function[[est[i]]], args = list(chain[, i]))
            }
        }
    } else {
        est_par <- est_results@est_parameters
        par_list <- est_results@estimates
    }
    cat("Estimated parameter values:\n")
    par_list_print <- data.frame(par_list, row.names = est_par)
    colnames(par_list_print) <- c("Values:")
    print(par_list_print)
    names(par_list) <- est_par
    model <- est_results@models[[1]]
    pt <- parameter_type(model, est_par)$par_type
    result_list <- vector(length = 0, mode = "list")
    
    if (length(which(!pt)) != 0) {
        result_list$free_par <- par_list[which(!pt)]  
    }
    
    if (length(which(pt > 0)) != 0) {
        result_list$shock_distr_par <- par_list[which(pt > 0)]  
    }    
    
    return (invisible(result_list))
}



#' Check if an object is \code{gecon_estimation_results}
#' 
#' The \code{is.gecon_estimation_results} function 
#' allows to check if supplied argument 
#' is of \code{is.gecon_estimation_results} class. 
#'
#' @param x any R object
#' 
#' @return a logical value indicating if object
#'         is of class "is.gecon_estimation_results"
#'
#' @keywords internal
is.gecon_estimation_results <- function(x)
{
    if (is(x, "gecon_estimation_results"))
        return(TRUE)
    else return(FALSE)
}

#' Retrieving the posterior distribution statistics
#' 
#' The \code{get_posterior_statistics} function allows
#' to retrieve moments and position statistics from
#' the posterior distribution.
#'
#' @param est_results an object of \code{gecon_estimation_results} class.
#'
#' @param quantile a numeric vector of numbers in the [0,1] interval.
#'                 By this argument, the relevant quantiles of 
#'                 posterior distribution can be requested.            
#'
#' @param silent logical. The default value is FALSE. 
#'               If set to TRUE, the console output is suppressed.
#'
#' @return The function returns a list with the following elements:
#'         \itemize{
#'                   \item \code{means} a numeric vector of posterior distribution
#'                                      means for each estimated parameter,
#'                   \item \code{medians} a numeric vector of posterior distribution
#'                                       medians for each estimated parameter,
#'                   \item \code{std_dev} a numeric vector of posterior distribution
#'                                       standard deviations for each estimated parameter,
#'                   \item \code{quantiles_computed} a numeric matrix of posterior distribution
#'                                                   quantiles for each estimated parameter.
#'                  }
#'
#' @examples
#' # load example estimation results
#' data(example_estimation_result)
#'
#' # retrieve statistics summarising the posterior distribution
#' get_posterior_statistics(example_estimation_result, 
#'                          quantile = c(0.1, 0.4, 0.8, 0.9))
get_posterior_statistics <- function(est_results, 
                                     quantile = c(0.05, 0.95), silent = FALSE)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")
    
    if (!silent) {
        if (est_results@method == "Bayes") {
            chains <- do.call("rbind", est_results@chains)
            means <- apply(X = chains, MARGIN = 2, "mean")
            names(means) <- est_results@est_parameters
            medians <- apply(X = chains, MARGIN = 2, "median")
            names(medians) <- est_results@est_parameters
            std_dev <- apply(X = chains, MARGIN = 2, "sd")
            names(std_dev) <- est_results@est_parameters
            quantiles_computed <- t(apply(FUN = "quantile", MARGIN=2, 
                             X = chains, probs = quantile))
            rownames(quantiles_computed) <- est_results@est_parameters
            stats <- data.frame(cbind(means, medians, std_dev, quantiles_computed), 
                                row.names = est_results@est_parameters)
            names(stats)[1:3] <- c("Mean", "Median", "Standard dev.")
            print(stats)
        } else  {
            stop("there is no posterior distribution for models estimated using maximum likelihood method")
        }
    }

    return(invisible(list(means = means,
                          medians = medians,
                          std_dev = std_dev,
                          quantiles_computed = quantiles_computed)))
}

#' Likelihood / posterior kernel optimisation statistics
#' 
#' The \code{get_optimisation_statistics} function allows to retrieve the 
#' results of the optimisation routine. The statistics may refer to
#' posterior kernel optimisation (Bayesian estimation) or likelihood
#' function optimisation (maximum likelihood method).
#'
#' @param est_results an object of \code{gecon_estimation_results} class.
#'
#' @param silent logical. The default value is FALSE. 
#'        If set to TRUE, the console output is suppressed.
#' 
#' @return The function returns a list with two elements:
#'         \itemize{
#'             \item \code{mode} a vector of posterior kernel modes or 
#'                    maximum likelihood estimates,
#'             \item \code{std_error} a vector of standard errors for 
#'                    the estimated parameters.
#'         }
#'
#' @examples
#' # #################################################################
#' # 1. prepare gEcon model
#' 
#' # copy the example to the current working directory
#' file.copy(from = file.path(system.file("examples", package = "gEcon.estimation"),
#'                            "dsge_model.gcn"), to = getwd())
#' dsge_model <- make_model("dsge_model.gcn")
#' 
#' # solve the model
#' dsge_model <- steady_state(dsge_model)
#' dsge_model <- solve_pert(dsge_model, loglin = TRUE)
#' 
#' # set the stochastic shocks distribution parameters
#' dsge_model <- set_shock_distr_par(dsge_model,
#'                                   distr_par = list("sd( epsilon_G )" = 0.01,
#'                                                    "sd( epsilon_Z )" = 0.01))
#' shock_info(model = dsge_model, all = TRUE)
#' 
#' # load data
#' data(example_estimation_data)
#'
#' # ###################################################################
#' # 2. maximum likelihood estimation
#' 
#' ml_estimation_result <- ml_estimation(data_set = example_estimation_data, 
#'                                       observables = c("Y", "G"), 
#'                                       model = dsge_model, 
#'                                       est_par = c("sd(epsilon_G)", "sd(epsilon_Z)"), 
#'                                       initial_vals = c("sd(epsilon_G)" = 0.007, 
#'                                                      "sd(epsilon_Z)" =  0.007))
#' 
#' # retrieving estimation statistics
#' summary(ml_estimation_result)
#' get_optimisation_statistics(ml_estimation_result)          
get_optimisation_statistics <- function(est_results, silent = FALSE)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")
       
    res_list <- vector(length = 0, mode = "list")
    if (est_results@method == "Bayes") {
        res_list$mode <- est_results@opt_result 
        res_list$std_error <- est_results@opt_err
    } else {
        res_list$mode <- est_results@estimates 
        res_list$std_error <- est_results@stddev    
    }
    if (!silent) {
        df_mod <- data.frame(cbind(res_list$mode, res_list$std_error))
        if (est_results@method == "Bayes") {
            cat("The posterior kernel optimisation statistics:\n \n")
            names(df_mod) <- c("Posterior mode:", "Std. err:") 
        } else  {
            cat("The likelihood optimisation statistics:\n")
            names(df_mod) <- c("ML estimate:", "Std. err:") 
        }
        print(df_mod)
    }
        
    return(invisible(res_list))       
}


#' Retrieving the \code{gecon_prior} class objects from 
#' the \code{gecon_estimation_results} class objects
#' 
#' The \code{get_prior} function allows to retrieve \code{gecon_prior}
#' class objects from \code{gecon_estimation_results} class objects. 
#'
#' @param est_results an object of \code{gecon_estimation_results} class.
#' 
#' @return The function returns an object of \code{gecon_prior} class.
#'
#' @keywords internal
get_prior <- function(est_results)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")
    
    if (est_results@method != "Bayes")
        stop("priors can be returned only for models estimated using Bayesian methods")
        
    return(est_results@prior)      
}


#' Retrieving the MCMC chains from 
#' the \code{gecon_estimation_results} class objects
#' 
#' The \code{get_chains} function allows to retrieve chains
#' from the objects of \code{gecon_estimation_results} class. 
#'
#' @param est_results an object of \code{gecon_estimation results} class.
#' 
#' @return The function returns a list of MCMC chains.
get_chains <- function(est_results)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")

    if (est_results@method != "Bayes")
        stop("MC chains can be returned only for models estimated using Bayesian methods")
              
    return(est_results@chains)      
}

#' Retrieving the specific MCMC chain from 
#' the \code{gecon_estimation_results} class objects
#' 
#' The \code{get_chain} function allows to retrieve specific chain
#' from the objects of \code{gecon_estimation_results} class. 
#'
#' @param est_results an object of \code{gecon_estimation results} class.
#'
#' @param number a numeric. The chain number
#' 
#' @return A matrix of the MCMC chain.
get_chain <- function(est_results, number)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")

    if (est_results@method != "Bayes")
        stop("MC chains can be returned only for models estimated using Bayesian methods")
              
    return(est_results@chains[[number]])      
}


#' Retrieving estimates and standard deviations from 
#' the \code{gecon_estimation_results} class objects
#' 
#' The \code{get_estimates} function allows to retrieve 
#' estimates and standard deviations from 
#' the \code{gecon_estimation_results} class objects.
#'
#' @param results an object of \code{gecon_estimation results} class.
#' 
#' @return The function returns a list with two elements corresponding
#'         to object's current estimates and standard deviation.
#'
#' @keywords internal
get_estimates <- function(est_results)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")
        
    return(list(estimates = est_results@estimates,
                stddev = est_results@stddev))      
}


#' Retrieving the acceptance rate from
#' the \code{gecon_estimation_results} class objects
#' 
#' The \code{get_prior} function allows to retrieve acceptance rate
#' from \code{gecon_estimation_results} class objects. 
#'
#' @param est_results an object of \code{gecon_estimation_results} class.
#' 
#' @return The function returns a numeric indicating the acceptance rate.
#'
#' @keywords internal
get_acc_rate <- function(est_results)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")
    
    if (est_results@method != "Bayes")
        stop("acceptance rate can be returned only for models estimated using Bayesian methods")

    return(est_results@acceptance_rate)      
}


#' Retrieving models from the \code{gecon_estimation_results} class
#' 
#' The \code{get_models} function allows to retrieve \code{gecon_model}
#' class objects from \code{gecon_estimation_results} class objects. 
#'
#' @param est_results an object of \code{gecon_estimation_results} class.
#' 
#' @return The function returns a list with objects of
#'         \code{gecon_model} class. The number of models is equal
#'         to the number of MC chains.
#'
#' @keywords internal
get_models <- function(est_results)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")

    return(est_results@models)         
}

#' Setting models to \code{gecon_estimation_results} object
#' 
#' The \code{set_models} function allows to
#' set models list to a \code{gecon_estimation_results} object. 
#'
#' @param est_results an object of \code{gecon_estimation results} class.
#'
#' @param models a list of objects of \code{gEcon_model} class. Each
#'                 of the models contains solved model for the last iteration
#'                 of the random walk Metropolis-Hastings algorithm.
#' 
#' @return The function returns an object of 
#'         \code{gecon_estimation_results} class.
#'
#' @keywords internal
set_models <- function(est_results, models)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the est_results argument has to be of gecon_estimation_results class")
        
    est_results@models <- models
    
    return(est_results)         
}


#' Set marginal density
#' 
#' The \code{set_marg_density} function allows to
#' set marginal density to a \code{gecon_estimation_results} object. 
#'
#' @param results an object of \code{gecon_estimation results} class.
#'
#' @param marg_density a numeric, marginal density (Laplace approximation)
#'                     of the posterior.
#' 
#' @return The function returns an object 
#'         of \code{gecon_estimation_results} class.
#'
#' @keywords internal
set_marg_density <- function(est_results, marg_density)
{
    if(!is.gecon_estimation_results(est_results))
        stop("the results argument has to be of gecon_estimation_results class")

    est_results@marg_density <- marg_density

    return(est_results)         
}
