# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Paweł Romański                                                    #
# ############################################################################
# Provides function solving Lyapunov equation X=AXA'+Q
# ############################################################################

#' Solves eqation AXB'+Q=X 
#'
#' The \code{vec_solve} function solves equation AXB'+Q=X using vectorisation.
#' 
#' @param A a matrix
#' 
#' @param B a matrix
#' 
#' @param Q a matrix
#' 
#' @return The function returns matrix X - the solution of AXB'+Q=X  
#'         equation.
#'
#' @keywords internal
vec_solve <- function(A, B, Q)
{
    d <- func_dim(A)
    e <- func_dim(B)
    if (!is.matrix(A) & !is.matrix(B)) { 
        # solve if both A and B are scalars
        X <- Q / (1 - A * B)
    } else { 
        # solve otherwise
        a <- diag(d[2] * e[1]) - as.matrix(kronecker(B, A))
        b <- as.vector(Q)
        X <- solve(a, b)
    }
    return(matrix(X, ncol = d[2]))
}

#' The \code{lyapunov} function solves Lyapunov equation
#'
#' The \code{lyapunov} function solves discrete
#' Lyapunov equation AXA'+Q=X. If solution 
#' does not exist, function returns an error.
#' 
#' @param A a matrix.
#' @param Q a matrix.
#' @param tol a numeric, tolerance for zeros. The default value is \code{1e-8}.
#' 
#' @return The function returns the matrix X - the solution of the
#'         Lyapunov equation
#'
#' @keywords internal
lyapunov <- function(A, Q, tol = 1e-8)
{
    A <- as.matrix(A)
    d <- dim(A)
    if (d[1] != d[2])
        stop("argument A must be a square matrix")
    s <- Schur(A) # decomposition of A into PRP'
    R <- s$T
    P <- s$Q
    W <- t(P) %*% Q %*% P
    X <- matrix(0, nrow = d[1], ncol = d[1])
    dms <- rep(0, d[1]) # sizes of blocks
    idx <- rep(0, d[1]) # indices of the beginnings of the blocks
    p <- 0 # block counter
    i<-1
    
    while (i <= d[1]) { # check the sizes of the blocks
        p <- p + 1
        idx[p] <- i
        if (i != d[1]) { 
            # check if not the last element on the diagonal
            if (abs(R[i + 1, i]) > tol) { 
                # non-zero below the diagonal
                dms[p] <- 2 # set size of block
                i <- i + 1
            } else {
                # zero below the diagonal
                dms[p] <- 1
            }
        } else {
            dms[p] <- 1
        }
        i <- i + 1
    }
    for (j in p:1) { 
        # main part of algorithm
        SS <- matrix(0, nrow = d[1], ncol = dms[j]) #sub-sum
        jj <- idx[j]:( idx[j] + dms[j] - 1 ) # indices of j-th block
        for (i in p:1) {
            ii <- idx[i]:(idx[i] + dms[i] - 1) # indices of i-th block
            sum <- matrix( rep(0, dms[i] * dms[j]), ncol = dms[j] )
            for (m in j:p) {
                mm <- idx[m]:(idx[m] + dms[m]-1) # indices of m-th block
                SS[ii, 1:dms[j] ] <- SS[ii, 1:dms[j]] + mmult( X[ii, mm], t(R[jj, mm]), dms[i], dms[j] )
            }
            for (l in i:p) {
                ll <- idx[l]:(idx[l] + dms[l] - 1) # indices of l-th block
                sum <- sum + mmult(R[ii, ll], SS[ll, 1:dms[j] ], dms[i], dms[j])
            }
            X[ii, jj] <- vec_solve(R[ii, ii], R[jj, jj], sum + W[ii, jj])
            SS[ii, 1:dms[j] ] <- SS[ii, 1:dms[j]] + mmult( X[ii, jj], t(R[jj, jj]), dms[i], dms[j] )
        }
    }
    X <- P %*% X %*% t(P)
    error <- max( abs( A %*% X %*% t(A) + Q - X ) ) 
    if (error > tol) # check if solution is correct
        stop("precision of the Lyapunov solution is lower than tol: ", error, ".\n",
             "Either solution does not exit or the value of the parameter tol is too low")
    return (X)
}
