# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski                                                    #
# ############################################################################
# Maximum likelihood estimation of DSGE models
# ############################################################################

#' Maximum likelihood estimation of DSGE models
#' 
#' The \code{ml_estimation} function allows to estimate DSGE model parameters
#' using maximum likelihood method. The vector of parameters
#' maximising the likelihood function is treated as point estimate of parameters.
#' For details about likelihood construction method, 
#' see \code{\link{gecon.estimation-package}}.
#' 
#' @param data_set an object of \code{ts} or \code{mts} class containing
#'        data for the estimation of the model. 
#'        The time series supplied have to be stationary, detrended, and deseasoned.
#'        The number of series supplied cannot be greater than 
#'        number of shocks in the model. Estimation based on data sets
#'        with missing observations is not supported in the current version.
#'
#' @param observables a character with the length 
#'        equal to the number of \code{data_set} columns.
#'        By this argument the names of observable variables can be specified
#'        (each of them must correspond to one of the model variables).
#'
#' @param model an object of \code{gecon_model} class.
#'        
#' @param est_parameters a character vector of estimated parameters' names.
#'        
#' @param l_bound a numeric of parameter range lower bounds.
#'        
#' @param u_bound a numeric of parameter range upper bounds.
#'
#' @param initial_vals a named vector of initial values of estimated parameters. 
#'
#' @param optim_options_list a list of options for 
#'        the likelihood maximisation routines:
#'             \itemize{
#'                  \item \code{solver} a character; the name of solver:
#'                        \itemize{
#'                             \item \code{csminwelNew} - \code{csminwelNew} solver 
#'                                   (updated version of \code{csminwel}),
#'                             \item \code{csminwel} - \code{csminwel} solver (default), 
#'                             \item \code{Nelder-Mead} - the Nelder-Mead routine 
#'                                   implemented in the \code{optim} function,
#'                             \item \code{GenSA} - a simulated annealing 
#'                                   solver from \code{GenSA} package.
#'                        }
#'                  \item \code{solver_crit} a numeric, the convergence criterion for a solver.
#'                        The default value is 1e-7. Not used by the \code{GenSA} solver.
#'                  \item \code{solver_iter} a numeric, the maximum number of iterations for a solver.
#'                        The default value is 1000.
#'                  \item \code{init_hess_scale} a numeric, size of the diagonal elements of
#'                        initial Hessian used by \code{csminwel} and \code{csminwelNew} procedures.
#'                        Not used by \code{Nelder-Mead} and \code{GenSA} solvers. 
#'                        The default value is 1e-4.
#'                  \item \code{temperature} a numeric, the initial temperature for \code{GenSA}
#'                        solver. The default value is 5230.
#'                  \item \code{visiting.param} a numeric, a visiting parameter for \code{GenSA}
#'                        solver. The default value is 2.62.
#'                  \item \code{acceptance.param} a numeric, an acceptance parameter for \code{GenSA}
#'                        solver. The default value is -5.
#'                  \item \code{max.call} a numeric, the maximum number of function calls if \code{GenSA}
#'                        solver is used. The default value is 1e+06.
#'                  \item \code{solver_hess} a logical value. If set to TRUE, the Hessian returned from
#'                        the numerical solver is used for computation of variance of sampling distribution.
#'                        By setting this value to TRUE, one can obtain only approximate Hessian.
#'                        However, such an approximate Hessian may be more often positive definite 
#'                        (thanks to rank-one updates) than one computed explicitly.
#'                        The \code{Nelder-Mead} and \code{GenSA} solvers do not return Hessian.
#'                        The default value is FALSE.
#'                  \item \code{hessian_d} a numeric, delta used to compute Hessian numerically.
#'                        The default value is 0.001.
#'                  \item \code{hessian_eps} a numeric, tolerance of the routine computing Hessian.
#'                        The default value is 1e-7.
#'             }
#' 
#' @examples
#' # #################################################################
#' # 1. prepare gEcon model
#' 
#' # copy the example to the current working directory
#' file.copy(from = file.path(system.file("examples", package = "gEcon.estimation"),
#'                            "dsge_model.gcn"), to = getwd())
#' dsge_model <- make_model("dsge_model.gcn")
#' 
#' # solve the model
#' dsge_model <- steady_state(dsge_model)
#' dsge_model <- solve_pert(dsge_model, loglin = TRUE)
#' 
#' # set the stochastic shocks distribution parameters
#' dsge_model <- set_shock_distr_par(dsge_model,
#'                                   distr_par = list("sd( epsilon_G )" = 0.01,
#'                                                    "sd( epsilon_Z )" = 0.01))
#' shock_info(model = dsge_model, all = TRUE)
#' 
#' # load data
#' data(example_estimation_data)
#'
#' # ###################################################################
#' # 2. maximum likelihood estimation
#' 
#' ml_estimation_result <- ml_estimation(data_set = example_estimation_data, 
#'                                       observables = c("Y", "G"), 
#'                                       model = dsge_model, 
#'                                       est_par = c("sd(epsilon_G)", "sd(epsilon_Z)"), 
#'                                       initial_vals = c("sd(epsilon_G)" = 0.007, 
#'                                                      "sd(epsilon_Z)" =  0.007))
#' 
#' # retrieving estimation statistics
#' summary(ml_estimation_result)
#' get_optimisation_statistics(ml_estimation_result)             
ml_estimation <- function(data_set,
                          observables,
                          model = NULL,
                          est_parameters,
                          l_bound,
                          u_bound,
                          initial_vals,
                          optim_options_list = NULL)
{
    # start clock
    real_start <- Sys.time()
    
    # ####################################################################
    # check inputs 
    if(!is.gecon_model(model))
        stop("the model argument has to be of gecon_model class")

    if((!is.ts(data_set) & !is.mts(data_set)))
        stop("the data_set argument has to be of (m)ts class")

    if(!is.character(observables))
        stop("the observables argument has to be a character vector")
        
    # retrieve information from data and validate them with model
    val_data <- validate_data(model, data_set, observables = observables)
    obs_var_indices <- val_data$obs_var_indices
    observables <- val_data$observables
    series_start <- val_data$series_start
    series_freq <- val_data$series_freq
    data_set <- val_data$data_set
    n_obs <- val_data$n_obs
    n_var <- val_data$n_var

    var_initval_coresp <- match(names(initial_vals), est_parameters)
    if (any(is.na(var_initval_coresp))) {
        stop(paste("the following initial values do not correspond to any of estimated parameters:\n",
              paste(names(initial_vals)[is.na(var_initval_coresp)], collapse = ", "), sep = ""))
    }

    # validate model
    validate_model(model)
 
    # verify if the number of shocks is appropriate for estimating the model                 
    if ( n_var > length(get_shock_names(model)) )
        stop("you can not use for estimation more observable variables than shocks in the model")

    # create new gecon_estimation_results object
    result <- gecon_estimation_results(models = model, est_parameters = est_parameters, method = "ML")
    # calculate steady state for the initial values
    cat("Calculating steady states for initial parameters ... ")
    
   
    
    # ####################################################################
    # finding parameters maximising the likelihood
         
    # initial values
    opt_pars_len <- length(est_parameters)
    init_pars <- rep(0.5, opt_pars_len)
    
    par_types <- parameter_type(model = model, parameters = est_parameters)
    
    par_type <- par_types$par_type
    shock_names_matrix <- par_types$shock_names_matrix 
    
    if (!is.null(get_shock_cov_mat(model))) {
        sh_mat <- get_shock_cov_mat(model)
        sq_sh_mat <- sqrt(diag(sh_mat))
        sh_mat <- sh_mat / kronecker(sq_sh_mat, t(sq_sh_mat))
        cov_sd_ind <- par_type
        if (length(which(cov_sd_ind > 0))) {
            init_pars[which(cov_sd_ind > 0)] <- sh_mat[shock_names_matrix]
        }
    }

    model_par <- get_par_values(model, silent = TRUE) 
    init_pars[-which(cov_sd_ind > 0)] <- model_par[est_parameters[-which(cov_sd_ind > 0)]]
    names(init_pars) <- est_parameters
    
    init_pars[var_initval_coresp] <- initial_vals
    
    # the likelihood function for model
    likelihood_fun <- function(pars)
    {
        # update parameters
        output_text <- capture.output(
            model_opt_tr <- update_model(model, pars, cov_sd_ind)
        )
        if (!is.null(model_opt_tr)) {
            output_text <- capture.output(
            tmp_model <- update_model(model, parameters = pars, par_type)
            )
            if ( is.null( tmp_model ) ) # if sth is wrong            
                return( Inf )   
        } else return( Inf )
          
        # compute likelihood
        output_text <- capture.output(
            like <- likelihood(data = data_set, model = model_opt_tr, 
                       value_on_failure = NULL) 
        )
        if (!is.null(like$log_likelihood)) {
            return(-like$log_likelihood)
        } else {
            return(Inf)
        }
    }
  
    # proper maximisation
    opt_fun_result <- maximise_function(fun = likelihood_fun, 
                                        init_pars = init_pars, 
                                        l_bound = l_bound,
                                        u_bound = u_bound,
                                        optim_options_list = optim_options_list)
    lik_mode <- opt_fun_result$f_mode
    f_inv_hess <- opt_fun_result$f_inv_hess    
        
        
    cat("DONE \n")

    if_not_pos_def <- tryCatch(expr={dispersion <- t(chol(f_inv_hess)) ; FALSE},
                     warning = function(w) TRUE, 
                     error = function(w) TRUE)
    
    hessian_pos_def <- TRUE
    if (if_not_pos_def) {
        warning("the likelihood optimisation problem. Inverse Hessian is NOT positive definite. Try with different initial values") 
        hessian_pos_def <- FALSE
    }    

    # ####################################################################
    # retrieve the estimates 
    result <- gecon_estimation_results(models = model, est_parameters = est_parameters, method = "ML")
    result <- set_optimisation_results(est_results = result, 
                                       opt_result = lik_mode, 
                                       opt_err = sqrt(diag(f_inv_hess)), 
                                       hessian_pos_def = hessian_pos_def)
   
    cat("Estimation is DONE. Total time elapsed: ", time_difference( real_start ) , "\n", sep = "")
    
    return( result )
}
