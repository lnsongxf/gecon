# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski                                                    #
# ############################################################################
# Shock decomposition for DSGE models
# ############################################################################

#' Historical decomposition of the model variables
#'
#' The \code{shock_decomposition} function computes individual 
#' contributions of structural shocks to variability of
#' selected variables. 
#'
#' The decomposition is calculated as follows:
#' \itemize{
#'     \item the Kalman smoother formulas are applied to parametrised
#'           model and data so as to obtain the smoothed estimates of
#'           stochastic innovations and initial values of the state
#'           variables,
#'     \item the model is simulated given path of smoothed shocks,
#'     \item the difference between smoothed values of variables
#'           and values simulated based on smoothed shocks is computed.
#'           It can be attributed to the initial values of observables
#'           (the impact of shocks former to the start date of 
#'            supplied data set).
#' } 
#' 
#' @param model an object of \code{gecon_model} class. The solution
#'              of this model is used for constructing state-space 
#'              representation and the smoother formulas.
#' 
#' @param data_set an object of \code{ts} class containing observables
#'                 from the time period for which the decomposition
#'                 is to be performed.
#'
#' @param observables a character with the length 
#'                equal to the number of \code{data_set} argument columns.
#'                By this argument one has to specify names of
#'                observable variables supplied in the \code{data_set} argument.
#'
#' @param variables a character vector of the variables' names
#'                  for which the decomposition is to be performed.
#'                  If set to NULL (default), only state variables
#'                  are decomposed.
#' 
#' @return The function returns a list consisting of two elements:
#'         \itemize{
#'             \item \code{shock_dec_list} a list of \code{ts} objects. 
#'                     Each element of the list corresponds to one variable. 
#'                     The columns correspond to model shocks
#'                     and impact of the initial values.
#'             \item \code{variables_tex} a character vector of
#'                     variables' LaTeX names.
#'             \item \code{model_info} a character vector
#'                    containing information about the model for which 
#'                    the decomposition has been computed: the input file name, 
#'                    the input file path, and the date of creation.
#'         }
#' @examples
#' # load example data set and estimation results
#' data(estimated_model)
#' data(example_estimation_data)
#' 
#' # perform a shock decomposition
#' dsge_shock_decomposition <- shock_decomposition(model = estimated_model, 
#'                                                 data_set =  example_estimation_data, 
#'                                                 observables = c("Y", "G"), 
#'                                                 variables = c("K", "I", "C"))
#' plot_shock_decomposition(dsge_shock_decomposition)
shock_decomposition <- function(model, data_set, observables,
                                variables = NULL)
{
    # validate supplied arguments
    if(!is.gecon_model(model))
        stop("the model argument has to be of gecon_model class")

    if(!is.character(observables))
        stop("the observables argument has to be a character vector")
        
    if((!is.ts(data_set) & !is.mts(data_set)))
        stop("the data_set argument has to be of ts class")

    if (is.null(variables)) {
        pert_solution <- get_pert_solution(model, silent = TRUE)
        variables <- names(pert_solution$ss_val[pert_solution$state_ind])
    }
        
    variables_ind <- match(variables, get_var_names(model))   
    variables_tex <- model@variables_tex[variables_ind]
   
    if( any(is.na(variables_ind)) )
        stop(paste("the following variables do not correspond to",
                   "any of the model variables:",
                   paste(variables[which(is.na(variables_ind))], collapse = ", ")))
                   
    # ##########################################################################              
    # run Kalman smother
    smoother_output <- smoother(model, data_set, 
                                observables = observables, 
                                variables = get_var_names(model))
    smoothed_shocks <- smoother_output$smoothed_shock   
    smoothed_variables <- smoother_output$smoothed_var   
    
    n_shocks <- length(get_shock_names(model))
    n_var <- length(get_var_names(model))
    n_obs <- dim(smoothed_shocks)[1]
    
    pert_solution <- get_pert_solution(model, silent = TRUE)
    state_variables <- names(pert_solution$ss_val[pert_solution$state_ind])
    state_ind <- which(colnames(smoothed_variables) %in% state_variables)

    # initialise array for storing simulation outputs
    hist_dec_array <- array(0, dim = c(n_var, (n_shocks + 1), n_obs))
    state_var_indices <- match(state_variables, get_var_names(model))
    
    # create state-space matrices
    # PP
    PP <- matrix(0, nrow = n_var, ncol =  length(state_var_indices))
    PP[state_var_indices, ] <- pert_solution$P
    PP[-state_var_indices, ] <- pert_solution$R
    
    # QQ
    QQ <- matrix(0, nrow = n_var, ncol =  n_shocks)
    QQ[state_var_indices, ] <- pert_solution$Q
    QQ[-state_var_indices, ] <- pert_solution$S

    # ##########################################################################                                         
    # decompose for each period    
    hist_dec_array[, 1:n_shocks, 1]  <- QQ * kronecker(rep(1, n_var), t(smoothed_shocks[1, ]))
    hist_dec_array[, n_shocks + 1, 1] <- smoothed_variables[1, ] -
                                         rowSums(matrix(hist_dec_array[, 1:n_shocks, 1], ncol = n_shocks))


    for (i in 2:n_obs)
    {            
        hist_dec_array[, 1:n_shocks, i]  <- 
             PP %*% hist_dec_array[state_var_indices, 1:n_shocks, (i - 1)]
        hist_dec_array[, 1:n_shocks, i]  <- 
             hist_dec_array[, 1:n_shocks, i] + QQ * kronecker(rep(1, n_var), t(smoothed_shocks[i, ]))
        hist_dec_array[, n_shocks + 1, i] <- 
             smoothed_variables[i, ] - rowSums(matrix(hist_dec_array[, 1:n_shocks, i], ncol = n_shocks))
    }

    # ##########################################################################                                             
    # prepare output list
    out_list <- vector(mode = "list")
    
    for (i in 1:length(variables)) {
        out_list[[i]] <- ts(t(hist_dec_array[variables_ind[i], , ]), 
                            start = start(data_set), 
                            frequency = frequency(data_set),
                            names  = c(get_shock_names(model), "Initial values"))
    }
    names(out_list) <- variables
    
    return(list(shock_dec_list = out_list,
                variables_tex = variables_tex,
                model_info = get_model_info(model)))
}

#' Plot shock decomposition
#'
#' The \code{plot_shock_decomposition} function plots 
#' shock decomposition returned by the \code{\link{shock_decomposition}} function.
#' 
#' @param shock_dec_list a list created by the \code{\link{shock_decomposition}} function.
#'
#' @param to_eps logical. If TRUE, plot(s) are saved as \code{.eps} 
#'        file(s) in the model's subdirectory \code{/plots} and added 
#'        to \code{.results.tex} file.
#'
#' @examples
#' # load data_set and estimation results
#' data(estimated_model)
#' data(example_estimation_data)
#' 
#' # perform a shock decomposition
#' dsge_shock_decomposition <- shock_decomposition(model = estimated_model, 
#'                                                 data_set =  example_estimation_data, 
#'                                                 observables = c("Y", "G"), 
#'                                                 variables = c("K", "I", "C"))
#' plot_shock_decomposition(dsge_shock_decomposition)
plot_shock_decomposition <- function(shock_dec_list, to_eps = FALSE)
{
    if (!is.list(shock_dec_list) | 
        is.na(match("shock_dec_list", names(shock_dec_list))))
        stop("the shock_dec_list must be a list returned by shock_decomposition function")
        
    variables <-  names(shock_dec_list$shock_dec_list)
    
    if (to_eps) {
        path_m <- gsub(pattern = paste0(shock_dec_list$model_info[1], "(.gcn)?$"),
                       replacement = "",
                       x = shock_dec_list$model_info[2])
        path_m <- paste(path_m, "plots", sep = "")
        dir.create(path_m, showWarnings = FALSE)
        files <- character()
        descriptions <- character()
    }

    for (i in 1:length(shock_dec_list$shock_dec_list)) {
        # main title and settings
        if (to_eps) {
            file_name <- gEcon:::unique_output_name(path_m)
            files <- c(files, file_name)
            file_name <- paste0(path_m, "/", file_name)
            descr <- paste0("Shock decomposition for: $", 
                            shock_dec_list$variables_tex[i], "$")
            descriptions <- c(descriptions, descr)
            main <- NULL
        } else {
            file_name <- NULL
            main <- variables[i]
        }

        # shock decomposition
        gecon_shock_decomposition(data = shock_dec_list$shock_dec_list[[i]], 
                                  eps_path = file_name,
                                  main = main, 
                                  legend.text = colnames(shock_dec_list$shock_dec_list[[i]]))
                   
    }
    
    if (to_eps) {
        tex_out <- paste0("\n\\pagebreak\n\n\\section{", "Shock decompositions", "}\n\n")
        tnpl <- length(files)
        if (tnpl == 1) {
            inds2 <- numeric()
            indr <- 1
        } else {
            inds2 <- 2 * (1:(tnpl %/% 2))
            indr <- (tnpl %% 2) * (1 + 2 * (tnpl %/% 2))
        }
        
        for (i in inds2) {
            mpage <- paste0("\\begin{figure}[h]\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-1em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[i - 1], "}\n",
                            "\\caption{", descriptions[i - 1] , "}\n",
                            "\\end{minipage}\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-1em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[i], "}\n",
                            "\\caption{", descriptions[i] ,"}\n",
                            "\\end{minipage}\n",
                            "\\end{figure}\n\n")
            tex_out <- paste0(tex_out, mpage)
            if (!(i %% 4)) tex_out <- paste0(tex_out, "\\pagebreak\n\n")
        }
        if (indr) {
            mpage <- paste0("\\begin{figure}[h]\n",
                            "\\centering\n",
                            "\\begin{minipage}{0.5\\textwidth}\n",
                            "\\vspace*{-1em}\n",
                            "\\centering\n",
                            "\\includegraphics[width=0.99\\textwidth, scale=0.55]{",
                            "plots/", files[indr], "}\n",
                            "\\caption{", descriptions[indr] ,"}\n",
                            "\\end{minipage}\n",
                            "\\end{figure}")
            tex_out <- paste0(tex_out, mpage)
        }
        filenam <- paste0(gsub(pattern = paste0("(.gcn)?$"),
                               replacement = "",
                               x = shock_dec_list$model_info[2]), ".results.tex")
        if (file.exists(filenam)) {
            write(tex_out, filenam, sep = "\n", append = TRUE)
        } else {
            write(tex_out, filenam  , sep = "\n")
        }
        cat(paste0("saved ", gEcon:::list2str(files, "\'"), " in directory \'", path_m, "\'\n"))
        cat(paste0("plot(s) added to \'", filenam, "\'\n"))
    }
    
    return(invisible(NULL))
}
