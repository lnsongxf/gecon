# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski                                                    #
# ############################################################################
# Marginal density approximation
# ############################################################################

#' Marginal density approximation
#' 
#' The \code{marginal_density_laplace} function computes
#' the Laplace approximation of the posterior marginal density.
#' 
#' @param params a numeric vector of estimated parameters at posterior mode.
#' 
#' @param in_hess an inverse Hessian computed at posterior mode.
#'
#' @param data_set a matrix of data based on which model is estimated.
#'        
#' @param model an object of \code{gecon_model} class.
#'
#' @param prior an object of \code{gecon_prior} class.
#'        It declares the prior distribution of estimated parameters.
#' 
#' @return The function returns a numeric with marginal density approximation.
#' 
#' @keywords internal
marginal_density_laplace <- function(params, in_hess, data_set, model, prior)
{
    n <- length(params)
    scale_f <- -as.numeric(sum(log10(diag(in_hess))))
    log_det <- - n * log(scale_f) +  
               as.numeric(determinant(scale_f * in_hess, logarithm = TRUE)$modulus)
    output_text <-  capture.output(
        likelihood <- posterior(parameters = params, data_set = data_set, 
                            prior = prior, model)$log_density
    )
    marg_dens_la <- 0.5 * n * log(2 * pi) + 0.5 * log_det + likelihood
    names(marg_dens_la) <- "(Log-)marginal density"
    return(marg_dens_la)
}
