# ############################################################################
# This file is a part of gEcon.estimation                                    #
#                                                                            #
# (c) Chancellery of the Prime Minister of the Republic of Poland 2014-2015  #
# (c) Karol Podemski 2015-2016                                               #
# License terms can be found in the file 'LICENCE'                           #
#                                                                            #
# Authors: Karol Podemski, Paweł Romański                                    #
# ############################################################################
# Utility functions used throughout the package
# ############################################################################

#' Update model parameters
#' 
#' The \code{update_model} function updates the parameters and 
#' the distribution of stochastic shocks in \code{gecon_model} class objects.
#' 
#' @param model an object of \code{gecon_model} class.
#' 
#' @param parameters a list specifying parameters which should be changed.
#' 
#' @param par_info a numeric vector of length equal to the number
#'                 of estimated parameters with the following codes:
#'                 \itemize{
#'                    \item 0 denotes free parameter,
#'                    \item 1 denotes standard deviation of a shock,
#'                    \item 2 denotes correlation of shocks.}
#' 
#' @return an updated object of \code{gecon_model} class. 
#'         If the supplied parameters do not imply  positive definite
#'         variance-covariance 
#'         matrix of shocks, \code{NULL} value is returned.
#' 
#' @keywords internal
update_model <- function(model, parameters, par_info) 
{    
    
    # set free parameters
    std_index <- which(par_info == 0)
    
    if (length(std_index) > 0) {
        std_pars <- parameters[std_index]
        model <- set_free_par(model, std_pars, warnings = FALSE)
    }
    
    # set shock distribution parameters
    shock_index <- which(par_info > 0)
    no_error_flag <- 
      tryCatch(expr = { model <- set_shock_distr_par(model, parameters[shock_index]); 
                       TRUE },
                       warning = function(w) TRUE, 
                       error = function(w) FALSE)
    
    if (!no_error_flag) {
        return(NULL)
    }
    
    return(model)
}


#' Validate data
#'
#' The \code{validate_data} function checks correspondence
#' between the supplied data set and the model variables.
#' 
#' @param model an object of \code{gecon_model} class. The solution
#'              of this model serves for constructing a state space model 
#'              used by the Kalman filter/smoother.
#' 
#' @param data_set an object of \code{ts} class containing data (time series)
#'                 which are to be validated.
#'
#' @param observables a character with the length 
#'                      equal to the number of \code{data_set} argument columns.
#'                      By this argument one can specify the names of
#'                      observable variables supplied in the data set.
#' 
#' @return a list the following elements:
#' \itemize{
#'    \item \code{observables} a character vector of the names of the
#'          observable variables,
#'    \item \code{obs_var_indices} a numeric vector of the observable 
#'          variables indices in the object of \code{gecon_model} class,
#'    \item \code{series_start} a numeric containing initial time
#'          index for the supplied series,
#'    \item \code{series_freq} a numeric containing frequency of
#'          the supplied \code{ts} class object,
#'    \item \code{data_set} a matrix with the data extracted from 
#'          \code{ts} class object,
#'    \item \code{n_obs} a numeric storing the number of observations,
#'    \item \code{n_var} a numeric storing the number of observable variables. 
#'  }
#'
#' @keywords internal
validate_data <- function(model, data_set, observables = NULL)
{
    # check the dimension of data set    
    if (!is.null(dim(data_set))) {
        dims_data_set <- dim(data_set)
        n_obs <- dims_data_set[1]
        n_var <- dims_data_set[2]
    } else {
        n_obs <- length(data_set)
        n_var <- 1

    }
    
    # validate observables
    if (is.null(observables))
        stop("the variable names should be specified by the observables argument")
            
    if ((!is.null(observables)) & (length(observables) != n_var))
        stop("the number of names in the observables argument is different than number of variables in data set")
        
    obs_var_indices <- match(observables, get_var_names(model))
    if (any(is.na(obs_var_indices)))
        stop(paste("the following time series do not correspond to any model variables:\n",
                    paste(observables[which(is.na(obs_var_indices))], collapse = ", "), ".", sep = ""))
    
    # prepare data_set 
    series_start <- start(data_set)
    series_freq <- frequency(data_set)
    data_set <- matrix(data_set, n_obs, n_var)
    colnames(data_set) <- observables
    
    if (any(is.na(data_set) || is.nan(data_set)))
        stop("filtering of models with the missing data is not supported in the current version")
    
    if (anyDuplicated(colnames(data_set)))
        stop("the variables in the data_set should have distinct names")
    

    return(list(observables = observables,
                obs_var_indices = obs_var_indices,
                series_start = series_start,
                series_freq = series_freq,
                data_set = data_set,
                n_obs = n_obs,
                n_var = n_var))
}

#' Validate model
#'
#' The \code{validate_model} function checks if the estimation
#' using the supplied model is possible.
#'
#' @param model an object of \code{gecon_model} class. 
#'
#' @return stops when detecting error or returns NULL value
#'
#' @keywords internal
validate_model <- function(model) 
{
    if (!re_solved(model))
        stop("the model has to be solved first before estimating it.")
    
    # check if model is log-linearised
    pert_sol <- get_pert_solution(model, silent = TRUE)
    pert_val_names <- names(pert_sol$loglin)
    not_log <- pert_val_names[(!pert_sol$loglin) & (pert_sol$ss_val != 0)]
    
    if (length(not_log) > 0) 
        stop(paste("only models with log-linearised variables or variables with zero mean",
                "can be estimated in the current version of the package. Log-linearise",
                " the following variables before estimating the model:\n",
                paste(not_log, collapse = ", "), ".", sep = ""))
   
    
    cov_mat <- get_shock_cov_mat(model)
    
    if (any(diag(cov_mat) == 0))
        stop("all the model shocks must have non-zero variance") 
    return(NULL)
}
    

#' Set dimensions for vector
#' 
#' @param M a vector or matrix.
#' 
#' @param nrow a numeric specifying desired number of rows.
#' 
#' @param ncol a numeric specifying desired number of columns.
#' 
#' @return a matrix created from the vector.
#' 
#' @keywords internal
check_shape <- function(M, nrow = NULL, ncol = NULL) 
{
    if (!is.matrix(M)) {
        if (!is.null(nrow))
            M <- matrix(M, nrow = nrow)
        else
            M <- matrix(M, ncol = ncol)
    }
    return(M)
}


#' Dimensions of scalars, vectors and matrices
#'
#' The \code{func_dim} function returns 
#' the dimensions of the supplied scalar, vector or matrix.
#' 
#' @param a scalar, vector or matrix
#' 
#' @return a vector of two numerics(number of rows and number of columns).
#'
#' @keywords internal
func_dim <- function(A)
{
    if (is.matrix(A)) {
        return (dim(A))
    } else {
        return (c(length(A), 1))
    }
}


#' Multiplication of scalars, vectors and matrices
#'
#' The \code{mmult} function performs 
#' the multiplication of scalars, vectors and 
#' matrices. It prevents from multiplying vectors as t(v) %*% v
#' instead of v %*% t(v). 
#' 
#' @param A a matrix or vector.
#' 
#' @param B a matrix or vector.
#' 
#' @param n a number of rows of the result matrix.
#' 
#' @param k a number of columns of the result matrix.
#' 
#' @return The function returns the multiplication result.
#'
#' @keywords internal
mmult <- function(A, B, n, k)
{
    if ( length(A) == 1 | length(B) == 1) 
        # if A or B is scalar
        return (A * B)
    else { 
        A <- matrix(as.vector(A), nrow = n)
        B <- matrix(as.vector(B), ncol = k)
        return (A %*% B)
    }
}

#' Time difference
#' 
#' Calculates how much time has passed between given date and current time.
#' 
#' @param start a \code{.POSIXct} object specifying the starting date. 
#' 
#' @param multiply a numeric of optional factor 
#'                 by which the time difference is multiplyed.
#' 
#' @return The time elapsed between \code{start} and \code{Sys.time()}
#'         expressed in 00h 00m 00s or 000d 00h 00m 00s format.
#'
#' @keywords internal
time_difference <- function(start, multiply = 1) 
{
    start_time <- as.POSIXct(start)
    dt <- difftime(Sys.time(), start_time, units="secs") * multiply
    if (dt < 60 * 60 * 24)
        return(format(.POSIXct(dt, tz="GMT"), "%Hh %Mm %Ss"))
    else
        return (format(.POSIXct(dt - 60 * 60 * 24, tz="GMT"), "%jd %Hh %Mm %Ss"))
}


