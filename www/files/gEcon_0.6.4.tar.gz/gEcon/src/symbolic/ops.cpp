/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

 /** \file ops.cpp
 * \brief Operations.
 */


#include <ops.h>
#include <ex_num.h>
#include <ex_symb.h>
#include <ex_vart.h>
#include <ex_add.h>
#include <ex_mul.h>
#include <ex_pow.h>
#include <ex_func.h>
#include <ex_e.h>
#include <cmp.h>
#include <error.h>
#include <iostream>
#include <cmath>
#include <climits>


using namespace symbolic;
using namespace symbolic::internal;


ptr_base
symbolic::internal::reduce(const ptr_base &p)
{
    if (p->flag() == EMPTY) {
        if (p->type() == ADD) return ex_num::zero();
        if (p->type() == MUL) return ex_num::one();
        INTERNAL_ERROR;
    }
    if ((p->flag() == (SINGLE | SCAL1)) && (p->type() == MUL)) {
        return static_cast<const ex_mul*>(p.get())->m_ops[0].second;
    }
    if ((p->flag() == (SINGLE | SCAL1)) && (p->type() == ADD)) {
        return static_cast<const ex_add*>(p.get())->m_ops[0].second;
    }
    if ((p->flag() & SPOW1) && (p->type() == MUL)) {
        const ex_mul *pp = static_cast<const ex_mul*>(p.get());
        return ex_add::create(pp->m_ops[0].second->val(), pp->m_ops[1].second);
    }

    return p;
}


ptr_base
symbolic::internal::mk_neg(const ptr_base &x)
{
    return mk_mul(ex_num::create(-1.), x);
}


ptr_base
symbolic::internal::mk_add(const ptr_base &lhs, const ptr_base &rhs)
{
    if (lhs->is0()) return rhs;
    if (rhs->is0()) return lhs;

    unsigned t1, t2;
    t1 = lhs->type();
    t2 = rhs->type();

    if ((t1 == NUM) && (t2 == NUM)) {
        return ex_num::create(lhs->val() + rhs->val());
    } else {
        return reduce(ex_add::create(lhs, rhs));
    }
}



namespace {

ptr_base
mk_rec_add(const num_ex_pair_vec &ops, unsigned b, unsigned e)
{
    if (b == e) return mk_mul(ex_num::create(ops[b].first), ops[b].second);
    if ((b + 1) == e) return mk_add(mk_rec_add(ops, b, b), mk_rec_add(ops, e, e));
    unsigned d = (e - b) / 2;
    return mk_add(mk_rec_add(ops, b, b + d), mk_rec_add(ops, b + d + 1, e));
}

} /* namespace */


ptr_base
symbolic::internal::mk_add(const num_ex_pair_vec &ops)
{
    return mk_rec_add(ops, 0, ops.size() - 1);
}




ptr_base
symbolic::internal::mk_sub(const ptr_base &lhs, const ptr_base &rhs)
{
    return mk_add(lhs, mk_neg(rhs));
}




ptr_base
symbolic::internal::mk_mul(const ptr_base &lhs, const ptr_base &rhs)
{
    unsigned t1, t2, f1, f2;
    t1 = lhs->type();
    t2 = rhs->type();
    f1 = lhs->flag();
    f2 = rhs->flag();

    if ((t1 == NUM) && (t2 == NUM)) {
        return ex_num::create(lhs->val() * rhs->val());
    }

    if (lhs->is0()) return lhs;
    if (rhs->is0()) return rhs;
    if (lhs->is1()) return rhs;
    if (rhs->is1()) return lhs;

    if ((t1 == NUM) && (t2 == ADD)) {
        return ex_add::create(lhs->val(), rhs);
    } else if ((t1 == ADD) && (t2 == NUM)) {
        return ex_add::create(rhs->val(), lhs);
    } else if ((t1 == NUM) && ((t2 == SYMB) || (t2 == VART))) {
        return ex_add::create(lhs->val(), rhs);
    } else if (((t1 == SYMB) || (t1 == VART)) && (t2 == NUM)) {
        return ex_add::create(rhs->val(), lhs);
    } else if ((t1 == ADD) && (f1 & SINGLE) && (t2 == ADD) && (f2 & SINGLE)) {
        const ex_add *p1 = static_cast<const ex_add*>(lhs.get());
        const ex_add *p2 = static_cast<const ex_add*>(rhs.get());
        return reduce(ex_mul::create(
            ex_mul::create(
                ex_num::create(p1->m_ops[0].first),
                p1->m_ops[0].second),
            ex_mul::create(
                ex_num::create(p2->m_ops[0].first),
                p2->m_ops[0].second)));
    } else if ((t1 == ADD) && (f1 & SINGLE)) {
        const ex_add *p = static_cast<const ex_add*>(lhs.get());
        return reduce(ex_mul::create(ex_num::create(p->m_ops[0].first),
                    ex_mul::create(p->m_ops[0].second, rhs)));
    } else if ((t2 == ADD) && (f2 & SINGLE)) {
        const ex_add *p = static_cast<const ex_add*>(rhs.get());
        return reduce(ex_mul::create(ex_num::create(p->m_ops[0].first),
                    ex_mul::create(p->m_ops[0].second, lhs)));
    } else {
        return reduce(ex_mul::create(lhs, rhs));
    }
}



namespace {

ptr_base
mk_rec_mul(const num_ex_pair_vec &ops, unsigned b, unsigned e)
{
    if (b == e) return mk_pow(ops[b].second, ex_num::create(ops[b].first));
    if ((b + 1) == e) return mk_mul(mk_rec_mul(ops, b, b), mk_rec_mul(ops, e, e));
    unsigned d = (e - b) / 2;
    return mk_mul(mk_rec_mul(ops, b, b + d), mk_rec_mul(ops, b + d + 1, e));
}


} /* namespace */


ptr_base
symbolic::internal::mk_mul(const num_ex_pair_vec &ops)
{
    return mk_rec_mul(ops, 0, ops.size() - 1);
}




ptr_base
symbolic::internal::mk_div(const ptr_base &lhs, const ptr_base &rhs)
{
    return mk_mul(lhs, mk_pow(rhs, ex_num::create(-1)));
}


ptr_base
symbolic::internal::mk_pow(const ptr_base &lhs, const ptr_base &rhs)
{
    unsigned t1, t2, f1;
    t1 = lhs->type();
    t2 = rhs->type();
    f1 = lhs->flag();

    if ((t1 == NUM) && (t2 == NUM)) {
        return ex_num::create(pow(lhs->val(), rhs->val()));
    }

    if (lhs->is0()) return lhs;
    if (rhs->is0()) return ex_num::one();
    if (rhs->is1()) return lhs;

    if ((t1 == MUL) && (t2 == NUM)) {
        return ex_mul::create(rhs->val(), lhs);
    } else if (((t1 == SYMB) || (t1 == VART)) && (t2 == NUM)) {
        return ex_mul::create(rhs->val(), lhs);
    } else if ((t1 == ADD) && (f1 & SINGLE) && (t2 == NUM)) {
        const ex_add *p = static_cast<const ex_add*>(lhs.get());
        if (p->m_ops[0].first == 1.)
            return ex_pow::create(p->m_ops[0].second, rhs);
        return ex_mul::create(
            ex_num::create(pow(p->m_ops[0].first, rhs->val())),
            ex_mul::create(rhs->val(), p->m_ops[0].second)
            );
    } else if (t1 == POW) {
        const ex_pow *p = static_cast<const ex_pow*>(lhs.get());
		return mk_pow(p->m_base, mk_mul(p->m_exp, rhs));
    } else if (t2 == NUM) {
        return ex_mul::create(rhs->val(), lhs);
    } else {
        return ex_pow::create(lhs, rhs);
    }
}




ptr_base
symbolic::internal::lag(const ptr_base &p, int l)
{
    if (!l) return p;
    if (!(p->flag() & HAST)) return p;
    unsigned t = p->type();
    // if ((t == NUM) || (t == SYMB)) return p;
    if (t == VART) return static_cast<const ex_vart*>(p.get())->lag(l);
    else if (t == EX) return static_cast<const ex_e*>(p.get())->lag(l);
    else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_add*>(p.get())->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(in[i].first,
                                                        lag(in[i].second, l)));
        return mk_add(out);
    } else if (t == MUL) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_mul*>(p.get())->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(in[i].first,
                                                        lag(in[i].second, l)));
        return mk_mul(out);
    } else if (t == POW) {
        const ex_pow *pt = static_cast<const ex_pow*>(p.get());
        return mk_pow(lag(pt->m_base, l), lag(pt->m_exp, l));
    } else if (t == FUN) {
        const ex_func *pt = static_cast<const ex_func*>(p.get());
        return ex_func::create(pt->m_code, lag(pt->m_arg, l));
    } else INTERNAL_ERROR;
}



ptr_base
symbolic::internal::ss(const ptr_base &p)
{
    if (!(p->flag() & HAST)) return p;
    unsigned t = p->type();
    // if ((t == NUM) || (t == SYMB)) return p;
    if (t == VART)
        return ex_vart::create(static_cast<const ex_vart*>(p.get())->m_hash, INT_MIN);
    else if (t == EX) return ss(static_cast<const ex_e*>(p.get())->m_arg);
    else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_add*>(p.get())->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(num_ex_pair(in[i].first, ss(in[i].second)));
        return mk_add(out);
    } else if (t == MUL) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_mul*>(p.get())->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(in[i].first, ss(in[i].second)));
        return mk_mul(out);
    } else if (t == POW) {
        const ex_pow *pt = static_cast<const ex_pow*>(p.get());
        return reduce(mk_pow(ss(pt->m_base), ss(pt->m_exp)));
    } else if (t == FUN) {
        const ex_func *pt = static_cast<const ex_func*>(p.get());
        return reduce(ex_func::create(pt->m_code, ss(pt->m_arg)));
    } else INTERNAL_ERROR;
}






ptr_base
symbolic::internal::drop_Es(const ptr_base &p)
{
    if (!has_Es(p)) return p;
    unsigned t = p->type();
    if (t == EX) {
        return static_cast<const ex_e*>(p.get())->m_arg;
    } else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_add*>(p.get())->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(in[i].first,
                                                      drop_Es(in[i].second)));
        return mk_add(out);
    } else if (t == MUL) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_mul*>(p.get())->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i)
            out.push_back(std::pair<Number, ptr_base>(in[i].first,
                                                      drop_Es(in[i].second)));
        return mk_mul(out);
    } else if (t == POW) {
        const ex_pow *pt = static_cast<const ex_pow*>(p.get());
        return mk_pow(drop_Es(pt->m_base), drop_Es(pt->m_exp));
    } else if (t == FUN) {
        const ex_func *pt = static_cast<const ex_func*>(p.get());
        return ex_func::create(pt->m_code, drop_Es(pt->m_arg));
    } else INTERNAL_ERROR;
}


bool
symbolic::internal::has(const ptr_base &p, const ptr_base &what)
{
    if (!compare(p, what)) return true;
    unsigned t = p->type();
    if (t == EX) {
        return has(static_cast<const ex_e*>(p.get())->m_arg, what);
    } else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_add*>(p.get())->m_ops;
        unsigned i, n = in.size();
        for (i = 0; i < n; ++i) {
            if (has(in[i].second, what)) return true;
        }
        return false;
    } else if (t == MUL) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_mul*>(p.get())->m_ops;
        unsigned i, n = in.size();
        for (i = 0; i < n; ++i) {
            if (has(in[i].second, what)) return true;
        }
        return false;
    } else if (t == POW) {
        const ex_pow *pt = static_cast<const ex_pow*>(p.get());
        if (has(pt->m_base, what)) return true;
        if (has(pt->m_exp, what)) return true;
        return false;
    } else if (t == FUN) {
        const ex_func *pt = static_cast<const ex_func*>(p.get());
        if (has(pt->m_arg, what)) return true;
        return false;
    }
    return false;
}



bool
symbolic::internal::hast(const ptr_base &p, const ptr_base &what)
{
    if (!compare(p, what)) return true;
    unsigned t = p->type();
    if ((t == VART) && (what->type() == VART)) {
        const ex_vart *p1 = static_cast<const ex_vart*>(p.get());
        const ex_vart *p2 = static_cast<const ex_vart*>(what.get());
        if (!p1->compare_name(*p2)) return true;
        return false;
    } else if ((t == EX) && (what->type() == EX)) {
        const ex_e *p1 = static_cast<const ex_e*>(p.get());
        const ex_e *p2 = static_cast<const ex_e*>(what.get());
        int l1 = p1->m_lag, l2 = p2->m_lag, ld;
        if ((ld = l2 - l1)) {
            if (!compare(lag(p1->m_arg, ld), p2->m_arg)) return true;
        } else {
            if (!compare(p1->m_arg, p2->m_arg)) return true;
        }
    } else if (t == EX) {
        return hast(static_cast<const ex_e*>(p.get())->m_arg, what);
    } else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_add*>(p.get())->m_ops;
        unsigned i, n = in.size();
        for (i = 0; i < n; ++i) {
            if (hast(in[i].second, what)) return true;
        }
        return false;
    } else if (t == MUL) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_mul*>(p.get())->m_ops;
        unsigned i, n = in.size();
        for (i = 0; i < n; ++i) {
            if (hast(in[i].second, what)) return true;
        }
        return false;
    } else if (t == POW) {
        const ex_pow *pt = static_cast<const ex_pow*>(p.get());
        if (hast(pt->m_base, what)) return true;
        if (hast(pt->m_exp, what)) return true;
        return false;
    } else if (t == FUN) {
        const ex_func *pt = static_cast<const ex_func*>(p.get());
        if (hast(pt->m_arg, what)) return true;
        return false;
    }
    return false;
}





bool
symbolic::internal::hasdifft(const ptr_base &p, const ptr_base &what)
{
    if (!compare(p, what)) return false;
    unsigned t = p->type();
    if ((t == VART) && (what->type() == VART)) {
        const ex_vart *p1 = static_cast<const ex_vart*>(p.get());
        const ex_vart *p2 = static_cast<const ex_vart*>(what.get());
        if (!p1->compare_name(*p2) && (p1->m_lag != p2->m_lag)) return true;
        return false;
    } else if ((t == EX) && (what->type() == EX)) {
        const ex_e *p1 = static_cast<const ex_e*>(p.get());
        const ex_e *p2 = static_cast<const ex_e*>(what.get());
        int l1 = p1->m_lag, l2 = p2->m_lag, ld;
        if ((ld = l2 - l1)) {
            if (!compare(lag(p1->m_arg, ld), p2->m_arg)) return true;
        } else return false;
    } else if (t == EX) {
        return hasdifft(static_cast<const ex_e*>(p.get())->m_arg, what);
    } else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_add*>(p.get())->m_ops;
        unsigned i, n = in.size();
        for (i = 0; i < n; ++i) {
            if (hasdifft(in[i].second, what)) return true;
        }
        return false;
    } else if (t == MUL) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_mul*>(p.get())->m_ops;
        unsigned i, n = in.size();
        for (i = 0; i < n; ++i) {
            if (hasdifft(in[i].second, what)) return true;
        }
        return false;
    } else if (t == POW) {
        const ex_pow *pt = static_cast<const ex_pow*>(p.get());
        if (hasdifft(pt->m_base, what)) return true;
        if (hasdifft(pt->m_exp, what)) return true;
        return false;
    } else if (t == FUN) {
        const ex_func *pt = static_cast<const ex_func*>(p.get());
        if (hasdifft(pt->m_arg, what)) return true;
        return false;
    }
    return false;
}




bool
symbolic::internal::haslead(const ptr_base &p, const ptr_base &what)
{
    if (!compare(p, what)) return false;
    unsigned t = p->type();
    if ((t == VART) && (what->type() == VART)) {
        const ex_vart *p1 = static_cast<const ex_vart*>(p.get());
        const ex_vart *p2 = static_cast<const ex_vart*>(what.get());
        if (!p1->compare_name(*p2) && (p1->m_lag > p2->m_lag)) return true;
        return false;
    } else if ((t == EX) && (what->type() == EX)) {
        const ex_e *p1 = static_cast<const ex_e*>(p.get());
        const ex_e *p2 = static_cast<const ex_e*>(what.get());
        int l1 = p1->m_lag, l2 = p2->m_lag, ld;
        if ((ld = l2 - l1) > 0) {
            if (!compare(lag(p1->m_arg, ld), p2->m_arg)) return true;
        } else return false;
    } else if (t == EX) {
        return haslead(static_cast<const ex_e*>(p.get())->m_arg, what);
    } else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_add*>(p.get())->m_ops;
        unsigned i, n = in.size();
        for (i = 0; i < n; ++i) {
            if (haslead(in[i].second, what)) return true;
        }
        return false;
    } else if (t == MUL) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_mul*>(p.get())->m_ops;
        unsigned i, n = in.size();
        for (i = 0; i < n; ++i) {
            if (haslead(in[i].second, what)) return true;
        }
        return false;
    } else if (t == POW) {
        const ex_pow *pt = static_cast<const ex_pow*>(p.get());
        if (haslead(pt->m_base, what)) return true;
        if (haslead(pt->m_exp, what)) return true;
        return false;
    } else if (t == FUN) {
        const ex_func *pt = static_cast<const ex_func*>(p.get());
        if (haslead(pt->m_arg, what)) return true;
        return false;
    }
    return false;
}



bool
symbolic::internal::has_Es(const ptr_base &p)
{
    unsigned t = p->type();
    if (t == EX) {
        return true;
    } else if (t == ADD) {
        unsigned i, n = static_cast<const ex_add*>(p.get())->m_ops.size();
        for (i = 0; i < n; ++i) {
            if (has_Es(static_cast<const ex_add*>(p.get())->m_ops[i].second))
                return true;
        }
        return false;
    } else if (t == MUL) {
        unsigned i, n = static_cast<const ex_mul*>(p.get())->m_ops.size();
        for (i = 0; i < n; ++i) {
            if (has_Es(static_cast<const ex_mul*>(p.get())->m_ops[i].second))
                return true;
        }
        return false;
    } else if (t == POW) {
        const ex_pow *pt = static_cast<const ex_pow*>(p.get());
        if (has_Es(pt->m_base)) return true;
        if (has_Es(pt->m_exp)) return true;
        return false;
    } else if (t == FUN) {
        const ex_func *pt = static_cast<const ex_func*>(p.get());
        if (has_Es(pt->m_arg)) return true;
        return false;
    }
    return false;
}



ptr_base
symbolic::internal::mk_E(const ptr_base &p, int l)
{
    if (!(p->flag() & HAST)) return p;
    if (l >= p->get_lag_max(true)) return p;
    unsigned t = p->type();
    if (t == VART) {
        if (l < static_cast<const ex_vart*>(p.get())->get_lag())
        return ex_e::create(p, l); else return p;
    } else if (t == EX) {
        const ex_e *pp = static_cast<const ex_e*>(p.get());
        return ex_e::create(pp->m_arg, std::min(l, pp->get_lag()));
    } else if (t == ADD) {
        num_ex_pair_vec in, out;
        in = static_cast<const ex_add*>(p.get())->m_ops;
        unsigned i, n = in.size();
        out.reserve(n);
        for (i = 0; i < n; ++i) {
            out.push_back(num_ex_pair(in[i].first, mk_E(in[i].second, l)));
        }
        return mk_add(out);
    } else return ex_e::create(p, l);
}




ptr_base
symbolic::internal::mk_func(func_code c, const ptr_base &arg)
{
    if (arg->type() == NUM) return ex_num::create(ex_func::eval(c, arg->val()));
    return ex_func::create(c, arg);
}



ptr_base
symbolic::internal::append_name(const ptr_base &p, const std::string &s)
{
    unsigned t = p->type();
    if (t == SYMB) {
        return ex_symb::create(static_cast<const ex_symb*>(p.get())->get_name() + s);
    }
    if (t == VART) {
        return ex_vart::create(static_cast<const ex_vart*>(p.get())->get_name() + s, 0);
    }
    USER_ERROR("append_name expects parameter or variable")
}




















