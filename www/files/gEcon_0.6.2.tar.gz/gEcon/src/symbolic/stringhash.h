/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file stringhash.h
 * \brief Hash values for strings.
 */

#ifndef SYMBOLIC_STRINGHASH_H

#define SYMBOLIC_STRINGHASH_H

#include <string>
#include <map>


namespace symbolic {
namespace internal {


class stringhash
{
  public:
    // Given string get hash values
    unsigned get_hash(const std::string &str);
    // Given string get hash values
    const std::string& get_str(unsigned id) const;
    // Get instance
    static stringhash& get_instance()
    {
        static stringhash instance;
        return instance;
    }

  private:
    // Maps
    std::map<std::string, unsigned> m_map2int;
    std::map<unsigned, std::string> m_map2str;
    // Index
    unsigned m_ind;
    // Constructor is private
    stringhash() : m_ind(0) { ; }
    // Private, too. Not implemented.
    stringhash(stringhash const& copy);
    stringhash& operator=(stringhash const& copy);

}; /* class stringhash */


} /* namespace internal */
} /* namespace symbolic */

#endif /* SYMBOLIC_STRINGHASH_H */
