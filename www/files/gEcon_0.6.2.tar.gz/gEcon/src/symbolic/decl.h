/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file decl.h
 * \brief Forward declarations and enums.
 */

#include <triplet.h>
#include <string>
#include <algorithm>
#include <vector>
#include <set>
#include <map>


#ifndef SYMBOLIC_DECL_H

#define SYMBOLIC_DECL_H


namespace symbolic {


// Forward decl
class ex;

struct less_ex {
    bool operator()(const symbolic::ex &a, const symbolic::ex &b) const;
    typedef ex first_argument_type;
    typedef ex second_argument_type;
    typedef bool result_type;
};

typedef std::vector<ex> vec_ex;
typedef std::set<ex, less_ex> set_ex;
typedef std::map<ex, ex, less_ex> map_ex_ex;
typedef std::map<ex, int, less_ex> map_ex_int;
typedef std::map<ex, std::string, less_ex> map_ex_str;
typedef std::map<std::string, std::string> map_str_str;


namespace internal {

// Forward decl
class ex_base;
class ptr_base;
class ex_num;
class ex_symb;
class ex_vart;
class ex_pow;
class ex_func;
class ex_e;
class num_ex_pair_vec;
class ex_add;
class ex_mul;


/// Expression types
enum ex_type {
    NUL     =      0,
    EMPTY   =    0x1,
    SINGLE  =    0x2,
    SCAL1   =    0x4,
    SPOW1   =    0x8,
    HAST    =   0x10,
    NUM     =  0x100,
    SYMB    =  0x200,
    VART    =  0x400,
    FUN     =  0x800,
    ADD     = 0x1000,
    MUL     = 0x2000,
    POW     = 0x4000,
    EX      = 0x8000
};



/// Function codes
enum func_code {
    EXP = 0, LOG,
    SIN, COS, TAN,
    ASIN, ACOS, ATAN,
    SINH, COSH, TANH
    // ERF
};


/// Printing flags
enum print_flag {
    DEFAULT = 0,
    CONVERT_T_IDX,
    DROP_T_IDX
};


} /* namespace internal */
} /* namespace symbolic */

#endif /* SYMBOLIC_DECL_H */
