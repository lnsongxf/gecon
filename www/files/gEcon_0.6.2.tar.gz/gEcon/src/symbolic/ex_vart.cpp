/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file ex_vart.cpp
 * \brief Time indexed variables.
 */

#include <error.h>
#include <ex_vart.h>
#include <ex_num.h>
#include <ops.h>
#include <cmp.h>
#include <stringhash.h>
#include <utils.h>
#include <climits>


using namespace symbolic;
using namespace symbolic::internal;

ex_vart::ex_vart(const std::string &n, int l)
	: ex_base(VART | ((l == INT_MIN) ? 0 : HAST) | SINGLE), m_lag(l)
{
    m_hash = stringhash::get_instance().get_hash(n);
}

ex_vart::ex_vart(unsigned i, int l)
    : ex_base(VART | ((l == INT_MIN) ? 0 : HAST) | SINGLE), m_lag(l)
{
    m_hash = i;
}



ptr_base
ex_vart::create(const std::string &n, int l)
{
    return ptr_base(new ex_vart(n, l));
}


ptr_base
ex_vart::create(unsigned i, int l)
{
    return ptr_base(new ex_vart(i, l));
}

void
ex_vart::destroy(ex_base *ptr)
{
	delete ptr;
}


ptr_base
ex_vart::copy() const
{
	return ptr_base(new ex_vart(*this));
}


ptr_base
ex_vart::copy0() const
{
	return ptr_base(new ex_vart(m_hash, 0));
}


int
ex_vart::compare(const ex_vart &b) const
{
    if (m_lag < b.m_lag) return -1;
    if (m_lag > b.m_lag) return 1;
    return compareT(m_hash, b.m_hash);
}


int
ex_vart::compare_name(const ex_vart &b) const
{
    return compareT(m_hash, b.m_hash);
}



std::string
ex_vart::get_name() const
{
    return stringhash::get_instance().get_str(m_hash);
}



std::string
ex_vart::str(print_flag pflag) const
{
    std::string name = get_name();
    switch (pflag) {
        case DEFAULT:
            if (m_lag == INT_MIN) return name + "[ss]";
            else if (m_lag == 0) return name + "[]";
            else return name + '[' + num2str(m_lag) + ']';
        case CONVERT_T_IDX:
            if (m_lag == INT_MIN) return name + "_ss";
            if (m_lag < 0) return name + "_tm" + num2str(-m_lag);
            if (m_lag == 0) return name + "_t";
            return name + "_tp" + num2str(m_lag);
        case DROP_T_IDX:
            return name;
        default:
            USER_ERROR("invalid print flag in ex_vart::str()")
    }
}


std::string
ex_vart::strmap(const map_str_str &mss) const
{
    std::string name = get_name();
    map_str_str::const_iterator it;
    it = mss.find(name);
    if (it == mss.end()) {
        return name;
    }
    return it->second;
}


std::string
ex_vart::tex(print_flag pflag) const
{
    std::string name = get_name();
    switch (pflag) {
        case DEFAULT:
            if (m_lag == INT_MIN) return str2tex(name) + "_\\mathrm{ss}";
            if (m_lag == 0) return str2tex(name) + "_{t}";
            if (m_lag < 0) return str2tex(name) + "_{t" + num2str(m_lag) + '}';
            return str2tex(name) + "_{t+" + num2str(m_lag) + '}';
        case DROP_T_IDX:
            return str2tex(name);
        default:
            USER_ERROR("invalid print flag in ex_vart::tex()")
    }
}


int
ex_vart::get_lag_max(bool) const
{
    return m_lag;
}


int
ex_vart::get_lag_min(bool) const
{
    if (m_lag == INT_MIN) return INT_MAX;
    return m_lag;
}


ptr_base
ex_vart::diff(const ptr_base &p) const
{
    if (p->type() == VART) {
        const ex_vart *pp = static_cast<const ex_vart*>(p.get());
        if (!compare(*pp)) return ex_num::one();
    }
    return ex_num::zero();
}


ptr_base
ex_vart::subst(const ptr_base &what, const ptr_base &with, bool all_leads_lags) const
{
    if (what->type() != VART) return copy();
    const ex_vart *pw = static_cast<const ex_vart*>(what.get());
    if (!all_leads_lags) {
        if (compare(*pw)) return copy();
        return with;
    }
    if (!compare_name(*pw)) {
        if (m_lag == INT_MIN) return ss(with);
        return symbolic::internal::lag(with, m_lag - pw->m_lag);
    }
    return copy();
}


ptr_base
ex_vart::lag(int l) const
{
    return create(m_hash, m_lag + l);
}








