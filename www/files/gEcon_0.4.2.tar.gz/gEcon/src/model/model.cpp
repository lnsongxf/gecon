/***********************************************************
 * (c) Kancelaria Prezesa Rady Ministrów 2012-2014         *
 * Treść licencji w pliku 'LICENCE'                        *
 *                                                         *
 * (c) Chancellery of the Prime Minister 2012-2014         *
 * License terms can be found in the file 'LICENCE'        *
 *                                                         *
 * Author: Grzegorz Klima                                  *
 ***********************************************************/

/** \file model.cpp
 * \brief Class representing DSGE model.
 */

#include <model.h>
#include <model_parse.h>
#include <ops.h>
#include <utils.h>
#include <helper.h>
#include <stdexcept>
#include <fstream>
#include <cstdlib>
#include <ctime>

using symbolic::internal::num2str;
using symbolic::internal::print_flag;
using symbolic::internal::DEFAULT;
using symbolic::internal::CONVERT_T_IDX;
using symbolic::internal::DROP_T_IDX;
using symbolic::triplet;


void
Model::warning(const std::string &mes)
{
    m_warn.push_back(mes);
}


void
Model::error(const std::string &mes)
{
    m_err.push_back(mes);
}


void
Model::terminate_on_errors()
{
    if (m_err.size()) {
        std::string errs = get_errs(), warns = get_warns();
        write_logf();
        clear();
        report_warns(warns);
        report_errors(errs);
    }
}



std::string
Model::get_errs() const
{
    std::string errs;
    std::vector<std::string>::const_iterator it;
    int i = 1;
    for (it = m_err.begin(); it != m_err.end(); ++it, ++i)
        errs += "(gEcon model error " + num2str(i) + "): " + *it + '\n';
    return errs;
}


std::string
Model::get_warns() const
{
    std::string warns;
    std::vector<std::string>::const_iterator it;
    int i = 1;
    for (it = m_warn.begin(); it != m_warn.end(); ++it, ++i)
        warns += "(gEcon model warning " + num2str(i) + "): " + *it + '\n';
    return warns;
}


void
Model::set_name(const std::string &name)
{
    size_t slash = name.find_last_of('/');
    if (slash == std::string::npos) {
        m_name = name;
        return;
    }
    m_path = name.substr(0, slash + 1);
    m_name = name.substr(slash + 1);
}


void
Model::add_block(const std::string &s)
{
#ifdef DEBUG
    std::cerr << "Adding block: " << s << '\n';
#endif /* DEBUG */
    if (!m_names.insert(s).second)
        error("block called \'" + s + "\' already exists");
    m_blocks.push_back(Model_block(s));
}



void
Model::check_defs()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        for (unsigned d = 0, D = m_blocks[i].m_defs_lhs.size(); d < D; ++d) {
            ex lhs = m_blocks[i].m_defs_lhs[d].first;
            ex rhs = m_blocks[i].m_defs_rhs[d].first;
            if (lhs.hast()) {
                int l;
                if ((l = lhs.get_lag_max())) {
                    lhs = lag(lhs, -l);
                    error("\'" + lhs.str() + "\' defined in lead/lag; error near line "
                          + num2str(m_blocks[i].m_defs_lhs[d].second));
                }
                if (!rhs.hast()) {
                    error("variable \'" + lhs.str() + "\' defined as constant expression \'"
                          + rhs.str() + "\'; error near line "
                          + num2str(m_blocks[i].m_defs_lhs[d].second));
                }
            } else {
                if (rhs.hast()) {
                    error("constant \'" + lhs.str() + "\' defined as variable expression \'"
                          + rhs.str() + "\'; error near line "
                          + num2str(m_blocks[i].m_defs_lhs[d].second));
                }
            }
            if (!m_blocks[i].m_defs.insert(lhs).second) {
                error("\'" + lhs.str() + "\' already defined; error near line "
                        + num2str(m_blocks[i].m_defs_lhs[d].second));
            }
            if (rhs.hast(lhs)) {
                error("\'" + lhs.str() + "\' used in its own definition; error near line "
                        + num2str(m_blocks[i].m_defs_lhs[d].second));
            }
            for (unsigned dd = d + 1; dd < D; ++dd) {
                ex rhsf = m_blocks[i].m_defs_rhs[dd].first;
                if (rhsf.hast(lhs)) {
                    error("\'" + lhs.str() + "\' appears in definition following "
                          "the definition of \'" + lhs.str() + "\' itself; error near line "
                            + num2str(m_blocks[i].m_defs_lhs[dd].second));
                }
            }
        }
    }
}



void
Model::subst_defs()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        m_blocks[i].subst_defs();
    }
}



void
Model::check_obj_contr()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        ex obj = m_blocks[i].m_obj_var;
        if (obj) {
            int l;
            if ((l = obj.get_lag_max())) {
                error("objective variable \'" + lag(obj, -l).str() + "\' on LHS of " + m_blocks[i].m_name
                      + "\'s problem is in lag different than 0; error near line "
                      + num2str(m_blocks[i].m_obj_line));
            }
            if (!m_obj.insert(exstr(obj, m_blocks[i].m_name)).second) {
                error("objective variable \'" + obj.str() + "\' in " + m_blocks[i].m_name
                      + "\'s problem is objective variable in " + m_obj.find(obj)->second
                      + "\'s problem; error near line " + num2str(m_blocks[i].m_obj_line));
            }
            if (m_blocks[i].m_obj_eq.hasdifft(lag(obj, 1))) {
                error("objective variable \'" + obj.str() + "\' on RHS of " + m_blocks[i].m_name
                      + "\'s problem is in lead/lag different than 1; "
                      + "error near line " + num2str(m_blocks[i].m_obj_line));
            }
            for (unsigned j = 0, J = m_blocks[i].m_constraints.size(); j < J; ++j) {
                if (m_blocks[i].m_constraints[j].first.hasdifft(lag(obj, 1))) {
                    error("objective variable \'" + obj.str() + "\' in " + m_blocks[i].m_name
                        + "\'s problem's constraint is in lead/lag different than 1; "
                        + "error near line " + num2str(m_blocks[i].m_constraints[j].second));
                }
            }
        }
    }

    for (std::map<ex, std::string>::const_iterator it = m_obj.begin();
         it != m_obj.end(); ++it) {
        for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
            for (unsigned j = 0, J = m_blocks[i].m_identities.size(); j < J; ++j) {
                if (m_blocks[i].m_identities[j].first.hast(it->first)) {
                    warning(it->second + "\'s objective variable \'" + it->first.str()
                            + "\' appears in identity; warning near line "
                            + num2str(m_blocks[i].m_identities[j].second));
                }
            }
        }
    }

    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        for (unsigned c = 0, C = m_blocks[i].m_controls.size(); c < C; ++c) {
            ex contr = m_blocks[i].m_controls[c].first;
            int l;
            bool any = false;
            if ((l = contr.get_lag_max())) {
                error("control variable \'" + lag(contr, -l).str() + "\' in " + m_blocks[i].m_name
                      + "\'s problem lag is " + num2str(l) + "; error near line "
                      + num2str(m_blocks[i].m_controls[c].second));
            }
            if (!m_blocks[i].m_contr.insert(contr).second) {
                error("control variable \'" + contr.str() + "\' in "
                      + m_blocks[i].m_name + "\'s problem is duplicated; error near line "
                      + num2str(m_blocks[i].m_controls[c].second));
            }
            if (m_blocks[i].m_defs.find(contr) != m_blocks[i].m_defs.end()) {
                error("control variable \'" + contr.str() + "\' in "
                      + m_blocks[i].m_name + "\'s problem was used in definitions "
                      + "(substituted); error near line "
                      + num2str(m_blocks[i].m_controls[c].second));
            }
            if (m_obj.find(contr) != m_obj.end()) {
                error("control variable \'" + contr.str() + "\' in " + m_blocks[i].m_name
                      + "\'s problem is objective variable in " + m_obj.find(contr)->second
                      + "\'s problem; error near line "
                      + num2str(m_blocks[i].m_controls[c].second));
            }
            if (!m_contr.insert(exstr(contr, m_blocks[i].m_name)).second) {
                warning("control variable \'" + contr.str() + "\' in "
                        + m_blocks[i].m_name + "\'s problem is control variable in "
                        + m_contr.find(contr)->second + "\'s problem; "
                        + "if this was intentional you might consider rewriting your model in terms "
                        + "of two different controls and adding equilibrium condition equating them; "
                        + "warning near line "+ num2str(m_blocks[i].m_controls[c].second));
            }
            if (m_blocks[i].m_obj_eq.hast(contr)) any = true;
            if (m_blocks[i].m_obj_eq.haslead(contr)) {
                error("control variable \'" + contr.str() + "\' in " + m_blocks[i].m_name
                      + "\'s problem is in lead; error near line "
                      + num2str(m_blocks[i].m_obj_line));
            }
            for (unsigned j = 0, J = m_blocks[i].m_constraints.size(); j < J; ++j) {
                if (m_blocks[i].m_constraints[j].first.hast(contr)) any = true;
                if (m_blocks[i].m_constraints[j].first.haslead(contr)) {
                    error("control variable \'" + contr.str() + "\' in " + m_blocks[i].m_name
                        + "\'s problem is in lead; error near line "
                        + num2str(m_blocks[i].m_constraints[j].second));
                }
            }
            if (!any) {
                error("control variable \'" + contr.str() + "\' in " + m_blocks[i].m_name
                    + "\'s problem does not appear in objective nor in any constraint; error near line "
                    + num2str(m_blocks[i].m_controls[c].second));
            }
        }
    }
}



void
Model::check_deter()
{
    m_deter = true;
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        if (m_blocks[i].m_shocks.size()) {
            m_deter = false;
            return;
        }
    }
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        ex eq = m_blocks[i].m_obj_eq;
        int l = m_blocks[i].m_obj_line;
        if (eq.has_Es() > 0) {
            warning("dropping expectation in objective \'"
                    + m_blocks[i].m_obj_var.str() + " = " + eq.str()
                    + "\'; model is deterministic (has no shocks); "
                    + "warning near line " + num2str(l));
            m_blocks[i].m_obj_eq = drop_Es(m_blocks[i].m_obj_eq);
            m_blocks[i].m_obj_eq_in = drop_Es(m_blocks[i].m_obj_eq_in);
        }
        for (unsigned e = 0; e < m_blocks[i].m_constraints.size(); ++e) {
            eq = m_blocks[i].m_constraints[e].first;
            l = m_blocks[i].m_constraints[e].second;
            if (eq.has_Es() > 0) {
                warning("dropping expectation in constraint \'"
                        + eq.str() + " = 0\'; model is deterministic (has no shocks); "
                        + "warning near line " + num2str(l));
                m_blocks[i].m_constraints[e].first =
                    drop_Es(m_blocks[i].m_constraints[e].first);
            }
        }
        for (unsigned e = 0; e < m_blocks[i].m_identities.size(); ++e) {
            eq = m_blocks[i].m_identities[e].first;
            l = m_blocks[i].m_identities[e].second;
            if (eq.has_Es() > 0) {
                warning("dropping expectation in identity \'"
                        + eq.str() + " = 0\'; model is deterministic (has no shocks); "
                        + "warning near line " + num2str(l));
                m_blocks[i].m_identities[e].first =
                    drop_Es(m_blocks[i].m_identities[e].first);
            }
        }
    }
}



void
Model::leads()
{
    m_max_lag = 0;
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        if (!m_deter) {
            ex eq = m_blocks[i].m_obj_eq;
            int l = m_blocks[i].m_obj_line;
            if (eq.get_lag_max(true) > 0) {
                error("forward looking variable(s) in objective \'"
                      + m_blocks[i].m_obj_var.str() + " = " + eq.str()
                      + "\' outside expected value operator in stochastic model; "
                      + "error near line " + num2str(l));
            }
            for (unsigned e = 0; e < m_blocks[i].m_constraints.size(); ++e) {
                eq = m_blocks[i].m_constraints[e].first;
                l = m_blocks[i].m_constraints[e].second;
                if (eq.get_lag_max(true) > 0) {
                    error("forward looking variable(s) in constraint \'"
                        + eq.str() + " = 0\' outside expected value operator "
                        + "in stochastic model; error near line " + num2str(l));
                }
            }
            for (unsigned e = 0; e < m_blocks[i].m_identities.size(); ++e) {
                eq = m_blocks[i].m_identities[e].first;
                l = m_blocks[i].m_identities[e].second;
                if (eq.get_lag_max(true) > 0) {
                    error("forward looking variable(s) in identity \'"
                        + eq.str() + " = 0\' outside expected value operator "
                        + "in stochastic model; error near line " + num2str(l));
                }
            }
        }

        ex eq = m_blocks[i].m_obj_eq;
        int l = m_blocks[i].m_obj_line;
        int mlag;
        if ((mlag = eq.get_lag_max()) > 1) {
            error("variable(s) in objective \'"
                    + m_blocks[i].m_obj_var.str() + " = " + eq.str()
                    + "\' in lead > 1; error near line " + num2str(l));
        }
        if (mlag > m_max_lag) m_max_lag = mlag;
        for (unsigned e = 0; e < m_blocks[i].m_constraints.size(); ++e) {
            eq = m_blocks[i].m_constraints[e].first;
            l = m_blocks[i].m_constraints[e].second;
            if ((mlag = eq.get_lag_max()) > 1) {
                error("variable(s) in constraint \'"
                    + eq.str() + " = 0\' in lead > 1; error near line " + num2str(l));
            }
            if (mlag > m_max_lag) m_max_lag = mlag;
        }
        for (unsigned e = 0; e < m_blocks[i].m_identities.size(); ++e) {
            eq = m_blocks[i].m_identities[e].first;
            l = m_blocks[i].m_identities[e].second;
            if ((mlag = eq.get_lag_max()) > 1) {
                error("variable(s) in identity \'"
                    + eq.str() + " = 0\' in lead > 1; error near line " + num2str(l));
            }
            if (mlag > m_max_lag) m_max_lag = mlag;
        }
    }
}



void
Model::lags()
{
    m_min_lag = 0;
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        int bmlag = 0, mlag;
        ex eq = m_blocks[i].m_obj_eq;
        mlag = eq.get_lag_min();
        if (mlag < bmlag) bmlag = mlag;
        for (unsigned e = 0; e < m_blocks[i].m_constraints.size(); ++e) {
            eq = m_blocks[i].m_constraints[e].first;
            mlag = eq.get_lag_min();
            if (mlag < bmlag) bmlag = mlag;
        }
        for (unsigned e = 0; e < m_blocks[i].m_identities.size(); ++e) {
            eq = m_blocks[i].m_identities[e].first;
            mlag = eq.get_lag_min();
            if (mlag < bmlag) bmlag = mlag;
        }
        if (bmlag < m_min_lag) m_min_lag = bmlag;
        if (bmlag < -1) {
            m_blocks[i].lags();
        }
    }
}



void
Model::check_static()
{
    if ((m_min_lag == 0) || (m_max_lag == 0)) m_static = true;
    if (m_static && !m_deter) {
        error("model is static (has no lags and leads) but has shocks; static models must be deterministic");
    }
}


void
Model::focs()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        if (m_deter) {
            m_blocks[i].focs_deter();
        } else {
            m_blocks[i].focs();
        }
        for (int f = 0, F = m_blocks[i].m_focs.size(); f < F; ++f) {
            if (!m_blocks[i].m_focs[f].first)
                warning("one of your first order conditions in " + m_blocks[i].m_name +
                        "\'s problem is of the form 0 = 0;");
        }
    }
}


void
Model::collect_shocks()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        std::vector<exint>::const_iterator it, ite;
        it = m_blocks[i].m_shocks.begin();
        ite = m_blocks[i].m_shocks.end();
        for (; it != ite; ++it) {
            if (m_blocks[i].m_defs.find(it->first) != m_blocks[i].m_defs.end()) {
                error("shock \'" + it->first.str() + "\' declared in "
                      + m_blocks[i].m_name + "\'s block was used in definitions "
                      + "(substituted); error near line " + num2str(it->second));
            }
            if (it->first.get_lag_max())
                error("shock \'" + it->first.str() + "\' declared in lead / lag;"
                      + " error near line " + num2str(it->second));
            if (!m_shocks.insert(it->first).second) {
                error("shock " + it->first.str() + " already declared;"
                      + " error near line " + num2str(it->second));
            }
            if (m_obj.find(it->first) != m_obj.end()) {
                error(m_obj.find(it->first)->second + "\'s objective variable \'"
                      + it->first.str() + "\' declared as shock;"
                      + " error near line " + num2str(it->second));
            }
            if (m_contr.find(it->first) != m_contr.end()) {
                error(m_contr.find(it->first)->second + "\'s control variable \'"
                      + it->first.str() + "\' declared as shock;"
                      + " error near line " + num2str(it->second));
            }
        }
    }
}



void
Model::collect_vp()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        m_blocks[i].collect_vp(m_vars, m_params);
    }

    // Test names of vars and params
    set_ex::const_iterator it;
    std::set<std::string> names;
    for (it = m_vars.begin(); it != m_vars.end(); ++it) {
        std::string name = it->str(DROP_T_IDX);
        names.insert(name);
    }
    for (it = m_shocks.begin(); it != m_shocks.end(); ++it) {
        std::string name = it->str(DROP_T_IDX);
        names.insert(name);
    }
    for (it = m_params.begin(); it != m_params.end(); ++it) {
        std::string name = it->str();
        if (!names.insert(name).second) {
            error("\'" + name + "\' treated both as a variable and a parameter; you "
                  "might have forgotten \'[]\'");
        }
    }                                                                                                                                                                                               // Just an Easter egg in Polish ;-)
                                                                                                                                                                                                    if (names.find("dupa") != names.end()) { warning("\"dupa\"?! Oj, brzydko, brzydko ;-)"); } if (names.find("Dupa") != names.end()) { warning("\"Dupa\"?! Oj, brzydko, brzydko ;-)"); } if (names.find("DUPA") != names.end()) { warning("\"DUPA\"?!  Oj, brzydko, brzydko ;-)"); }
    for (it = m_shocks.begin(); it != m_shocks.end(); ++it) {
        if (m_vars.find(*it) == m_vars.end()) {
            warning("shock \'" + it->str() + "\' does not appear in any model equation");
        } else m_vars.erase(*it);
    }
}



void
Model::collect_lagr()
{
    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        std::pair<set_ex::iterator, bool> res;
        ex lm = m_blocks[i].m_obj_lm;
        int l;
        if (lm) {
            if ((l = lm.get_lag_max())) {
                error("Lagrange multiplier  \'" + lag(lm, -l).str() + "\' declared in lead / lag;"
                      + " error near line " + num2str(m_blocks[i].m_obj_line));
            }
            res = m_lagr_mult.insert(lm);
            if (!res.second) {
                error("Lagrange multiplier \'" + lm.str() + "\' already used;"
                      + " error near line " + num2str(m_blocks[i].m_obj_line));
            }
        }
        std::vector<exint>::const_iterator it, ite;
        it = m_blocks[i].m_lagr_mult.begin();
        ite = m_blocks[i].m_lagr_mult.end();
        for (; it != ite; ++it) {
            if ((l = it->first.get_lag_max())) {
                error("Lagrange multiplier  \'" + lag(it->first, -l).str() + "\' declared in lead / lag;"
                      + " error near line " + num2str(it->second));
            }
            res = m_lagr_mult.insert(it->first);
            if (!res.second) {
                error("Lagrange multiplier \'" + it->first.str() + "\' already used;"
                      + " error near line " + num2str(it->second));
            }
        }
    }
}


void
Model::collect_eq()
{
    int i, n;
    for (i = 0, n = m_blocks.size(); i < n; ++i) {
        std::vector<expair>::const_iterator itp, itep;
        itp = m_blocks[i].m_focs.begin();
        itep = m_blocks[i].m_focs.end();
        for (; itp != itep; ++itp) {
            if (!m_eqs.insert(itp->first).second) {
                warning("repeating equation: " + itp->first.str() + " = 0");
            }
        }
        if (m_blocks[i].m_obj_eq) {
            ex lhs = m_blocks[i].m_obj_var, rhs = m_blocks[i].m_obj_eq;
            if (!m_eqs.insert(lhs - rhs).second) {
                warning("equation for " + m_blocks[i].m_name + "\'s objective \'"
                        + m_blocks[i].m_obj_eq.str() + "\' is duplicated");
            }
        }
        std::vector<exint>::const_iterator it, ite;
        it = m_blocks[i].m_constraints.begin();
        ite = m_blocks[i].m_constraints.end();
        for (; it != ite; ++it) {
            if (!m_eqs.insert(it->first).second) {
                warning("repeating constraint: \'" + it->first.str() + " = 0\' "
                        + "near line " + num2str(it->second));
            }
        }
        it = m_blocks[i].m_identities.begin();
        ite = m_blocks[i].m_identities.end();
        for (; it != ite; ++it) {
            if (!m_eqs.insert(it->first).second) {
                warning("repeating identity: \'" + it->first.str() + " = 0\' "
                        + "near line " + num2str(it->second));
            }
        }
    }
}



void
Model::reduce()
{
    vec_ex eqs;
    eqs.reserve(m_eqs.size());
    for (set_ex::iterator it = m_eqs.begin(); it != m_eqs.end(); ++it) eqs.push_back(*it);

    unsigned i, n = eqs.size();
    bool try_red;
    do {
        try_red = false;
        for (i = 0; i < n; ++i) {
            triplet<bool, ex, ex> ts = find_subst(eqs[i], m_lagr_mult);
            if (!ts.first) continue;
            if (ts.third.hast()) {
                ex e = ts.second, lde = lag(e, 1), lge = lag(e, -1);
                int ld = 0, lg = 0;
                for (unsigned i = 0; i < eqs.size(); ++i) {
                    if (eqs[i].has(lde)) {
                        ld = 1;
                        break;
                    }
                }
                for (unsigned i = 0; i < eqs.size(); ++i) {
                    if (eqs[i].has(lge)) {
                        lg = -1;
                        break;
                    }
                }
                if (ts.third.get_lag_max() + ld > 1) continue;
                if (ts.third.get_lag_min() + lg < -1) continue;
            }
            ex what = ts.second, with = ts.third;
            m_lagr_mult.erase(what);
            m_vars.erase(what);
            eqs[i] = ex();
            for (unsigned j = 0; j < n; ++j) {
                eqs[j] = eqs[j].subst(what, with);
            }
            try_red = true;
            break;
        }
    } while (try_red);

    m_eqs.clear();
    for (i = 0; i < n; ++i) {
        ex eq = eqs[i];
        if (eq) m_eqs.insert(eq);
    }

    int vars = m_vars.size(), count = m_eqs.size();
    if (count < vars) {
        error("there are " + num2str(vars) + " variables but only "
                + num2str(count) + " equations");
    } else if (count > vars) {
        error("there are " + num2str(count) + " equations but only "
                + num2str(vars) + " variables");
    }

}




namespace {

enum lag_flags {
    NUL    =     0,
    LAG_M1 =   0x1,
    LAG_0  =   0x2,
    LAG_P1 =   0x4
};

} /* namespace */


void
Model::var_eq_map()
{
    int i, j;
    unsigned flag;
    set_ex::const_iterator it1, it2, it3;
    ex x, r, e;

    for (it1 = m_eqs.begin(), i = 1; it1 != m_eqs.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_vars.begin(), j = 1; it2 != m_vars.end(); ++it2, ++j) {
            flag = 0;
            x = lag(*it2, -1);
            if (e.has(x)) flag |= LAG_M1;
            x = *it2;
            if (e.has(x)) flag |= LAG_0;
            x = lag(*it2, 1);
            if (e.has(x)) flag |= LAG_P1;
            if (flag) m_var_eq_map.insert(std::pair<std::pair<int, int>, unsigned>(
                                          std::pair<int, int>(i, j), flag));
        }
    }
}


void
Model::shock_eq_map()
{
    int i, j;
    set_ex::const_iterator it1, it2;
    ex x, r, e;

    for (it1 = m_eqs.begin(), i = 1; it1 != m_eqs.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_shocks.begin(), j = 1; it2 != m_shocks.end(); ++it2, ++j) {
            if (e.hasdifft(*it2)) {
                error("shock \'" + it2->str() + "\' in equation \'" + it1->str()
                      + "\' has invalid time index; shocks should have time index 0");
            }
            if (e.has(*it2)) m_shock_eq_map.insert(std::pair<int, int>(i, j));
        }
    }
}



void
Model::collect_calibr()
{
    int i, n;
    set_ex params_set, params_fr_add;
    for (i = 0, n = m_blocks.size(); i < n; ++i) {
        std::vector<exint>::const_iterator it, ite;
        unsigned j, m = m_blocks[i].m_calibr.size();
        for (j = 0; j < m; ++j) {
            ex ceq = m_blocks[i].m_calibr[j].first;
            int lineno = m_blocks[i].m_calibr[j].second;
            if (!m_static && ceq.hast()) {
                error("calibrating equation with non-steady state values: \'" + ceq.str()
                      + " = 0\'; error near line " + num2str(lineno));
            }

            set_ex vars, pars;
            collect(ceq, vars, pars);
            set_ex::const_iterator it, ite;
            for (it = vars.begin(), ite = vars.end(); it != ite; ++it) {
                if (m_vars.find(*it) == m_vars.end()) {
                    error("variable \'" + it->str() + "\' appears in calibrating equation but does not "
                          + "appear in any model equation; error near line " + num2str(lineno));
                }
            }
            vars.clear();
            for (it = pars.begin(), ite = pars.end(); it != ite; ++it) {
                if (m_params.find(*it) == m_params.end()) {
                    warning("parameter \'" + it->str()
                            + "\' appears in calibrating equation but does not "
                            + "appear in any model equation; adding \'"
                            + it->str() + "\' to free parameter list; "
                            + "warning near line " + num2str(lineno));
                    m_params_free.insert(*it);
                    params_fr_add.insert(*it);
                }
            }
            pars.clear();

            triplet<bool, ex, ex> ps = find_par_eq_num(ceq);
            if (ps.first) {
                if (!params_set.insert(ps.second).second) {
                    error("free parameter \'" + ps.second.str()
                          + "\' already set to " + m_params_frs.find(ps.second)->second.str()
                          + "; error near line " + num2str(lineno));
                }
                if (m_blocks[i].m_calibr_pl[j].size()) {
                    error("equation \'" + ps.second.str() + " = " + ps.third.str()
                          + "\' sets value of a parameter and is not a proper "
                          + "calibrating equation so it cannot be followed by a parameter list; "
                          + "error near line " + num2str(lineno));
                }
                m_params_frs.insert(expair(ps.second, ps.third));
                if (m_params_calibr.find(ps.second) != m_params_calibr.end()) {
                    error("parameter \'" + ps.second.str() + "\' was earlier declared as calibrated "
                          + "parameter; error near line " + num2str(lineno));
                }
                continue;
            }

            for (unsigned k = 0; k < m_blocks[i].m_calibr_pl[j].size(); ++k) {
                ex pp = m_blocks[i].m_calibr_pl[j][k].first;
                if (m_params.find(pp) == m_params.end()) {
                    error("parameter \'" + pp.str() + "\' declared as calibrated, but does not "
                          + "appear in any model equation; error near line "
                          + num2str(m_blocks[i].m_calibr_pl[j][k].second));
                }
//                 if (!ceq.has(pp)) {
//                     warning("parameter \'" + pp.str() + "\' is listed as calibrated through "
//                             + "equation \'" + " = 0\', but does not appear in it; "
//                             + "warning near line " + num2str(m_blocks[i].m_calibr_pl[j][k].second));
//                 }
                if (!pars.insert(pp).second) {
                    error("repeating parameter \'" + pp.str() + "\' in a parameter list; "
                          + "error near line " + num2str(m_blocks[i].m_calibr_pl[j][k].second));
                } else {
                    m_params_calibr.insert(pp);
                }
                map_ex_ex::const_iterator mit;
                if ((mit = m_params_frs.find(pp)) != m_params_frs.end()) {
                    error("parameter \'" + pp.str() + "\' declared as calibrated parameter "
                          + "yet at the same time its value was set to " + mit->second.str()
                          + "; error near line "
                          + num2str(m_blocks[i].m_calibr_pl[j][k].second));
                }
            }

            if (!m_calibr.insert(ceq).second) {
                warning("repeating calibration equation \'" + ceq.str()
                        + " = 0\'; warning near line " + num2str(lineno));
            }
        }
    }

    unsigned nfp = m_params_calibr.size(), ce = m_calibr.size();
    if (ce < nfp) {
        error("there are " + num2str(nfp) + " non-free parameters but only "
                + num2str(ce) + " calibration equations");
    } else if (ce > nfp) {
        error("there are " + num2str(ce) + " calibration equations but only "
                + num2str(nfp) + " non-free parameters");
    }

    for (set_ex::const_iterator it = m_params.begin(), ite = m_params.end();
         it != ite; ++it) {
        if (m_params_calibr.find(*it) == m_params_calibr.end())
            m_params_free.insert(*it);
    }
    for (set_ex::const_iterator it = params_fr_add.begin(),
         ite = params_fr_add.end(); it != ite; ++it) {
        m_params.insert(*it);
    }
}





void
Model::ss()
{
    set_ex::const_iterator it, it2;
    for (it = m_eqs.begin(); it != m_eqs.end(); ++it) {
        ex ssex = symbolic::ss(*it);
        if (!ssex) {
            warning("steady state equation: 0 = 0");
            continue;
        }
        for (it2 = m_shocks.begin(); it2 != m_shocks.end(); ++it2) {
            ssex = ssex.subst(symbolic::ss(*it2), ex());
        }
        if (!ssex) {
            warning("steady state equation: 0 = 0");
            continue;
        }
        if (!m_ss.insert(ssex).second) {
            warning("repeating steady state equation: " + ssex.str() + " = 0");
        }
    }

    int vs = m_vars.size(), sse = m_ss.size();
    if (vs > sse) {
        error("there are " + num2str(vs) + " variables but only "
              + num2str(sse) + " steady state equations");
    }
    if (vs < sse) {
        error("there are " + num2str(sse) + " steady state equations"
              + " but only "+ num2str(vs) + " variables");
    }
}




void
Model::ss_jacob()
{
    int i, j;
    set_ex::const_iterator it1, it2, it3;
    ex x, e, r;

    for (it1 = m_ss.begin(), i = 1; it1 != m_ss.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_vars.begin(), j = 1; it2 != m_vars.end(); ++it2, ++j) {
            x = symbolic::ss(*it2);
            r = diff(e, x);
            if (r) {
                m_jacob_ss.insert(std::pair<std::pair<int, int>, ex>(
                                  std::pair<int, int>(i, j), r));
                m_jacob_ss_calibr.insert(std::pair<std::pair<int, int>, ex>(
                                  std::pair<int, int>(i, j), r));
            }
        }
    }
    for (it1 = m_ss.begin(), i = 1; it1 != m_ss.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_params_calibr.begin(), j = m_vars.size() + 1;
             it2 != m_params_calibr.end(); ++it2, ++j) {
            x = *it2;
            r = diff(e, x);
            if (r) {
                m_jacob_ss_calibr.insert(std::pair<std::pair<int, int>, ex>(
                                  std::pair<int, int>(i, j), r));
            }
        }
    }
    for (it1 = m_calibr.begin(), i = m_ss.size() + 1; it1 != m_calibr.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_vars.begin(), j = 1; it2 != m_vars.end(); ++it2, ++j) {
            x = symbolic::ss(*it2);
            r = diff(e, x);
            if (r) {
                m_jacob_ss_calibr.insert(std::pair<std::pair<int, int>, ex>(
                                  std::pair<int, int>(i, j), r));
            }
        }
    }
    for (it1 = m_calibr.begin(), i = m_ss.size() + 1; it1 != m_calibr.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_params_calibr.begin(), j = m_vars.size() + 1;
             it2 != m_params_calibr.end(); ++it2, ++j) {
            x = *it2;
            r = diff(e, x);
            if (r) {
                m_jacob_ss_calibr.insert(std::pair<std::pair<int, int>, ex>(
                                  std::pair<int, int>(i, j), r));
            }
        }
    }
}




void
Model::diff_eqs()
{
    int i, j;
    set_ex::const_iterator it1, it2, it3;
    ex x, r, e;

    for (it1 = m_eqs.begin(), i = 1; it1 != m_eqs.end(); ++it1, ++i) {
        e = *it1;
        for (it2 = m_vars.begin(), j = 1; it2 != m_vars.end(); ++it2, ++j) {
            x = lag(*it2, -1);
            r = diff(e, x);
            r = symbolic::ss(r);
            for (it3 = m_shocks.begin(); (it3 != m_shocks.end()) && (r); ++it3) {
                r = r.subst(symbolic::ss(*it3), ex());
            }
            if (r) m_Atm1.insert(std::pair<std::pair<int, int>, ex>(
                        std::pair<int, int>(i, j), r));
            x = *it2;
            r = diff(e, x);
            r = symbolic::ss(r);
            for (it3 = m_shocks.begin(); (it3 != m_shocks.end()) && (r); ++it3) {
                r = r.subst(symbolic::ss(*it3), ex());
            }
            if (r) m_At.insert(std::pair<std::pair<int, int>, ex>(
                        std::pair<int, int>(i, j), r));
            x = lag(*it2, 1);
            r = diff(e, x);
            r = symbolic::ss(r);
            for (it3 = m_shocks.begin(); (it3 != m_shocks.end()) && (r); ++it3) {
                r = r.subst(symbolic::ss(*it3), ex());
            }
            if (r) m_Atp1.insert(std::pair<std::pair<int, int>, ex>(
                        std::pair<int, int>(i, j), r));
        }
        for (it2 = m_shocks.begin(), j = 1; it2 != m_shocks.end(); ++it2, ++j) {
            x = *it2;
            r = diff(e, x);
            r = symbolic::ss(r);
            for (it3 = m_shocks.begin(); (it3 != m_shocks.end()) && (r); ++it3) {
                r = r.subst(symbolic::ss(*it3), ex());
            }
            if (r) m_Aeps.insert(std::pair<std::pair<int, int>, ex>(
                        std::pair<int, int>(i, j), r));
        }
    }
}



void
Model::do_it()
{
#ifdef DEBUG
    std::cerr << "Sanity check\n";
#endif /* DEBUG */
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Checking definitions\n";
#endif /* DEBUG */
    check_defs();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Substituting definitions\n";
#endif /* DEBUG */
    subst_defs();
#ifdef DEBUG
    std::cerr << "Checking if model is deterministic\n";
#endif /* DEBUG */
    check_deter();
#ifdef DEBUG
    std::cerr << "Checking controls\n";
#endif /* DEBUG */
    check_obj_contr();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Checking / handling leads\n";
#endif /* DEBUG */
    leads();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Checking / handling lags\n";
#endif /* DEBUG */
    lags();
#ifdef DEBUG
    std::cerr << "Checking if model is static\n";
#endif /* DEBUG */
    check_static();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Deriving FOCs\n";
#endif /* DEBUG */
    focs();
#ifdef DEBUG
    std::cerr << "Collecting shocks\n";
#endif /* DEBUG */
    collect_shocks();
#ifdef DEBUG
    std::cerr << "Collecting variables and parameters\n";
#endif /* DEBUG */
    collect_vp();
#ifdef DEBUG
    std::cerr << "Collecting Lagrange multipliers\n";
#endif /* DEBUG */
    collect_lagr();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Collecting model equations\n";
#endif /* DEBUG */
    collect_eq();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Reducing model equations\n";
#endif /* DEBUG */
    reduce();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Constructing variables / equations map\n";
#endif /* DEBUG */
    var_eq_map();
#ifdef DEBUG
    std::cerr << "Constructing shocks / equations map\n";
#endif /* DEBUG */
    shock_eq_map();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Determining steady state equations\n";
#endif /* DEBUG */
    ss();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Collecting calibration equations\n";
#endif /* DEBUG */
    collect_calibr();
    terminate_on_errors();
#ifdef DEBUG
    std::cerr << "Determining steady state equations Jacobian\n";
#endif /* DEBUG */
    ss_jacob();
#ifdef DEBUG
    std::cerr << "Differentiating equations for 1st order perturbation\n";
#endif /* DEBUG */
    diff_eqs();
}


void
Model::write_logf() const
{
    std::string full_name = m_path + m_name + ".model.log";
#ifdef DEBUG
    std::cerr << "Writing logfile to: \'" << full_name << "\'\n";
#endif /* DEBUG */
    std::ofstream logfile(full_name.c_str());
    if (!logfile.good()) {
        report_errors("(gEcon error): failed opening logfile \'" + full_name
                      + "\' for writing");
    }
    write_log(logfile);
    if (!logfile.good()) {
        report_errors("(gEcon error): failed writing logfile \'" + full_name
                      + "\'");
    } else {
        write_info("logfile written to \'" + full_name + "\'");
    }

}


namespace {

std::string
time_str()
{
    std::string ts, mo, da, ho, mi, se;
    time_t tt = time(0);
    struct tm *now = localtime(&tt);
    mo = (now->tm_mon < 9) ? '0' + num2str(now->tm_mon + 1) : num2str(now->tm_mon + 1);
    da = (now->tm_mday < 10) ? '0' + num2str(now->tm_mday) : num2str(now->tm_mday);
    ho = (now->tm_hour < 10) ? '0' + num2str(now->tm_hour) : num2str(now->tm_hour);
    mi = (now->tm_min < 10) ? '0' + num2str(now->tm_min) : num2str(now->tm_min);
    se = (now->tm_sec < 10) ? '0' + num2str(now->tm_sec) : num2str(now->tm_sec);
    ts = num2str(now->tm_year + 1900) + '-' + mo + '-' + da
        + ' ' + ho + ':' + mi + ':' + se;
    return ts;
}


std::string
info_str()
{
    return "Generated on " + time_str() + " by gEcon ver. " + gecon_ver_str();
}

} /* namespace */



void
Model::write_log(std::ostream &logfile) const
{
    logfile << info_str() << "\n\n";
    logfile << "Model name: " << m_name << "\n\n";

    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        m_blocks[i].write_logfile(logfile, m_static);
    }

    set_ex::const_iterator it;
    std::string tab("    ");
    print_flag pflag = (m_static) ? DROP_T_IDX : DEFAULT;

    if (m_vars.size()) {
        logfile << "Variables (" << m_vars.size() << "):\n";
        it = m_vars.begin();
        logfile << tab << it->str(pflag);
        for (++it; it != m_vars.end(); ++it) {
            logfile << ", "<< it->str(pflag);
        }
        logfile << "\n\n";
    }

    if (m_lagr_mult.size()) {
        logfile << "Lagrange multipliers (" << m_lagr_mult.size() << "):\n";
        it = m_lagr_mult.begin();
        logfile << tab << it->str(pflag);
        for (++it; it != m_lagr_mult.end(); ++it) {
            logfile << ", "<< it->str(pflag);
        }
        logfile << "\n\n";
    }

    if (m_shocks.size()) {
        logfile << "Shocks (" << m_shocks.size() << "):\n";
        it = m_shocks.begin();
        logfile << tab << it->str(pflag);
        for (++it; it != m_shocks.end(); ++it) {
            logfile << ", "<< it->str(pflag);
        }
        logfile << "\n\n";
    }

    if (m_params.size()) {
        logfile << "Parameters (" << m_params.size() << "):\n";
        it = m_params.begin();
        logfile << tab << it->str(pflag);
        for (++it; it != m_params.end(); ++it) {
            logfile << ", "<< it->str(pflag);
        }
        logfile << "\n\n";
    }

    if (m_params_free.size()) {
        logfile << "Free parameters (" << m_params_free.size() << "):\n";
        it = m_params_free.begin();
        logfile << tab << it->str(pflag);
        for (++it; it != m_params_free.end(); ++it) {
            logfile << ", "<< it->str(pflag);
        }
        logfile << "\n\n";
    }

    if (m_params_calibr.size()) {
        logfile << "Calibrated parameters (" << m_params_calibr.size() << "):\n";
        it = m_params_calibr.begin();
        logfile << tab << it->str(pflag);
        for (++it; it != m_params_calibr.end(); ++it) {
            logfile << ", "<< it->str(pflag);
        }
        logfile << "\n\n";
    }

    unsigned i;
    if (m_eqs.size()) {
        logfile << "Equations (" << m_eqs.size() << "):\n";
        for (it = m_eqs.begin(), i = 1; it != m_eqs.end(); ++it, ++i) {
            logfile << " (" << i << ")  " << it->str(pflag) << " = 0\n";
        }
        logfile << "\n";
    }

    if (!m_static && m_ss.size()) {
        logfile << "Steady state equations (" << m_ss.size() << "):\n";
        for (it = m_ss.begin(), i = 1; it != m_ss.end(); ++it, ++i) {
            logfile << " (" << i << ")  " << it->str(pflag) << " = 0\n";
        }
        logfile << "\n";
    }

    if (m_calibr.size()) {
        logfile << "Calibration equations (" << m_calibr.size() << "):\n";
        for (it = m_calibr.begin(), i = 1; it != m_calibr.end(); ++it, ++i) {
            logfile << " (" << i << ")  " << it->str(pflag) << " = 0\n";
        }
        logfile << "\n";
    }

    if (m_params_frs.size()) {
        logfile << "Parameter settings (" << m_params_frs.size() << "):\n";
        map_ex_ex::const_iterator itm;
        for (itm = m_params_frs.begin(), i = 1; itm != m_params_frs.end(); ++itm, ++i) {
            logfile << " (" << i << ")  " << itm->first.str(pflag) << " = "
                    << itm->second.str(pflag) << "\n";
        }
        logfile << "\n";
    }
}



void
Model::write_R(bool output_long) const
{
    std::string full_name = m_path + m_name + ".R";
#ifdef DEBUG
    std::cerr << "Writing R code to file: \'" << full_name << "\'\n";
#endif /* DEBUG */
    std::ofstream R(full_name.c_str());
    if (!R.good()) {
        report_errors("(gEcon error): failed opening R file \'" + full_name
                      + "\' for writing");
    }
    set_ex::const_iterator it;
    std::string tab("    ");
    int index;
    int n_eq = m_eqs.size(), n_v = m_vars.size(), n_s = m_shocks.size();

    R << "# " << info_str() << "\n# Model name: " << m_name << "\n\n";

    R << "# info\ninfo__ <- c(\"" << m_name << "\", \""
      << m_path << m_name << "\", \""
      << time_str() << "\")\n\n";

    R << "# variables\n";
    R << "variables__ <- c(";
    it = m_vars.begin();
    R << '\"' << it->str(DROP_T_IDX) << '\"';
    for (++it; it != m_vars.end(); ++it) {
        R << ",\n                 \"" << it->str(DROP_T_IDX) << '\"';
    }
    R << ")\n\n";

    R << "# shocks\n";
    if (n_s) {
        R << "shocks__ <- c(";
        it = m_shocks.begin();
        R << '\"' << it->str(DROP_T_IDX) << '\"';
        for (++it; it != m_shocks.end(); ++it) {
            R << ",\n              \"" << it->str(DROP_T_IDX) << '\"';
        }
        R << ")\n\n";
    } else {
        R << "shocks__ <- character(0)\n\n";
    }

    R << "# parameters\n";
    if (m_params.size()) {
    R << "parameters__ <- c(";
        it = m_params.begin();
        R << '\"' << it->str() << '\"';
        for (++it; it != m_params.end(); ++it) {
            R << ",\n                  \"" << it->str() << '\"';
        }
        R << ")\n\n";
    } else {
        R << "parameters__ <- character(0)\n\n";
    }

    R << "# free parameters\n";
    if (m_params_free.size()) {
    R << "parameters_free__ <- c(";
        it = m_params_free.begin();
        R << '\"' << it->str() << '\"';
        for (++it; it != m_params_free.end(); ++it) {
            R << ",\n                       \"" << it->str() << '\"';
        }
        R << ")\n\n";
    } else {
        R << "parameters_free__ <- character(0)\n\n";
    }


    R << "# free parameters' values\n";
    if (m_params_free.size()) {
    R << "parameters_free_val__ <- c(";
        it = m_params_free.begin();
        map_ex_ex::const_iterator mit;
        if ((mit = m_params_frs.find(*it)) != m_params_frs.end()) {
            R << mit->second.str();
        } else {
            R << "NA";
        }
        for (++it; it != m_params_free.end(); ++it) {
            if ((mit = m_params_frs.find(*it)) != m_params_frs.end()) {
                R << ",\n                           " << mit->second.str();
            } else {
                R << ",\n                           NA";
            }
        }
        R << ")\n\n";
    } else {
        R << "parameters_free_val__ <- numeric(0)\n\n";
    }

    print_flag pflag = (m_static) ? DROP_T_IDX : DEFAULT;
    R << "# equations\n";
    if (true) {
        R << "equations__ <- c(";
        it = m_eqs.begin();
        R << '\"' << it->str(pflag) << " = 0\"";
        for (++it; it != m_eqs.end(); ++it) {
            R << ",\n                 \"" << it->str(pflag) << " = 0\"";
        }
        R << ")\n\n";
    } else {
        R << "equations__ <- character(0)\n\n";
    }

    R << "# calibrating equations\n";
    if (m_calibr.size()) {
        R << "calibr_equations__ <- c(";
        it = m_calibr.begin();
        R << '\"' << it->str(pflag) << " = 0\"";
        for (++it; it != m_calibr.end(); ++it) {
            R << ",\n                        \"" << it->str(pflag) << " = 0\"";
        }
        R << ")\n\n";
    } else {
        R << "calibr_equations__ <- character(0)\n\n";
    }

    std::map<std::pair<int, int>, unsigned>::const_iterator itim;
    R << "# variables / equations map\n";
	R << "vareqmap__ <- sparseMatrix(i = c(";
    itim = m_var_eq_map.begin();
    R << itim->first.first;
    for (++itim; itim != m_var_eq_map.end(); ++itim) R << ", " << itim->first.first;
    R << "),\n                           j = c(";
    itim = m_var_eq_map.begin();
    R << itim->first.second;
    for (++itim; itim != m_var_eq_map.end(); ++itim) R << ", " << itim->first.second;
    R << "),\n                           x = c(";
    itim = m_var_eq_map.begin();
    R << itim->second;
    for (++itim; itim != m_var_eq_map.end(); ++itim) R << ", " << itim->second;
    R << "),\n                           dims = c(" << n_eq << ", " << n_v << "))\n\n";

    std::set<std::pair<int, int> >::const_iterator itis;

    R << "# shocks / equations map\n";
    if (m_shock_eq_map.size()) {
        R << "shockeqmap__ <- sparseMatrix(i = c(";
        itis = m_shock_eq_map.begin();
        R << itis->first;
        for (++itis; itis != m_shock_eq_map.end(); ++itis) R << ", " << itis->first;
        R << "),\n                             j = c(";
        itis = m_shock_eq_map.begin();
        R << itis->second;
        for (++itis; itis != m_shock_eq_map.end(); ++itis) R << ", " << itis->second;
        R << "),\n                             x = rep(1, " << m_shock_eq_map.size();
        R << "), dims = c(" << n_eq << ", " << n_s << "))\n\n";
    } else {
        R << "shockeqmap__ <- sparseMatrix(i = NULL, j = NULL, dims = c(";
        R << n_eq << ", " << n_s << "))\n\n";
    }

    pflag = (m_static) ? DROP_T_IDX : CONVERT_T_IDX;
    R << "# steady state equations\n";
    R << "ss_eq__ <- function(v, pcalibr, pfree)\n";
    R << "{\n";
    for (it = m_vars.begin(), index = 1; it != m_vars.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str(pflag) << " = v[" << index << "]\n" ;
    }
    R << '\n';
    for (it = m_params_calibr.begin(), index = 1; it != m_params_calibr.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str() << " = pcalibr[" << index << "]\n" ;
    }
    R << '\n';
    for (it = m_params_free.begin(), index = 1; it != m_params_free.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str() << " = pfree[" << index << "]\n" ;
    }
    R << '\n' << tab << "r <- numeric(" << m_ss.size() << ")\n";
    for (it = m_ss.begin(), index = 1; it != m_ss.end(); ++it, ++index) {
        R << tab << "r[" << index << "] = " << symbolic::ss(*it).str(pflag) << "\n" ;
    }
    R << "\n" << tab << "return(r)" << "\n}\n\n";


    R << "# calibration equations\n";
    R << "calibr_eq__ <- function(v, pcalibr, pfree)\n";
    R << "{\n";
    for (it = m_vars.begin(), index = 1; it != m_vars.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str(pflag) << " = v[" << index << "]\n" ;
    }
    R << '\n';
    for (it = m_params_calibr.begin(), index = 1; it != m_params_calibr.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str() << " = pcalibr[" << index << "]\n" ;
    }
    R << '\n';
    for (it = m_params_free.begin(), index = 1; it != m_params_free.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str() << " = pfree[" << index << "]\n" ;
    }
    R << '\n' << tab << "r <- numeric(" << m_calibr.size() << ")\n";
    for (it = m_calibr.begin(), index = 1; it != m_calibr.end(); ++it, ++index) {
        R << tab << "r[" << index << "] = " << symbolic::ss(*it).str(pflag) << "\n" ;
    }
    R << '\n' << tab << "return(r)" << "\n}\n\n";

    std::map<std::pair<int, int>, ex>::const_iterator itm;
    R << "# steady state and calibration equations Jacobian\n";
    R << "ss_calibr_eq_jacob__ <- function(v, pcalibr, pfree)\n";
    R << "{\n";
    for (it = m_vars.begin(), index = 1; it != m_vars.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str(pflag) << " = v[" << index << "]\n" ;
    }
    R << '\n';
    for (it = m_params_calibr.begin(), index = 1; it != m_params_calibr.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str() << " = pcalibr[" << index << "]\n" ;
    }
    R << '\n';
    for (it = m_params_free.begin(), index = 1; it != m_params_free.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str() << " = pfree[" << index << "]\n" ;
    }
    R << '\n' << tab << "jacob <- Matrix(0, nrow = "
      << (m_ss.size() + m_calibr.size()) << ", ncol = "
      << (m_vars.size() + m_params_calibr.size()) << ", sparse = TRUE)\n";
    for (itm = m_jacob_ss_calibr.begin(); itm != m_jacob_ss_calibr.end(); ++itm) {
        R << tab << "jacob[" << itm->first.first << ", " << itm ->first.second
          << "] = " << itm->second.str(pflag) << '\n';
    }
    R << "\n" << tab << "return(jacob)" << "\n}\n\n";

    R << "# 1st order perturbation\n";
    R << "pert1__ <- function(v, pcalibr, pfree)\n";
    R << "{\n";
    for (it = m_vars.begin(), index = 1; it != m_vars.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str(pflag) << " = v[" << index << "]\n" ;
    }
    R << '\n';
    for (it = m_params_calibr.begin(), index = 1; it != m_params_calibr.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str() << " = pcalibr[" << index << "]\n" ;
    }
    R << '\n';
    for (it = m_params_free.begin(), index = 1; it != m_params_free.end(); ++it, ++index) {
        R << tab << symbolic::ss(*it).str() << " = pfree[" << index << "]\n" ;
    }
    R << '\n';


    R << tab << "Atm1 <- Matrix(0, nrow = " << n_eq << ", ncol = " << n_v
      << ", sparse = TRUE)\n";
    for (itm = m_Atm1.begin(); itm != m_Atm1.end(); ++itm) {
        R << tab << "Atm1[" << itm->first.first << ", " << itm ->first.second
          << "] = " << itm->second.str(pflag) << '\n';
    }
    R << '\n';

    R << tab << "At <- Matrix(0, nrow = " << n_eq << ", ncol = " << n_v
      << ", sparse = TRUE)\n";
    for (itm = m_At.begin(); itm != m_At.end(); ++itm) {
        R << tab << "At[" << itm->first.first << ", " << itm ->first.second
          << "] = " << itm->second.str(pflag) << '\n';
    }
    R << '\n';

	R << tab << "Atp1 <- Matrix(0, nrow = " << n_eq << ", ncol = " << n_v
      << ", sparse = TRUE)\n";
    for (itm = m_Atp1.begin(); itm != m_Atp1.end(); ++itm) {
        R << tab << "Atp1[" << itm->first.first << ", " << itm ->first.second
          << "] = " << itm->second.str(pflag) << '\n';
    }
    R << '\n';

	R << tab << "Aeps <- Matrix(0, nrow = " << n_eq << ", ncol = " << n_s
      << ", sparse = TRUE)\n";
    for (itm = m_Aeps.begin(); itm != m_Aeps.end(); ++itm) {
        R << tab << "Aeps[" << itm->first.first << ", " << itm ->first.second
          << "] = " << itm->second.str(pflag) << '\n';
    }

    R << "\n\n" << tab << "return(list(Atm1, At, Atp1, Aeps))" << "\n}\n\n";

    R << "# create model object\n"
      << "gecon_model(model_info = info__,\n"
      << "            map_var = variables__,\n"
      << "            map_shocks = shocks__,\n"
      << "            map_params = parameters__,\n"
      << "            map_params_free = parameters_free__,\n"
      << "            map_params_free_val = parameters_free_val__,\n"
      << "            map_equations = equations__,\n"
      << "            map_calibr_equations = calibr_equations__,\n"
      << "            var_eq_map = vareqmap__,\n"
      << "            shock_eq_map = shockeqmap__,\n"
      << "            ss_function = ss_eq__,\n"
      << "            calibr_function = calibr_eq__,\n"
      << "            ss_calibr_function_jac = ss_calibr_eq_jacob__,\n"
      << "            pert = pert1__)\n\n";


    if (!R.good()) {
        report_errors("(gEcon error): failed writing R file \'" + full_name
                      + "\'");
    } else {
        write_info("R code written to \'" + full_name + "\'");
    }
}


void
Model::write_LaTeX() const
{
    std::string full_name = m_path + m_name + ".tex";
#ifdef DEBUG
    std::cerr << "Writing LaTeX documentation to file: \'" << full_name << "\'\n";
#endif /* DEBUG */

    std::ofstream latex(full_name.c_str());
    if (!latex.good()) {
        report_errors("(gEcon error): failed opening LaTeX file \'" + full_name
                      + "\' for writing");
    }
    latex << "% " << info_str() << "\n% Model name: " << m_name << "\n\n";
    latex << "\
\\documentclass[a4]{article}\n\
\\usepackage[utf8]{inputenc}\n\
\\usepackage{color}\n\
\\usepackage{graphicx}\n\
\\usepackage{amsmath}\n\
\\usepackage{amssymb}\n\
\\numberwithin{equation}{section}\n\
\\usepackage[top = 2.5cm, bottom=2.5cm, left = 2.0cm, right=2.0cm]{geometry}\n\
\\begin{document}\n\n";
    latex << "\\input{" << m_name << ".model.tex}\n\n";
    latex << "\\input{" << m_name << ".results.tex}\n\n";
    latex << "\\end{document}\n\n";
    if (!latex.good()) {
        report_errors("(gEcon error): failed writing LaTeX file \'" + full_name
                      + "\'");
    }
    latex.close();

    full_name = m_path + m_name + ".results.tex";
    latex.open(full_name.c_str());
    if (!latex.good()) {
        report_errors("(gEcon error): failed opening LaTeX file \'" + full_name
                      + "\' for writing");
    }
    latex << "% " << info_str() << "\n% Model name: " << m_name << "\n\n";
    if (!latex.good()) {
        report_errors("(gEcon error): failed writing LaTeX file \'" + full_name
                      + "\'");
    }
    latex.close();

    full_name = m_path + m_name + ".model.tex";
    latex.open(full_name.c_str());
    if (!latex.good()) {
        report_errors("(gEcon error): failed opening LaTeX file \'" + full_name
                      + "\' for writing");
    }
    latex << "% " << info_str() << "\n% Model name: " << m_name << "\n\n";

    for (unsigned i = 0, n = m_blocks.size(); i < n; ++i) {
        m_blocks[i].write_LaTeX(latex, m_static);
    }

    set_ex::const_iterator it, ite;
    print_flag pflag = (m_static) ? DROP_T_IDX : DEFAULT;

    latex << "\\section{Equilibrium relationships}\n\n";
    it = m_eqs.begin();
    ite = m_eqs.end();
    for (; it != ite; ++it) {
        latex << "\\begin{equation}\n";
        latex << it->tex(pflag) << " = 0\n";
        latex << "\\end{equation}\n";
    }
    latex << "\n\n\n";

    if (!m_static) {
        latex << "\\section{Steady state relationships}\n\n";
        it = m_ss.begin();
        ite = m_ss.end();
        for (; it != ite; ++it) {
            latex << "\\begin{equation}\n";
            latex << it->tex(pflag) << " = 0\n";
            latex << "\\end{equation}\n";
        }
        latex << "\n\n\n";
    }

    if (m_calibr.size()) {
        latex << "\\section{Calibrating equations}\n\n";
        it = m_calibr.begin();
        ite = m_calibr.end();
        for (; it != ite; ++it) {
            latex << "\\begin{equation}\n";
            latex << it->tex(pflag) << " = 0\n";
            latex << "\\end{equation}\n";
        }
    }
    latex << "\n\n\n";

    if (m_params_frs.size()) {
        latex << "\\section{Parameter settings}\n\n";
        map_ex_ex::const_iterator itm, itme;
        itm = m_params_frs.begin();
        itme = m_params_frs.end();
        for (; itm != itme; ++itm) {
            latex << "\\begin{equation}\n";
            latex << itm->first.tex(pflag) << " = " << itm->second.tex(pflag) << "\n";
            latex << "\\end{equation}\n";
        }
    }
    latex << "\n\n";

    if (!latex.good()) {
        report_errors("(gEcon error): failed writing LaTeX file \'" + full_name
                      + "\'");
    } else {
        write_info("LaTeX documentation written to \'" + m_path + m_name
                   + ".tex\' and \'" + full_name + "\'; created file \'"
                   + m_path + m_name + ".results.tex\'");
    }
}


void
Model::clear()
{
    *this = Model();
}



